"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReportApp = void 0;
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var Report_module_scss_1 = tslib_1.__importDefault(require("./Report.module.scss"));
var data_1 = require("../lib/data");
var exporters_1 = require("../lib/exporters");
var BankWide_1 = require("../dashboards/BankWide");
var DepartmentInsights_1 = require("../dashboards/DepartmentInsights");
var ui_1 = require("./ui");
/* Text size: Large is the default, as readers are often older. */
var ZOOM = { standard: 1, large: 1.25, xlarge: 1.5 };
var SIDEBAR_KEY = 'edrms-sidebar-closed';
var ICONS = {
    bw: React.createElement("svg", { viewBox: "0 0 16 16" },
        React.createElement("circle", { cx: "8", cy: "8", r: "6" }),
        React.createElement("circle", { cx: "8", cy: "8", r: "2.5", fill: "currentColor" })),
    dp: React.createElement("svg", { viewBox: "0 0 16 16" },
        React.createElement("rect", { x: "2", y: "2", width: "5", height: "5" }),
        React.createElement("rect", { x: "9", y: "2", width: "5", height: "5" }),
        React.createElement("rect", { x: "2", y: "9", width: "5", height: "5" }),
        React.createElement("rect", { x: "9", y: "9", width: "5", height: "5" })),
    pj: React.createElement("svg", { viewBox: "0 0 16 16" },
        React.createElement("path", { d: "M8 2l6 6-6 6-6-6z" })),
    fp: React.createElement("svg", { viewBox: "0 0 16 16" },
        React.createElement("path", { d: "M3 4h10M3 8h10M3 12h10" })),
    rd: React.createElement("svg", { viewBox: "0 0 16 16" },
        React.createElement("circle", { cx: "8", cy: "8", r: "6" }),
        React.createElement("path", { d: "M8 5v3l2 1" })),
    ra: React.createElement("svg", { viewBox: "0 0 16 16" },
        React.createElement("rect", { x: "2", y: "3", width: "12", height: "4" }),
        React.createElement("path", { d: "M3 7v6h10V7M6 10h4" }))
};
var FUTURE = [
    { key: 'pj', text: 'Project Insights' },
    { key: 'fp', text: 'Institutional File Plan' },
    { key: 'rd', text: 'Retention & Disposal' },
    { key: 'ra', text: 'Records & Archive Holdings' }
];
function readClosed() {
    try {
        return localStorage.getItem(SIDEBAR_KEY) === '1';
    }
    catch (_a) {
        return false;
    }
}
var ReportApp = function (props) {
    var data = React.useMemo(data_1.loadReportData, []);
    var _a = React.useState(props.dashboard), dash = _a[0], setDash = _a[1];
    var _b = React.useState(undefined), focus = _b[0], setFocus = _b[1];
    var _c = React.useState(readClosed), closed = _c[0], setClosed = _c[1];
    var _d = React.useState(false), busy = _d[0], setBusy = _d[1];
    var page = React.useRef(null);
    var root = React.useRef(null);
    React.useEffect(function () { return setDash(props.dashboard); }, [props.dashboard]);
    var go = function (d) {
        setDash(d);
        if (d === 'bw')
            setFocus(undefined);
        if (root.current)
            root.current.scrollIntoView({ block: 'start' });
    };
    var openDept = function (code) { setFocus(code); go('dp'); };
    var toggle = function () {
        var next = !closed;
        setClosed(next);
        try {
            localStorage.setItem(SIDEBAR_KEY, next ? '1' : '0');
        }
        catch ( /* private window */_a) { /* private window */ }
    };
    var pdf = function () {
        if (!page.current || busy)
            return;
        setBusy(true);
        // The PDF library does not understand CSS zoom, so the page is drawn at
        // standard size and the text size is put back afterwards.
        var r = root.current, zoom = r ? r.style.getPropertyValue('zoom') : '';
        if (r)
            r.style.setProperty('zoom', '1');
        var done = function () { if (r)
            r.style.setProperty('zoom', zoom); setBusy(false); };
        (0, exporters_1.exportPdf)(page.current, dash === 'bw' ? 'Bank-wide Oversight' : 'Department Insights').then(done, done);
    };
    var bandTools = (React.createElement(React.Fragment, null,
        React.createElement("span", { className: "asof" },
            React.createElement("i", null),
            "Data as of",
            React.createElement("b", null, data.asOf)),
        React.createElement("button", { type: "button", className: "pdfBtn", onClick: pdf, disabled: busy, "data-html2canvas-ignore": "true" },
            React.createElement(ui_1.DownloadGlyph, null),
            busy ? 'Preparing PDF' : 'Export to PDF')));
    return (React.createElement("div", { ref: root, className: Report_module_scss_1.default.report, style: { zoom: ZOOM[props.textSize] || 1.25 } },
        props.showSidebar && (React.createElement("nav", { className: 'side' + (closed ? ' closed' : ''), "aria-label": "Dashboards" },
            React.createElement("div", { className: "brand" },
                React.createElement("button", { type: "button", className: "menuBtn", onClick: toggle, "aria-expanded": !closed, title: closed ? 'Open navigation' : 'Close navigation', "aria-label": closed ? 'Open navigation' : 'Close navigation' },
                    React.createElement("svg", { viewBox: "0 0 24 24" },
                        React.createElement("path", { d: "M4 6h16M4 12h16M4 18h16" }))),
                React.createElement("div", { className: "t1" }, "EDRMS Utilization Report"),
                React.createElement("div", { className: "t2" }, "Asian Development Bank")),
            React.createElement("div", { className: "grp" }, "Key views"),
            React.createElement("button", { type: "button", className: 'nav' + (dash === 'bw' ? ' on' : ''), "aria-current": dash === 'bw' ? 'page' : undefined, title: "Bank-wide Oversight", onClick: function () { return go('bw'); } },
                ICONS.bw,
                React.createElement("span", { className: "navTx" }, "Bank-wide Oversight")),
            React.createElement("button", { type: "button", className: 'nav' + (dash === 'dp' ? ' on' : ''), "aria-current": dash === 'dp' ? 'page' : undefined, title: "Department Insights", onClick: function () { return go('dp'); } },
                ICONS.dp,
                React.createElement("span", { className: "navTx" }, "Department Insights")),
            React.createElement("div", { className: "grp" }, "For future release"),
            FUTURE.map(function (f) { return (React.createElement("button", { type: "button", key: f.key, className: "nav future", "aria-disabled": "true", title: f.text + ' (future release)' },
                ICONS[f.key],
                React.createElement("span", { className: "navTx" }, f.text))); }))),
        React.createElement("div", { className: "main", ref: page }, dash === 'bw'
            ? React.createElement(BankWide_1.BankWide, { data: data, openDept: openDept, bandTools: bandTools })
            : React.createElement(DepartmentInsights_1.DepartmentInsights, { data: data, openDept: openDept, bandTools: bandTools, focus: focus }))));
};
exports.ReportApp = ReportApp;
//# sourceMappingURL=ReportApp.js.map