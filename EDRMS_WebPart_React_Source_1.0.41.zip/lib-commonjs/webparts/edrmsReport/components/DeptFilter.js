"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeptFilter = void 0;
exports.filterDepts = filterDepts;
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var react_1 = require("@fluentui/react");
var ui_1 = require("./ui");
/**
 * The Filter button on department tables: tick the departments to show, then
 * Apply. An empty selection means every department.
 */
var DeptFilter = function (_a) {
    var depts = _a.depts, selected = _a.selected, onApply = _a.onApply;
    var _b = React.useState(false), open = _b[0], setOpen = _b[1];
    var _c = React.useState([]), draft = _c[0], setDraft = _c[1];
    var btn = React.useRef(null);
    var sortedDepts = React.useMemo(function () { return depts.slice().sort(function (a, b) { return a.code.localeCompare(b.code); }); }, [depts]);
    var all = sortedDepts.map(function (d) { return d.code; });
    var show = function () { setDraft(selected.length ? selected.slice() : all.slice()); setOpen(true); };
    var toggle = function (code, on) {
        return setDraft(on ? draft.concat(code) : draft.filter(function (c) { return c !== code; }));
    };
    var apply = function () { onApply(draft.length === all.length ? [] : draft); setOpen(false); };
    var reset = function () { onApply([]); setOpen(false); };
    return (React.createElement(React.Fragment, null,
        React.createElement("button", { type: "button", ref: btn, className: 'fBtn' + (selected.length ? ' on' : ''), "aria-haspopup": "true", "aria-expanded": open, onClick: function () { return (open ? setOpen(false) : show()); } },
            React.createElement(ui_1.FunnelGlyph, null),
            "Filter",
            selected.length ? " (".concat(selected.length, ")") : ''),
        open && (React.createElement(react_1.Callout, { target: btn, onDismiss: function () { return setOpen(false); }, directionalHint: react_1.DirectionalHint.bottomRightEdge, gapSpace: 6, setInitialFocus: true, role: "dialog", ariaLabel: "Filter departments" },
            React.createElement("div", { className: "fPop" },
                React.createElement("div", { className: "fAll" },
                    React.createElement(react_1.Checkbox, { label: "All Departments / Offices / RMs / ROs", checked: draft.length === all.length, indeterminate: draft.length > 0 && draft.length < all.length, onChange: function (_, on) { return setDraft(on ? all.slice() : []); } })),
                React.createElement("div", { className: "fList" }, sortedDepts.map(function (d) { return (React.createElement("div", { key: d.code },
                    React.createElement(react_1.Checkbox, { checked: draft.indexOf(d.code) >= 0, onChange: function (_, on) { return toggle(d.code, !!on); }, onRenderLabel: function () { return React.createElement("span", { style: { marginLeft: 8, fontSize: 13 } },
                            React.createElement("b", null, d.code),
                            " ",
                            React.createElement("span", { style: { color: '#6B7A8C' } }, d.name)); } }))); })),
                React.createElement("div", { className: "fBtns" },
                    React.createElement("button", { type: "button", className: "btn", onClick: reset }, "Reset"),
                    React.createElement("button", { type: "button", className: "btn primary", disabled: !draft.length, onClick: apply }, "Apply")))))));
};
exports.DeptFilter = DeptFilter;
/** Filters and searches a department list the same way on every table. */
function filterDepts(depts, selected, query) {
    var q = query.trim().toLowerCase();
    return depts.filter(function (d) { return (!selected.length || selected.indexOf(d.code) >= 0) &&
        (!q || (d.code + ' ' + d.name).toLowerCase().indexOf(q) >= 0); });
}
//# sourceMappingURL=DeptFilter.js.map