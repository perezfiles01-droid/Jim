import * as React from 'react';
import { IReportData, IDept, approxHead, sum, isMissing, NOT_SOURCED } from '../helpers/edrmsData';
import { F } from '../helpers/edrmsFormat';
import { Band, KpiRow, IKpi } from './EdrmsUi';
import { FilteredResults } from './EdrmsFilteredResults';
import { DocumentsView, SitesView, UsersView, RecordsView, PhysicalView } from './EdrmsDocumentsView';

/*
 * Web part 1.0.59: Bank-wide Oversight as in the Floot app (24 Nov 2026). The Floot file also
 * keeps the earlier drill-downs, Comparison and the records trend, switched off; they never
 * show, so they are left out here. The page-wide "html,body" background rule is left out too,
 * so the web part does not repaint the rest of the SharePoint page.
 */

export interface IDashboardProps {
  data: IReportData;
  /** Opens Department Insights for one department. */
  openDept: (code: string) => void;
  /** The "Data as of" and Export to PDF controls for the title band. */
  bandTools: React.ReactNode;
}

/** The bank-wide headcount: the sum of each unit's rounded headcount, so cards and tables add up the same way. */
const roundedHead = (depts: IDept[]): number => sum(depts, approxHead);

const CSS = `
.edrms-report .main{background:#C3E4F3}
.edrms-report{display:flex;align-items:stretch}
.edrms-report > .side{min-height:inherit;align-self:stretch}
.edrms-report > .main{flex:1 1 auto}
.edrms-report .main > div > :last-child,.edrms-report .main > div > :last-child > :last-child,.edrms-report .main > div > :last-child > :last-child > :last-child{margin-bottom:0!important}
.dash-bw .panel{background:transparent!important;box-shadow:none!important;border:0!important}
.dash-bw .kpi{background:#fff!important;border:2px solid #1B2A38!important;border-radius:14px!important}
.dash-bw .kpi.on{background:#FFC000!important;border-color:#1B2A38!important}
.dash-bw .kpi.on .lab,.dash-bw .kpi.on .val,.dash-bw .kpi.on .tap{color:#10243E!important}
.dash-bw .fr,.dash-bw .trend{display:grid!important;grid-template-columns:minmax(0,1.15fr) minmax(0,1fr);column-gap:14px;align-items:stretch}
.dash-bw .fr > *,.dash-bw .trend > *{grid-column:1/-1}
.dash-bw .fr .frStrip,.dash-bw .trend .tiles{grid-column:1!important;grid-row:2}
.dash-bw .fr .frFilters,.dash-bw .trend .ctl{grid-column:2!important;grid-row:2}
.dash-bw .trend > .ptitle{grid-row:1}.dash-bw .trend > .psub{grid-row:1;margin-top:28px}
.dash-bw .dv .dvTop{display:grid!important;grid-template-columns:minmax(0,1.15fr) minmax(0,1fr);gap:14px;align-items:stretch}
.dash-bw .dv .dvBox.fil{order:0!important}
.dash-bw .dv .dvBox.fil h4{display:block!important}
.dash-bw .dv .dvF .ttl{display:none}
.dash-bw .fr .frStrip,.dash-bw .fr .frFilters,.dash-bw .dv .dvBox,.dash-bw .trend .tiles,.dash-bw .trend .ctl{background:#1B5E80!important;border:2px solid #0E3A52!important;border-radius:18px!important;padding:14px 16px!important;color:#fff!important;margin:0 0 14px!important}
.dash-bw .fr .frStrip::before,.dash-bw .trend .tiles::before{content:'"Filtered results"';color:#fff!important;font-size:18px!important;font-weight:700!important;text-transform:none!important;letter-spacing:0!important}
.dash-bw .fr .frFilters::before,.dash-bw .trend .ctl::before{content:'Filters';display:block;width:100%;color:#fff;font-size:18px;font-weight:700;margin-bottom:8px}
.dash-bw .dv .dvBox h4{color:#fff!important;font-size:18px!important;font-weight:700!important;text-transform:none!important;letter-spacing:0!important}
.dash-bw .dv .dvTop > .dvBox:not(.fil) h4::before,.dash-bw .dv .dvTop > .dvBox:not(.fil) h4::after{content:'"'}
.dash-bw .fr .frStrip{grid-template-columns:repeat(5,minmax(0,1fr))!important;align-content:start;gap:10px!important}
.dash-bw .fr .frCell .infoWrap,.dash-bw .dv .dvCard .infoWrap,.dash-bw .trend .tile .infoWrap{top:6px!important;right:6px!important}
.dash-bw .fr,.dash-bw .trend{display:flex!important;flex-direction:column!important}
.dash-bw .fr > *,.dash-bw .trend > *{order:9}
.dash-bw .trend > .ptitle{order:0}.dash-bw .trend > .psub{order:1;margin-top:0!important}
.dash-bw .fr > .frFilters,.dash-bw .trend > .ctl{order:2}
.dash-bw .fr > .frHint,.dash-bw .trend > .note{order:3}
.dash-bw .fr > .frStrip,.dash-bw .trend > .tiles{order:4}
.dash-bw .fr > style,.dash-bw .trend > style{order:0}
.dash-bw .dv .dvTop{grid-template-columns:minmax(0,1fr)!important}
.dash-bw .dv .dvBox.fil{order:-1!important}
.dash-bw .fr .frFilters .frG{flex:0 0 auto}
.dash-bw .trend .tiles{grid-template-columns:minmax(0,300px)!important}
.dash-bw{--teal:#1B5E80;--ink:#10243E;--line:#0E3A52}
.dash-bw .kpis{gap:16px!important}
.dash-bw .kpi{border:1px solid #9FB7C8!important;border-radius:12px!important;box-shadow:0 1px 2px rgba(16,36,62,.06)!important;padding:16px 18px!important}
.dash-bw .kpi.on{border-color:#C99700!important;box-shadow:0 2px 6px rgba(201,151,0,.25)!important}
.dash-bw .kpi .lab{font-size:15px!important;font-weight:600!important}
.dash-bw .kpi .val{font-size:30px!important}
.dash-bw .panel.fr,.dash-bw .panel.trend,.dash-bw .panel.dv{padding:0!important;margin-top:16px!important}
.dash-bw .fr .frFilters,.dash-bw .fr .frStrip,.dash-bw .dv .dvBox,.dash-bw .trend .ctl,.dash-bw .trend .tiles{border:0!important;border-radius:12px!important;padding:16px!important;margin:0 0 16px!important;box-shadow:0 1px 3px rgba(16,36,62,.15)}
.dash-bw .fr .frFilters::before,.dash-bw .trend .ctl::before,.dash-bw .fr .frStrip::before,.dash-bw .trend .tiles::before,.dash-bw .dv .dvBox h4{font-size:15px!important;font-weight:700!important;letter-spacing:.01em!important;margin:0 0 12px!important}
.dash-bw .fr .frStrip::before,.dash-bw .trend .tiles::before{content:'Filtered results'!important}
.dash-bw .dv .dvTop > .dvBox:not(.fil) h4::before,.dash-bw .dv .dvTop > .dvBox:not(.fil) h4::after{content:''!important}
.dash-bw .fr .frFilters{display:grid!important;grid-template-columns:minmax(220px,1fr) auto auto auto;gap:12px!important;align-items:stretch}
.dash-bw .fr .frFilters .frG:last-child{grid-column:2/-1!important}
.dash-bw .fr .frG .seg button{padding-left:14px!important;padding-right:14px!important}
.dash-bw .fr .frCell,.dash-bw .dv .dvCard,.dash-bw .trend .tile{border:0!important}
.dash-bw .fr .frFilters::before{grid-column:1/-1}
.dash-bw .fr .frFilters .frG:last-child{grid-column:1/-1}
.dash-bw .fr .frG,.dash-bw .trend .ctlG{display:flex!important;flex-direction:column;align-items:stretch!important;gap:8px!important;padding:10px 12px!important;border-radius:10px!important;min-width:0}
.dash-bw .fr .frG .frL,.dash-bw .trend .ctl .ctlL{text-align:left!important;font-size:12px!important;font-weight:700!important;color:#33475F!important;text-transform:uppercase!important;letter-spacing:.05em!important}
.dash-bw .fr .frG .seg,.dash-bw .trend .ctlG .seg{display:flex!important;width:100%}
.dash-bw .fr .frG .seg button,.dash-bw .trend .ctlG .seg button{flex:1 1 0;justify-content:center;text-align:center;white-space:nowrap}
.dash-bw .fr .dp{min-width:0!important}
.dash-bw .fr > .frHint{margin:-4px 0 12px!important;font-size:13px}
.dash-bw .fr .frStrip{gap:12px!important}
.dash-bw .fr .frCell,.dash-bw .dv .dvCard,.dash-bw .trend .tile{border:0!important;border-radius:10px!important;padding:14px 12px!important;min-height:0!important}
.dash-bw .fr .frCell .l,.dash-bw .dv .dvCard .l,.dash-bw .trend .tile .tl{font-size:13px!important;font-weight:600!important;color:#33475F!important;text-transform:uppercase!important;letter-spacing:.04em!important}
.dash-bw .fr .frCell .v,.dash-bw .dv .dvCard .v,.dash-bw .trend .tile .tv{font-size:28px!important;margin-top:6px!important}
.dash-bw .dv .dvCards{gap:12px!important}
.dash-bw .dv .dvF{border-radius:10px!important;padding:10px 12px!important;gap:12px!important}
.dash-bw .trend .ctl{display:grid!important;grid-template-columns:2.2fr 2.4fr 1fr;gap:12px!important}
.dash-bw .trend .ctl::before{grid-column:1/-1}
.dash-bw .trend .ctlRow{flex-wrap:wrap;gap:8px}
.dash-bw .panel:not(.fr):not(.trend):not(.dv){background:#fff!important;border:1px solid #9FB7C8!important;border-radius:12px!important;box-shadow:0 1px 3px rgba(16,36,62,.10)!important;padding:18px 20px!important;margin-top:16px!important}
.dash-bw .panel:not(.fr):not(.trend):not(.dv) .chart{border:0;box-shadow:none;padding:0}
.dash-bw .cmpBar{min-width:52px;box-sizing:border-box}
.edrms-report .dash-bw .seg button.on,.edrms-report .dash-bw .seg button[aria-pressed="true"]{background:#FFC000!important;color:#10243E!important;font-weight:700!important;border-color:#FFC000!important;box-shadow:none!important;outline:0!important}
.edrms-report .dash-bw .seg button:not(.on):hover{background:#FFF4CC!important}
.dash-bw .cmpR > .cmpTrack:nth-child(2) .cmpBar{color:#10243E!important}
.dash-bw .cmpTrack{background:#E8EEF3!important}
.dash-bw .sgWrap .sgGroupBar{background:#1B5E80;border-radius:12px 12px 0 0;padding:14px 16px 10px;margin:8px 0 0!important;flex-wrap:wrap;row-gap:10px}
.dash-bw .sgWrap .sgGroupBar::before{content:'Filters';flex:0 0 100%;color:#fff;font-size:15px;font-weight:700}
.dash-bw .sgWrap .sgGroupBar .ctlL{color:#fff!important;font-weight:700}
.dash-bw .sgWrap .sgGroupBar .seg{background:#fff;border-radius:8px}
.dash-bw .sgWrap .sgGroupBar .sgLink{color:#fff!important;font-weight:600}
.dash-bw .sgWrap .toolbar{background:#1B5E80;border-radius:0 0 12px 12px;padding:6px 16px 16px;margin:0 0 14px!important}
.dash-bw .sgWrap .toolbar .search,.dash-bw .sgWrap .toolbar .fBtn,.dash-bw .sgWrap .toolbar .xpBtn{background:#fff}
.dash-bw .sgTbl th{background:#1B5E80!important;color:#fff!important}
.dash-bw .chart{background:#fff;border:1px solid #9FB7C8;border-radius:12px;padding:16px 18px 10px;box-shadow:0 1px 3px rgba(16,36,62,.10);margin-top:4px}
.dash-bw .chart .chartTitle{font-size:15px;font-weight:700;color:#10243E;margin-bottom:6px}
.dash-bw .chart .legend{margin:0 0 6px!important}
.dash-bw .trend > .legend,.dash-bw .panel > .legend{background:#fff;border:1px solid #9FB7C8;border-bottom:0;border-radius:12px 12px 0 0;padding:14px 18px 4px;margin:0!important}
.dash-bw .trend > .legend + .chart,.dash-bw .panel > .legend + .chart{border-top:0;border-radius:0 0 12px 12px;margin-top:0}
.dash-bw .band{padding-top:12px!important;padding-bottom:12px!important}
.dash-bw .kpis{gap:12px!important;margin-bottom:0!important}
.dash-bw .kpi{padding:10px 14px!important}
.dash-bw .kpi .val{font-size:24px!important;margin-top:2px!important}
.dash-bw .kpi .tap{margin-top:2px!important}
.dash-bw .panel.fr{margin-top:12px!important}
.dash-bw .fr .frFilters{display:flex!important;flex-wrap:wrap;align-items:center;gap:8px!important;padding:10px 12px!important;margin-bottom:10px!important}
.dash-bw .fr .frFilters::before{content:'Filters'!important;width:auto!important;flex:0 0 auto;margin:0 6px 0 2px!important;font-size:14px!important}
.dash-bw .fr .frG{flex-direction:row!important;align-items:center!important;gap:8px!important;padding:5px 8px!important;flex:0 0 auto}
.dash-bw .fr .frFilters .frG:first-of-type{flex:1 1 200px}
.dash-bw .fr .frFilters .frG:last-child{grid-column:auto!important}
.dash-bw .fr .frG .frL{white-space:nowrap;font-size:11px!important}
.dash-bw .fr .frG .seg{width:auto!important}
.dash-bw .fr .frG .seg button{flex:0 0 auto!important;padding:4px 10px!important;font-size:13px!important}
.dash-bw .fr .dp input[type=search]{height:30px!important}
.dash-bw .fr > .frHint{display:none!important}
.dash-bw .fr .frFilters{gap:6px 0!important;padding:12px 16px!important}
.dash-bw .fr .frFilters::before{margin-right:18px!important;font-size:13px!important;letter-spacing:.06em!important;text-transform:uppercase;color:#CFE3EF!important}
.dash-bw .fr .frG{background:transparent!important;padding:2px 18px!important;border-radius:0!important;border-left:1px solid rgba(255,255,255,.22)}
.dash-bw .fr .frFilters .frG:first-of-type{border-left:0;padding-left:0!important;flex:0 1 260px}
.dash-bw .fr .frFilters .frG .frL,.edrms-report .dash-bw .fr .frFilters .frG span.frL{color:#E3EFF7!important;font-size:12px!important;font-weight:600!important;letter-spacing:.04em!important;text-transform:none!important}
.dash-bw .fr .frG .seg{background:#fff;border-radius:7px;overflow:hidden;box-shadow:none}
.dash-bw .fr .frG .seg button{border:0!important;font-size:12.5px!important;color:#33475F}
.dash-bw .fr .frG .seg button.on{background:#FFC000!important;color:#10243E!important;font-weight:700}
.dash-bw .fr .dp input[type=search]{border:0!important;border-radius:7px!important}
.dash-bw .fr .frFilters{display:grid!important;grid-template-columns:auto repeat(3,minmax(0,1fr));column-gap:28px!important;row-gap:10px!important;align-items:center}
.dash-bw .fr .frFilters::before{grid-column:1!important;grid-row:1/3!important;align-self:center;margin-right:0!important}
.dash-bw .fr .frFilters .frG,.dash-bw .fr .frFilters .frG:first-of-type,.dash-bw .fr .frFilters .frG:last-child{display:grid!important;grid-template-columns:104px minmax(0,1fr);align-items:center;gap:10px!important;padding:0!important;border:0!important;flex:none!important;grid-column:auto!important;min-width:0}
.dash-bw .fr .frG .seg{display:flex!important;width:100%!important}
.dash-bw .fr .frG .seg button{flex:1 1 0!important;padding:5px 6px!important;white-space:nowrap}
.dash-bw .fr .frG .dp{width:100%}
.dash-bw .fr .frFilters{grid-template-columns:auto minmax(0,1fr) minmax(0,1.05fr) minmax(0,1.35fr)!important;column-gap:22px!important}
.dash-bw .fr .frFilters .frG,.dash-bw .fr .frFilters .frG:first-of-type,.dash-bw .fr .frFilters .frG:last-child{grid-template-columns:92px minmax(0,1fr)!important}
.dash-bw .fr .frG .seg button{font-size:12px!important;padding:5px 4px!important}
.edrms-report .dash-bw.inBreakdown .band{padding-top:8px!important;padding-bottom:8px!important}
.edrms-report .dash-bw.inBreakdown .band .bd{display:none}
.edrms-report .dash-bw.inBreakdown .kpi{padding:8px 14px!important;flex-direction:row!important;align-items:center!important;justify-content:space-between;gap:10px;min-height:0!important}
.edrms-report .dash-bw.inBreakdown .kpi .lab{font-size:13px!important;flex:1 1 auto!important;min-height:0!important;line-height:1.2!important}
.edrms-report .dash-bw.inBreakdown .kpi .val{font-size:20px!important;margin:0!important;padding:0!important}
.edrms-report .dash-bw.inBreakdown .kpi .tap{display:none!important}
.edrms-report .dash-bw.inBreakdown .kpi .infoWrap{display:block!important;position:static!important;order:3;flex:0 0 auto;margin-left:4px}
.edrms-report .dash-bw.inBreakdown .kpi .lab{align-self:center}
.edrms-report .dash-bw.inBreakdown .kpi .val{order:2}
.edrms-report .dash-bw.inBreakdown > .btn{margin:6px 0 2px!important;padding:3px 10px!important;font-size:12px!important}
.edrms-report .dash-bw.inBreakdown .dv .ptitle{margin-top:2px!important;font-size:16px!important}
.edrms-report .dash-bw.inBreakdown .dv .dvTbl td{padding:3px 12px!important;font-size:13px!important;line-height:1.35!important}
.edrms-report .dash-bw.inBreakdown .dv .dvTop > .dvBox:not(.fil){display:flex!important;align-items:center;gap:12px;padding:6px 10px!important}
.edrms-report .dash-bw.inBreakdown .dv .dvTop > .dvBox:not(.fil) h4{margin:0!important;white-space:nowrap;flex:0 0 auto}
.edrms-report .dash-bw.inBreakdown .dv .dvTop > .dvBox:not(.fil) .dvCards{flex:1 1 auto}
.edrms-report .dash-bw.inBreakdown .dv .dvCard{padding:6px 12px!important}
.edrms-report .dash-bw.inBreakdown .dv .dvBox.fil{padding:6px 10px!important}
.edrms-report .dash-bw.inBreakdown .dv .dvSub{display:none}
.edrms-report .dash-bw.inBreakdown .dv .dvTbl th{padding:7px 12px!important;font-size:13px!important}
.edrms-report .dash-bw.inBreakdown .dv .dvTbl td.site small{display:none}
.edrms-report .dash-bw .dv .dvSub{margin:0 0 6px!important}
.edrms-report .dash-bw .dv .dvTop{gap:8px!important;margin:4px 0 8px!important}
.edrms-report .dash-bw .dv .dvBox{padding:8px 12px!important;margin:0!important}
.edrms-report .dash-bw .dv .dvBox h4{font-size:14px!important;margin:0 0 6px!important}
.edrms-report .dash-bw .dv .dvBox.fil h4{display:none!important}
.edrms-report .dash-bw .dv .dvF{padding:6px 10px!important}
.edrms-report .dash-bw .dv .dvCards{grid-template-columns:repeat(auto-fit,minmax(0,1fr))!important;grid-auto-flow:column;gap:8px!important}
.edrms-report .dash-bw .dv .dvCard{display:flex!important;flex-direction:row!important;align-items:center!important;justify-content:space-between!important;gap:8px;padding:8px 12px!important;text-align:left!important}
.edrms-report .dash-bw .dv .dvCard .infoWrap{position:static!important;order:3}
.edrms-report .dash-bw .dv .dvCard .l{min-height:0!important;display:block!important;font-size:13px!important;text-align:left!important;flex:1 1 auto;line-height:1.2!important}
.edrms-report .dash-bw .dv .dvCard .v{font-size:20px!important;margin:0!important;white-space:nowrap}
.edrms-report .dash-bw .dv .dvTblWrap{overflow:auto;border-radius:8px}
.edrms-report .dash-bw .dv .dvTbl thead{position:sticky;top:0;z-index:2}
.edrms-report .dash-bw .dv .dvTbl td{padding:6px 12px!important}
.edrms-report .dash-bw .fr .frStrip{grid-template-columns:repeat(5,minmax(0,1fr))!important;row-gap:8px!important}
.edrms-report .dash-bw .fr .frStrip::before{grid-column:1/-1!important;margin:0!important}
.edrms-report .dash-bw .fr .frCell{display:flex!important;flex-direction:row!important;align-items:center!important;justify-content:flex-start!important;padding:8px 12px!important;gap:8px!important;min-width:0}
.edrms-report .dash-bw .fr .frCell .infoWrap{position:static!important;transform:none!important;order:3;flex:0 0 auto;display:block!important}
.edrms-report .dash-bw .fr .frCell .l{order:1;flex:1 1 auto;text-align:left!important;font-size:13px!important;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0;padding:0!important}
.edrms-report .dash-bw .fr .frCell .v{order:2;font-size:20px!important;white-space:nowrap;margin:0!important}
.dash-bw .fr .frCell{align-items:center!important;padding:8px 30px 8px 14px!important;position:relative}
.dash-bw .fr .frCell .infoWrap{display:block!important;position:absolute;top:50%!important;right:8px!important;transform:translateY(-50%)}
.dash-bw .fr .frCell .l{font-size:13px!important;line-height:1!important}
.dash-bw .fr .frCell .v{line-height:1!important}
.dash-bw .fr .frStrip{grid-template-columns:auto repeat(5,minmax(0,1fr))!important;align-items:center;padding:10px 12px!important;gap:10px!important;margin-bottom:10px!important}
.dash-bw .fr .frStrip::before{grid-column:auto!important;margin:0 6px 0 2px!important;font-size:14px!important;white-space:nowrap}
.dash-bw .fr .frCell{padding:8px 10px!important;flex-direction:row!important;justify-content:space-between!important;align-items:baseline!important;gap:8px}
.dash-bw .fr .frCell .l{font-size:12px!important;padding:0!important}
.dash-bw .fr .frCell .v{font-size:20px!important;margin:0!important}
.dash-bw .fr .frCell .infoWrap{display:none}
.dash-bw .fr .chart{padding:10px 14px 4px!important}
.dash-bw .fr .chart .chartTitle{font-size:14px!important;margin-bottom:2px!important;display:inline-block;margin-right:16px}
.dash-bw .fr .chart .legend{display:inline-flex!important}
@media (max-width:1100px){.dash-bw .fr .frFilters,.dash-bw .trend .ctl{grid-template-columns:1fr 1fr}}
.dash-bw .fr .frCell,.dash-bw .dv .dvCard,.dash-bw .trend .tile{background:#fff!important;border:2px solid #0E3A52!important;border-radius:16px!important;box-shadow:none!important;padding:12px 12px!important;text-align:center!important}
.dash-bw .fr .frCell .l,.dash-bw .dv .dvCard .l,.dash-bw .trend .tile .tl{font-size:15px!important;font-weight:600!important;color:#10243E!important;padding:0 8px!important;text-transform:none!important;letter-spacing:0!important}
.dash-bw .fr .frCell .v,.dash-bw .dv .dvCard .v,.dash-bw .trend .tile .tv{font-size:24px!important;font-weight:700!important;color:#10243E!important}
.dash-bw .fr .frFilters{display:flex;flex-wrap:wrap;gap:8px;align-content:flex-start}
.dash-bw .fr .frG,.dash-bw .trend .ctlG,.dash-bw .dv .dvF{background:#fff;border-radius:12px;padding:8px 10px;align-items:center}
.dash-bw .fr .frG .frL,.dash-bw .trend .ctl .ctlL{color:#10243E!important;font-size:14px!important;font-weight:700!important;text-transform:none!important;letter-spacing:0!important;text-align:center}
.dash-bw .dv .dvF{flex-direction:row}
.dash-bw .dv .dvF .ctlL{color:#10243E!important;font-size:13px!important;font-weight:700!important;text-transform:none!important;letter-spacing:0!important}
.dash-bw .trend .ctl{display:flex;flex-wrap:wrap;gap:8px;align-content:flex-start}
.dash-bw .trend .ctl .lbl{color:#10243E!important}
.dash-bw .trend .tiles{grid-template-columns:minmax(0,1fr)!important;align-content:start}
.dash-bw .dv .dvTbl th{background:#1B5E80!important}
.dash-bw .dv .dvTbl thead tr.sub th{background:#D6E8F4!important;color:#10243E!important;font-weight:700!important;border-top:2px solid #fff}
.dash-bw .dv .dvCards{align-items:stretch!important}
.dash-bw .dv .dvCard,.dash-bw .fr .frCell{display:flex!important;flex-direction:column;justify-content:space-between;align-items:center}
.dash-bw .dv .dvCard .l{min-height:2.6em;display:flex;align-items:center;justify-content:center;line-height:1.3!important}
.dash-bw .dv .dvCard .v{margin-top:6px!important}
`;
const CSS2 = '.dash-bw .kpis{grid-template-columns:repeat(5,minmax(0,1fr))!important}.dash-bw .kpi{display:flex!important;flex-direction:column;align-items:flex-start;height:auto!important;min-height:0!important;padding:8px 14px!important;gap:0}.dash-bw .kpi .lab{padding-right:20px;font-size:15px!important;font-weight:600!important;color:#10243E!important;line-height:1.25;flex:1 1 auto}.dash-bw .kpi .val{position:static!important;margin:2px 0 0!important;font-size:26px!important;line-height:1.1;text-align:left!important}.dash-bw .kpi .tap{position:static!important;margin-top:2px!important;font-size:13px!important;text-align:left!important}.dash-bw .tile{padding:10px 14px!important;min-height:0!important}.dash-bw .tile .tl{font-size:14px!important;font-weight:600;color:#33475F!important}.dash-bw .tile .tv{font-size:26px!important}.fr .frCell{padding:8px 12px}.fr .frCell .l{font-size:14px;font-weight:600;color:#33475F}.fr .frCell .v{font-size:24px}@media (max-width:900px){.dash-bw .kpis{grid-template-columns:repeat(2,minmax(0,1fr))!important}}';

export const BankWide: React.FC<IDashboardProps> = ({ data, openDept, bandTools }) => {
  const depts = data.depts;
  /* RAC review 23 Nov 2026 (EDRMS_Dashboard.pptx): five fixed cards on top, a
     "Filtered results" section under them, and each card's "View breakdown" opens its
     own view with a "Back to Bank-wide Overview" button. Labels carry no "Total". */
  const [open, setOpen] = React.useState<string>('home');
  /* Sample: the share of listed sites idle for more than 180 days. */
  const idleShare = React.useMemo(() => {
    const listed = Object.keys(data.sites || {}).reduce((a, k) => a.concat(data.sites[k]), [] as { idle: number }[]);
    return listed.length ? listed.filter(s => s.idle > 180).length / listed.length : 0;
  }, [data]);
  const totals = {
    sites: sum(depts, d => d.sites),
    head: roundedHead(depts),
    docs: sum(depts, d => d.docs),
    rec: sum(depts, d => d.rec),
    phys: sum(depts, d => d.phys)
  };
  const kpis: IKpi[] = [
    { key: 'sites', label: 'EDRMS Sites', value: F(totals.sites), info: 'EDRMS sites, compliant in Cloud Governance' },
    { key: 'users', label: 'ADB Users', value: isMissing('head') ? NOT_SOURCED : F(totals.head), info: 'Internal ADB users only: approximate headcount derived by BPMSD' },
    { key: 'docs', label: 'Documents in EDRMS', value: F(totals.docs), info: 'All files on EDRMS sites' },
    { key: 'rec', label: 'Records Declared in EDRMS', value: F(totals.rec), info: 'Declared as records via EDRMS' },
    { key: 'phys', label: 'Physical Records Identified in EDRMS', value: F(totals.phys), info: 'Declared records that also exist on paper' }
  ];
  const back = (
    <button type="button" className="btn" style={{ margin: '4px 0 10px' }} onClick={() => setOpen('home')}>
      &#8249; Back to Bank-wide Overview
    </button>
  );

  return (
    <div className={'dash-bw' + (open !== 'home' ? ' inBreakdown' : '')}>
      <style>{CSS}</style>
      <style>{CSS2}</style>
      <Band title="Bank-wide Oversight" text="EDRMS adoption across ADB: sites, users, documents, declared records and physical records" tools={bandTools} />
      <KpiRow items={kpis} open={open} onOpen={k => setOpen(k === open ? 'home' : k)} />
      {open !== 'home' && back}
      {open === 'sites' && <SitesView depts={depts} openDept={openDept} idleShare={idleShare} />}
      {open === 'users' && <UsersView depts={depts} openDept={openDept} />}
      {open === 'docs' && <DocumentsView depts={depts} openDept={openDept} />}
      {open === 'rec' && <RecordsView depts={depts} openDept={openDept} />}
      {open === 'phys' && <PhysicalView depts={depts} openDept={openDept} />}
      {open === 'home' && <FilteredResults data={data} openDept={openDept} />}
    </div>
  );
};
