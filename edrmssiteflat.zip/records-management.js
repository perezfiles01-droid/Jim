/* ===================================================================
   Records Management
   Source: EDRMS_Records_Management_Dashboard_v3.html
   =================================================================== */
DASHBOARDS.rm=(function(){
  function split(total,k,seed){
    const w=[];let s=0;for(let i=0;i<k;i++){const x=((seed*(i+3)*7919)%100)/100*0.6+0.55;w.push(x);s+=x;}
    const out=w.map(x=>Math.max(1,Math.round(total*x/s)));
    out[0]+=total-out.reduce((a,b)=>a+b,0);if(out[0]<1)out[0]=1;return out;
  }
  function monthly(total,seed){
    const w=[];for(let m=0;m<12;m++)w.push(0.6+m*0.08+((seed*(m+1))%5)*0.05);
    const s=w.reduce((a,b)=>a+b,0);const out=w.map(x=>Math.round(total*x/s));
    out[11]+=total-out.reduce((a,b)=>a+b,0);return out;
  }
  /* --- pager: this variant hides itself entirely on a single page --- */
  function pager(total,page,pages,noun){
    if(pages<=1)return "";
    const win=[];for(let p=1;p<=pages;p++){if(p===1||p===pages||Math.abs(p-page)<=1)win.push(p);}
    let nums="",last=0;win.forEach(p=>{if(last&&p-last>1)nums+=`<span style="color:var(--mut)">…</span>`;nums+=`<button class="${p===page?'on':''}" data-pg="${p}">${p}</button>`;last=p;});
    const from=(page-1)*10+1,to=Math.min(total,page*10);
    return `<div class="pager"><div class="pinfo">Showing ${from} to ${to} of ${F(total)} ${noun}</div>
      <div class="pbtns"><button data-pg="prev" ${page===1?'disabled':''}>‹ Prev</button>${nums}<button data-pg="next" ${page===pages?'disabled':''}>Next ›</button></div></div>`;
  }

  /* ===== departments (16) ===== */
  const DEPTS=[
   {c:"ITD",n:"Information Technology",rec:2611,phys:470,docs:640000},
   {c:"SARD",n:"South Asia Regional",rec:2240,phys:360,docs:520000},
   {c:"OSFG",n:"Sovereign Operations",rec:2168,phys:300,docs:410000},
   {c:"FIN",n:"Finance",rec:2150,phys:520,docs:300000},
   {c:"PARD",n:"Procurement & Admin",rec:1892,phys:410,docs:290000},
   {c:"HRD",n:"Human Resources",rec:1462,phys:240,docs:205000},
   {c:"SERD",n:"Southeast Asia",rec:1320,phys:180,docs:150000},
   {c:"EARD",n:"East Asia Regional",rec:1180,phys:150,docs:120000},
   {c:"OGC",n:"General Counsel",rec:1074,phys:210,docs:100000},
   {c:"CWRD",n:"Central & West Asia",rec:1150,phys:210,docs:180000},
   {c:"PSOD",n:"Private Sector Operations",rec:980,phys:260,docs:140000},
   {c:"BRM",n:"Budget & Mgmt Services",rec:809,phys:90,docs:70000},
   {c:"SPD",n:"Strategy & Policy",rec:760,phys:120,docs:95000},
   {c:"SDCC",n:"Sustainable Dev & Climate",rec:690,phys:110,docs:88000},
   {c:"OAS",n:"Administrative Services",rec:620,phys:130,docs:105000},
   {c:"ERCD",n:"Economic Research",rec:540,phys:70,docs:60000},
  ];
  DEPTS.forEach((d,i)=>{d.mrec=monthly(d.rec,d.c.length+i+1);d.mphys=monthly(d.phys,d.c.length+i+2);d.mdocs=monthly(d.docs,d.c.length+i+3);});
  const ANNUAL_REC=DEPTS.reduce((a,d)=>a+d.rec,0);
  const ANNUAL_DOCS=DEPTS.reduce((a,d)=>a+d.docs,0);

  const DIVNAMES={ITD:["Digital Services","Infrastructure & Operations"],SARD:["South Asia Operations","South Asia Programs"],
   OSFG:["Country Operations","Safeguards"],FIN:["Treasury","Financial Control"],PARD:["Procurement","Administration"],
   HRD:["People Operations","Talent & Learning"],SERD:["Southeast Asia Operations"],EARD:["East Asia Operations"],
   OGC:["Legal Advisory","Compliance"],CWRD:["Central Asia Operations","West Asia Operations"],PSOD:["Investments","Portfolio Management"],
   BRM:["Budget Operations"],SPD:["Strategy","Partnerships"],SDCC:["Climate Change","Sustainable Development"],
   OAS:["Facilities","Administration"],ERCD:["Macroeconomics","Statistics"]};
  const LIBPOOL=["Final Documents","Board Papers","Loan Agreements","Country Reports","Policies","Correspondence","Minutes","Project Completion"];

  const TREE=DEPTS.map(d=>{
    const divs=DIVNAMES[d.c];
    const dr=split(d.rec,divs.length,d.c.length+1),dp=split(d.phys,divs.length,d.c.length+2),dd=split(d.docs,divs.length,d.c.length+3);
    const children=divs.map((dv,i)=>{
      const short=dv.split(" ")[0];
      const siteNames=[`${d.c} ${short} Site`,`${d.c} ${short} Annex`];
      const sr=split(dr[i],2,i+3),sp=split(dp[i],2,i+4),sd=split(dd[i],2,i+5);
      const sites=siteNames.map((sn,j)=>{
        const libNames=[LIBPOOL[(i+j)%LIBPOOL.length],LIBPOOL[(i+j+3)%LIBPOOL.length]];
        const lr=split(sr[j],2,j+6),lp=split(sp[j],2,j+7),ld=split(sd[j],2,j+8);
        const libs=libNames.map((ln,k)=>({label:ln,site:sn,rec:lr[k],phys:lp[k],docs:ld[k]}));
        return {label:sn,sub:`${d.c} · ${dv}`,rec:sr[j],phys:sp[j],docs:sd[j],children:libs};
      });
      return {label:dv,sub:d.c,rec:dr[i],phys:dp[i],docs:dd[i],children:sites};
    });
    return {label:d.c,sub:d.n,rec:d.rec,phys:d.phys,docs:d.docs,children};
  });
  const LEVELS=["Department","Division","Site","Library"];
  function listAt(path){let lvl=TREE;for(const idx of path)lvl=lvl[idx].children;return lvl;}
  function crumbHTML(path){let lvl=TREE,html=`<a data-i="-1">All departments</a>`;
    path.forEach((idx,i)=>{html+=`<span class="arw">›</span><a data-i="${i}">${lvl[idx].label}</a>`;lvl=lvl[idx].children;});
    html+=`<span class="arw">·</span><span class="cur">${LEVELS[path.length]} level</span>`;return html;}

  /* ===== section 1 ===== */
  let pathRec=[],pageRec=1,pathDocs=[],pageDocs=1;
  let curS1="rec";
  function renderS1(which){
    curS1=which;
    document.querySelectorAll("#s1-kpis .kpi").forEach(k=>k.classList.toggle("on",k.dataset.k===which));
    const box=document.getElementById("s1-detail");
    if(which==="rec"){
      box.innerHTML=`<div class="panel">
        <div class="ptitle">Total Declared Records</div>
        <div class="psub">Declared records per department, split into those with and without a physical counterpart. Click a bar to drill down from department to division to site to library.</div>
        <div class="daterow">
          <div class="drill" id="rec-crumb" style="margin:0"></div>
          <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
            <div class="drange">Date range
              <input type="date" id="rec-s"> to
              <input type="date" id="rec-e"></div>
            <button id="rec-reset" class="resetbtn">↺ Reset filter</button>
          </div>
        </div>
        <div class="subtotal" id="rec-subtotal" style="margin-bottom:12px"></div>
        <div class="legend"><span class="lg"><span class="sw" style="background:var(--greyblue)"></span>Without physical counterpart</span><span class="lg"><span class="sw" style="background:var(--teal)"></span>With physical counterpart</span></div>
        <div id="rec-bars"></div><div id="rec-pager"></div></div>`;
      document.getElementById("rec-s").onchange=()=>{pageRec=1;drawRec();};
      document.getElementById("rec-e").onchange=()=>{pageRec=1;drawRec();};
      document.getElementById("rec-reset").onclick=()=>{
        document.getElementById("rec-s").value="";
        document.getElementById("rec-e").value="";
        pathRec=[];pageRec=1;drawRec();
      };
      drawRec();
    }else{
      box.innerHTML=`<div class="panel">
        <div class="ptitle">Total Documents in EDRMS Compliant Sites</div>
        <div class="psub">Total documents held in each department's EDRMS compliant sites. Click a bar to drill down from department to division to site to library.</div>
        <div class="daterow">
          <div class="drill" id="docs-crumb" style="margin:0"></div>
          <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
            <div class="drange">Date range
              <input type="date" id="docs-s"> to
              <input type="date" id="docs-e"></div>
            <button id="docs-reset" class="resetbtn">↺ Reset filter</button>
          </div>
        </div>
        <div class="subtotal" id="docs-subtotal" style="margin-bottom:12px"></div>
        <div id="docs-bars"></div><div id="docs-pager"></div></div>`;
      document.getElementById("docs-s").onchange=()=>{pageDocs=1;drawDocs();};
      document.getElementById("docs-e").onchange=()=>{pageDocs=1;drawDocs();};
      document.getElementById("docs-reset").onclick=()=>{
        document.getElementById("docs-s").value="";
        document.getElementById("docs-e").value="";
        pathDocs=[];pageDocs=1;drawDocs();
      };
      drawDocs();
    }
  }
  function rangeMonthsFor(sId,eId){
    const sEl=document.getElementById(sId),eEl=document.getElementById(eId);
    if(!sEl||!eEl)return [0,11];
    const s=new Date(sEl.value+"T00:00:00"),e=new Date(eEl.value+"T00:00:00");
    let sM=isNaN(s)?0:(s.getFullYear()<2026?0:s.getFullYear()>2026?12:s.getMonth());
    let eM=isNaN(e)?11:(e.getFullYear()>2026?11:e.getFullYear()<2026?-1:e.getMonth());
    return [sM,eM];
  }
  function rangeMonths(){return rangeMonthsFor("rec-s","rec-e");}
  /* the range summary line shows only while a date range is actually applied */
  function paintSubtotal(id,blank,full,text){
    const el=document.getElementById(id);
    if(!el)return;
    if(blank||full){el.innerHTML="";el.style.display="none";}
    else{el.innerHTML=text;el.style.display="";}
  }
  function sumMonths(arr,sM,eM){let t=0;for(let m=Math.max(0,sM);m<=Math.min(11,eM);m++)t+=arr[m];return t;}
  function drawRec(){
    const [sM,eM]=rangeMonths();
    const canDrill=pathRec.length<3,atLib=pathRec.length===3;
    document.getElementById("rec-crumb").innerHTML=crumbHTML(pathRec);
    document.querySelectorAll("#rec-crumb a").forEach(a=>a.onclick=()=>{const i=+a.dataset.i;pathRec=i<0?[]:pathRec.slice(0,i+1);pageRec=1;drawRec();});
    let rows;
    if(pathRec.length===0){
      rows=DEPTS.map((d,i)=>({label:d.c,sub:d.n,i,rec:sumMonths(d.mrec,sM,eM),phys:sumMonths(d.mphys,sM,eM)}));
    }else{
      const dd=DEPTS[pathRec[0]];
      const recF=dd.rec?sumMonths(dd.mrec,sM,eM)/dd.rec:0, physF=dd.phys?sumMonths(dd.mphys,sM,eM)/dd.phys:0;
      rows=listAt(pathRec).map((r,i)=>({...r,i,rec:Math.round(r.rec*recF),phys:Math.round(r.phys*physF)}));
    }
    rows=rows.map(r=>({...r,elec:r.rec-r.phys})).sort((a,b)=>b.rec-a.rec);
    const rangeTotal=DEPTS.reduce((a,d)=>a+sumMonths(d.mrec,sM,eM),0);
    const full=(sM<=0&&eM>=11);
    const sVal=(document.getElementById("rec-s")||{}).value||"";
    const eVal=(document.getElementById("rec-e")||{}).value||"";
    const blank=(sVal===""&&eVal==="");
    paintSubtotal("rec-subtotal",blank,full,
      `Declared in selected range: <b>${F(rangeTotal)}</b> of ${F(ANNUAL_REC)} total.`);
    const mx=Math.max(...rows.map(r=>r.rec),1);
    const pages=Math.max(1,Math.ceil(rows.length/10));if(pageRec>pages)pageRec=pages;
    const pg=rows.slice((pageRec-1)*10,pageRec*10);
    document.getElementById("rec-bars").innerHTML=pg.map(r=>{
      const w=100*r.rec/mx,we=r.rec?r.elec/r.rec*w:0,wp=r.rec?r.phys/r.rec*w:0;
      const sub=atLib?`in ${r.site}`:(r.sub||"");
      return `<div class="sbar ${canDrill?'click':''}" data-i="${r.i}"><div class="sl"><b>${r.label}</b>${sub?`<small>${sub}</small>`:""}</div>
        <div class="st"><div class="seg e" style="width:${we}%" title="Without physical: ${F(r.elec)}">${r.elec>110?F(r.elec):""}</div><div class="seg p" style="width:${wp}%" title="With physical: ${F(r.phys)}">${r.phys>70?F(r.phys):""}</div></div>
        <div class="sv">${F(r.rec)}</div></div>`;}).join("");
    if(canDrill)document.querySelectorAll("#rec-bars .sbar.click").forEach(b=>b.onclick=()=>{pathRec=[...pathRec,+b.dataset.i];pageRec=1;drawRec();});
    document.getElementById("rec-pager").innerHTML=pager(rows.length,pageRec,pages,LEVELS[pathRec.length].toLowerCase()+"s");
    wirePager("#rec-pager",v=>{pageRec=v==="prev"?Math.max(1,pageRec-1):v==="next"?Math.min(pages,pageRec+1):+v;drawRec();});
  }
  function drawDocs(){
    const [sM,eM]=rangeMonthsFor("docs-s","docs-e");
    const canDrill=pathDocs.length<3,atLib=pathDocs.length===3;
    document.getElementById("docs-crumb").innerHTML=crumbHTML(pathDocs);
    document.querySelectorAll("#docs-crumb a").forEach(a=>a.onclick=()=>{const i=+a.dataset.i;pathDocs=i<0?[]:pathDocs.slice(0,i+1);pageDocs=1;drawDocs();});
    let rows;
    if(pathDocs.length===0){
      rows=DEPTS.map((d,i)=>({label:d.c,sub:d.n,i,docs:sumMonths(d.mdocs,sM,eM)}));
    }else{
      const dd=DEPTS[pathDocs[0]];
      const docsF=dd.docs?sumMonths(dd.mdocs,sM,eM)/dd.docs:0;
      rows=listAt(pathDocs).map((r,i)=>({...r,i,docs:Math.round(r.docs*docsF)}));
    }
    rows.sort((a,b)=>b.docs-a.docs);
    const rangeTotal=DEPTS.reduce((a,d)=>a+sumMonths(d.mdocs,sM,eM),0);
    const full=(sM<=0&&eM>=11);
    const sVal=(document.getElementById("docs-s")||{}).value||"";
    const eVal=(document.getElementById("docs-e")||{}).value||"";
    const blank=(sVal===""&&eVal==="");
    paintSubtotal("docs-subtotal",blank,full,
      `Documents in selected range: <b>${F(rangeTotal)}</b> of ${F(ANNUAL_DOCS)} total.`);
    const mx=Math.max(...rows.map(r=>r.docs),1);
    const pages=Math.max(1,Math.ceil(rows.length/10));if(pageDocs>pages)pageDocs=pages;
    const pg=rows.slice((pageDocs-1)*10,pageDocs*10);
    document.getElementById("docs-bars").innerHTML=pg.map(r=>{
      const sub=atLib?`in ${r.site}`:(r.sub||"");
      return `<div class="cbar" data-i="${r.i}" style="${canDrill?'cursor:pointer':''}"><div class="cl"><b>${r.label}</b>${sub?`<small>${sub}</small>`:""}</div>
        <div class="ct"><div class="cf" style="width:${Math.max(6,100*r.docs/mx)}%;background:var(--orange)">${F(r.docs)}</div></div></div>`;}).join("");
    if(canDrill)document.querySelectorAll("#docs-bars .cbar").forEach(b=>b.onclick=()=>{pathDocs=[...pathDocs,+b.dataset.i];pageDocs=1;drawDocs();});
    document.getElementById("docs-pager").innerHTML=pager(rows.length,pageDocs,pages,LEVELS[pathDocs.length].toLowerCase()+"s");
    wirePager("#docs-pager",v=>{pageDocs=v==="prev"?Math.max(1,pageDocs-1):v==="next"?Math.min(pages,pageDocs+1):+v;drawDocs();});
  }

  /* ===== sites / users usage ===== */
  const SITES=[];
  DEPTS.forEach((d,i)=>{
    const seed=d.c.length*7+i*13;
    const prim=(i%2===0)?"Records Site":"Workspace";
    SITES.push({dept:d.c,site:`${d.c} ${prim}`,base:Math.round(d.rec*0.95),last:(seed%7)+1});
    SITES.push({dept:d.c,site:`${d.c} Team Site`,base:Math.round(d.rec*0.5),last:(seed%22)+2});
    if(d.rec>1000)SITES.push({dept:d.c,site:`${d.c} Programs Hub`,base:Math.round(d.rec*0.35),last:(seed%60)+8});
    if(i%3===0)SITES.push({dept:d.c,site:`${d.c} Shared Drive (legacy)`,base:Math.round(d.rec*0.4),last:110+(seed%80)});
  });
  SITES.forEach(s=>{
    s.uv7=s.last<=7?Math.round(s.base*0.42):0;
    s.uv30=s.last<=30?s.base:0;
    s.v7=s.last<=7?Math.round(s.base*0.42*1.5):0;
    s.v30=s.last<=30?Math.round(s.base*1.5):0;
    s.v90=s.last<=90?Math.round(s.base*1.5*2.2):0;
  });

  let winSites=7,deptSites="all",pageSites=1,winUsers=7,deptUsers="all",pageUsers=1;
  let curS2="sites";
  function deptOptions(sel){return `<option value="all">All departments</option>`+DEPTS.map(d=>`<option value="${d.c}" ${sel===d.c?"selected":""}>${d.c} — ${d.n}</option>`).join("");}

  function renderS2(which){
    curS2=which;
    document.querySelectorAll("#s2-kpis .kpi").forEach(k=>k.classList.toggle("on",k.dataset.k===which));
    const box=document.getElementById("s2-detail");
    if(which==="sites"){
      box.innerHTML=`<div class="panel">
        <div class="ptitle">Active Departmental Sites</div>
        <div class="psub">Departmental sites with activity in the selected window, ranked by site visits, with each site's most recent activity.</div>
        <div class="toolbar">
          <div class="dayf" id="sites-win">${[7,30,90].map(dd=>`<button class="${winSites===dd?'on':''}" data-d="${dd}">Last ${dd} days</button>`).join("")}</div>
          <div class="ctl">Department<select id="sites-dept">${deptOptions(deptSites)}</select></div></div>
        <div class="statrow" id="sites-stats"></div>
        <div class="colhead"><span>Site</span><span class="c2">Site visits</span><span class="c3">Last activity</span></div>
        <div id="sites-bars"></div><div id="sites-pager"></div></div>`;
      document.querySelectorAll("#sites-win button").forEach(b=>b.onclick=()=>{winSites=+b.dataset.d;pageSites=1;renderS2("sites");});
      document.getElementById("sites-dept").onchange=e=>{deptSites=e.target.value;pageSites=1;drawSites();};
      drawSites();
    }else{
      box.innerHTML=`<div class="panel">
        <div class="ptitle">Active Users</div>
        <div class="psub">Unique viewers per site in the selected window, with each site's most recent activity.</div>
        <div class="toolbar">
          <div class="dayf" id="users-win">${[7,30,90].map(dd=>`<button class="${winUsers===dd?'on':''}" data-d="${dd}">Last ${dd} days</button>`).join("")}</div>
          <div class="ctl">Department<select id="users-dept">${deptOptions(deptUsers)}</select></div></div>
        <div class="statrow" id="users-stats"></div>
        <div class="colhead"><span>Site</span><span class="c2" id="users-metric-h">Unique viewers</span><span class="c3">Last activity</span></div>
        <div id="users-bars"></div><div id="users-note"></div><div id="users-pager"></div></div>`;
      document.querySelectorAll("#users-win button").forEach(b=>b.onclick=()=>{winUsers=+b.dataset.d;pageUsers=1;renderS2("users");});
      document.getElementById("users-dept").onchange=e=>{deptUsers=e.target.value;pageUsers=1;drawUsers();};
      drawUsers();
    }
  }
  function drawSites(){
    const vKey=s=>winSites===7?s.v7:winSites===30?s.v30:s.v90;
    let list=SITES.filter(s=>s.last<=winSites);
    if(deptSites!=="all")list=list.filter(s=>s.dept===deptSites);
    list=list.map(s=>({...s,v:vKey(s)})).sort((a,b)=>b.v-a.v);
    const visits=list.reduce((a,b)=>a+b.v,0);
    document.getElementById("sites-stats").innerHTML=`
      <div class="stat"><div class="sl">Active sites</div><div class="sv">${F(list.length)}</div></div>
      <div class="stat"><div class="sl">Total site visits</div><div class="sv">${F(visits)}</div></div>`;
    const mx=Math.max(...list.map(s=>s.v),1);
    const pages=Math.max(1,Math.ceil(list.length/10));if(pageSites>pages)pageSites=pages;
    const pg=list.slice((pageSites-1)*10,pageSites*10);
    document.getElementById("sites-bars").innerHTML=pg.map(s=>`<div class="cbar act"><div class="cl"><b>${s.site}</b><small>${s.dept}</small></div>
      <div class="ct"><div class="cf" style="width:${Math.max(6,100*s.v/mx)}%;background:var(--green)">${F(s.v)}</div></div>
      <div class="la">${s.last} day${s.last===1?"":"s"} ago</div></div>`).join("");
    document.getElementById("sites-pager").innerHTML=pager(list.length,pageSites,pages,"sites");
    wirePager("#sites-pager",v=>{pageSites=v==="prev"?Math.max(1,pageSites-1):v==="next"?Math.min(pages,pageSites+1):+v;drawSites();});
  }
  function drawUsers(){
    const at90=winUsers===90;
    const uvKey=s=>winUsers===7?s.uv7:winUsers===30?s.uv30:null;
    let list=SITES.filter(s=>s.last<=winUsers);
    if(deptUsers!=="all")list=list.filter(s=>s.dept===deptUsers);
    const metric=s=>at90?s.v90:uvKey(s);
    list=list.map(s=>({...s,m:metric(s)})).sort((a,b)=>b.m-a.m);
    document.getElementById("users-metric-h").textContent=at90?"Site visits":"Unique viewers";
    const totUV=list.reduce((a,b)=>a+(uvKey(b)||0),0);
    const totV=list.reduce((a,b)=>a+s90(b),0);
    function s90(x){return x.v90;}
    document.getElementById("users-stats").innerHTML= at90
      ? `<div class="stat"><div class="sl">Total site visits</div><div class="sv">${F(totV)}</div></div>`
      : `<div class="stat"><div class="sl">Total unique viewers</div><div class="sv">${F(totUV)}</div></div>`;
    const mx=Math.max(...list.map(s=>s.m),1);
    const pages=Math.max(1,Math.ceil(list.length/10));if(pageUsers>pages)pageUsers=pages;
    const pg=list.slice((pageUsers-1)*10,pageUsers*10);
    document.getElementById("users-bars").innerHTML=pg.map(s=>`<div class="cbar act"><div class="cl"><b>${s.site}</b><small>${s.dept}</small></div>
      <div class="ct"><div class="cf" style="width:${Math.max(6,100*s.m/mx)}%;background:var(--deepblue)">${F(s.m)}</div></div>
      <div class="la">${s.last} day${s.last===1?"":"s"} ago</div></div>`).join("");
    document.getElementById("users-note").innerHTML=at90
      ? `<div class="note">At 90 days SharePoint does not return a unique viewer total, so site visits are shown here. Switch to 7 or 30 days to see unique viewers.</div>`:"";
    document.getElementById("users-pager").innerHTML=pager(list.length,pageUsers,pages,"sites");
    wirePager("#users-pager",v=>{pageUsers=v==="prev"?Math.max(1,pageUsers-1):v==="next"?Math.min(pages,pageUsers+1):+v;drawUsers();});
  }

  const html=`<section class="dash-rm">
    <div class="band">
      <h2>Total Declared Records vs Total Documents in EDRMS Compliant Sites</h2>
      <div class="bd">See how much of the content stored in EDRMS compliant sites has been formally declared as an official record, and how that breaks down by department, division, site, and library.</div>
    </div>
    <div class="kpis" id="s1-kpis">
      <div class="kpi on" data-k="rec"><div class="lab">Total Declared Records</div><div class="val" id="kpi-rec">—</div><div class="tap">▾ Click to open</div></div>
      <div class="kpi" data-k="docs"><div class="lab">Total Documents in EDRMS Compliant Sites</div><div class="val" id="kpi-docs">—</div><div class="tap">▾ Click to open</div></div>
    </div>
    <div id="s1-detail"></div>

    <div class="band">
      <h2>SharePoint Sites and Users Governance</h2>
      <div class="bd">See which departmental sites and users are actively engaging with EDRMS, based on SharePoint usage over the last 7, 30, or 90 days.</div>
    </div>
    <div class="kpis" id="s2-kpis">
      <div class="kpi on" data-k="sites"><div class="lab">Active Departmental Sites</div><div class="val" id="kpi-sites">—</div><div class="tap">▾ Click to open</div></div>
      <div class="kpi" data-k="users"><div class="lab">Active Users</div><div class="val" id="kpi-users">—</div><div class="tap">▾ Click to open</div></div>
    </div>
    <div id="s2-detail"></div>
  </section>`;

  function init(){
    document.getElementById("kpi-rec").textContent=F(ANNUAL_REC);
    document.getElementById("kpi-docs").textContent=(ANNUAL_DOCS/1e6).toFixed(2)+"M";
    document.getElementById("kpi-sites").textContent=F(SITES.filter(s=>s.last<=7).length);
    document.getElementById("kpi-users").textContent=F(SITES.filter(s=>s.last<=7).reduce((a,b)=>a+b.uv7,0));
    document.querySelectorAll("#s1-kpis .kpi").forEach(k=>k.onclick=()=>renderS1(k.dataset.k));
    document.querySelectorAll("#s2-kpis .kpi").forEach(k=>k.onclick=()=>renderS2(k.dataset.k));
    renderS1(curS1);renderS2(curS2);
  }

  return {
    ver:"Records Management Dashboard",
    crumb:"Records Management Dashboard",
    asof:"Data as of Mon 20 Jul 2026 23:59 · refreshed Tue 21 Jul 06:00",
    /* exposed so Format and Storage can assert its format counts still add up
       to the same declared records total */
    annualRec:ANNUAL_REC,
    html,init
  };
})();
