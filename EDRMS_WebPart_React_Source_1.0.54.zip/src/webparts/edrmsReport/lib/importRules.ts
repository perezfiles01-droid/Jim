/*
 * The single manual data template (5 Nov 2026) and every rule it must pass.
 *
 * One workbook, one import, three data tabs:
 *   Sites        sir Rotsen's site file (Site, URL, Site Name, Department,
 *                Division, Production, Category, Sub-category, Sub-group)
 *   People       the AP All Users export, one row per person, plus one column
 *                RAC fills in: Completed EDRMS training (Yes / No / blank)
 *   Departments  Go-Live date and Site convention link per unit
 * and one optional helper tab:
 *   Code mapping People codes that are not report units (SD1, CCSD...) and
 *                the unit they count towards
 *
 * Headcount, staff type split and completed training are COUNTED from People,
 * never typed. Only per unit counts are kept; no names or emails are stored.
 *
 * If any rule is broken nothing is loaded. Skipped rows (service accounts,
 * repeated emails) are not errors: they are counted and reported.
 * This file has no SharePoint or browser imports, so the Floot copy
 * (helpers/importRules.tsx) is the same code.
 */

export type Cell = string | number | boolean | Date | null | undefined;
export type Sheet = Cell[][];

export interface IIssue { tab: string; row: number; column: string; message: string }

export interface IUnitFigures {
  headcount: number;
  staff: number;
  consultant: number;
  contractor: number;
  trained: number;
  goLive: string | null;
  convUrl: string | null;
}

export interface ISiteRow {
  site: string; url: string; siteName: string; department: string; division: string;
  production: boolean; category: string; subCategory: string; subGroup: string | null;
}

export interface IManualData {
  version: 2;
  importedAt: string;
  importedBy: string;
  fileName: string;
  units: { [code: string]: IUnitFigures };
  sites: ISiteRow[];
  notes: string[];
}

export interface IValidation {
  issues: IIssue[];
  notes: string[];
  data: IManualData | null;
  summary: { sites: number; people: number; units: number; trained: number };
}

export const TABS = { sites: 'Sites', people: 'People', departments: 'Departments', mapping: 'Code mapping' };

export const COLUMNS = {
  sites: [
    { name: 'Site', req: true, rule: 'Full link to the library. Must start with the URL on the same row followed by /. Each Site once.' },
    { name: 'URL', req: true, rule: 'https://<tenant>.sharepoint.com/sites/<name>, nothing after the site name.' },
    { name: 'Site Name', req: true, rule: 'Must equal the <name> at the end of the URL.' },
    { name: 'Department', req: true, rule: 'Unit code (capital letters and digits). Must equal the Sub-category or the Sub-group.' },
    { name: 'Division', req: true, rule: 'Division code (capital letters and digits).' },
    { name: 'Production', req: true, rule: 'Yes or No.' },
    { name: 'Category', req: true, rule: 'HQ, RM or RO.' },
    { name: 'Sub-category', req: true, rule: 'Unit code.' },
    { name: 'Sub-group', req: false, rule: 'Unit code, or blank.' }
  ],
  people: [
    { name: 'Email', req: true, rule: 'The person\'s email. Each person once (repeats are counted once). Only adb.org, adbi.org and afe.adb.org mailboxes are counted; others are skipped as service or test accounts.' },
    { name: 'Display Name', req: false, rule: 'Optional, for your reference only. Never stored.' },
    { name: 'Department', req: true, rule: 'Department code as in the AP export.' },
    { name: 'Division', req: false, rule: 'As in the AP export.' },
    { name: 'Unit', req: false, rule: 'As in the AP export.' },
    { name: 'Office Location', req: false, rule: 'ADB HQ, or the RM / RO code. A person in an RM or RO counts towards it; otherwise towards the Department.' },
    { name: 'Staff type', req: false, rule: 'Staff, Consultant or Contractor. Leave blank to take it from the email (.consultant, .contractor, otherwise Staff).' },
    { name: 'Completed EDRMS training', req: false, rule: 'Yes or No. Blank counts as No.' }
  ],
  departments: [
    { name: 'Unit code', req: true, rule: 'A unit that appears on Sites or People. Each unit once.' },
    { name: 'Go-Live date', req: false, rule: 'YYYY-MM-DD (an Excel date also works), from 2015-01-01 up to today. Blank if not live yet.' },
    { name: 'Site convention link', req: false, rule: 'https:// link on a sharepoint.com address. Blank if not provided yet.' }
  ],
  mapping: [
    { name: 'Code in People', req: true, rule: 'A Department or Office Location code used on People.' },
    { name: 'Report unit', req: true, rule: 'The report unit those people count towards.' }
  ]
};

/* Older header spellings accepted so the client's files can be pasted as they are. */
const ALIASES: { [k: string]: string } = {
  'main category': 'category', 'sub category': 'sub-category', 'sub sub category': 'sub-group',
  'subcategory': 'sub-category', 'sub group': 'sub-group', 'email id': 'email', 'e-mail': 'email'
};

export const POLICIES = [
  'Use this template. Only .xlsx files, 10 MB at most.',
  'Keep the tab names and the column headings in row 1. Columns may be in any order; extra columns are refused.',
  'Sites: at least 1 and at most 5,000 rows. People: at most 30,000 rows. Departments: at most 500 rows.',
  'Cells must not start with = + - or @ (formulas are not accepted).',
  'The raw AP All Users pivot can be pasted into People as it is: blank cells are filled down from the row above and Total rows are dropped.',
  'If any rule is broken, nothing in the file is loaded. Every problem is listed by tab, row and column.',
  'Headcount, staff type and completed training are counted from People. Only the counts per unit are kept; names and emails are never stored.'
];

const CODE = /^[A-Z][A-Z0-9-]{1,11}$/;
/* People codes come from HR as they are, e.g. "VAN PCO" or "MYRM-YGN". */
const PCODE = /^[A-Z][A-Z0-9 -]{1,15}$/;
const SITE_URL = /^https:\/\/[a-z0-9-]+\.sharepoint\.com\/sites\/([A-Za-z0-9_.-]+)$/i;
const EMAIL = /^[a-z0-9._%+'-]+@[a-z0-9.-]+\.[a-z]{2,}$/i;
const ADB_DOMAINS = ['adb.org', 'adbi.org', 'afe.adb.org'];
const HQ = ['', 'adb hq', '(blank)', 'hq'];

function clean(v: Cell): string {
  if (v === null || v === undefined) return '';
  if (v instanceof Date) return isoDate(v);
  return String(v).replace(/ /g, ' ').trim();
}
function isoDate(d: Date): string {
  const x = new Date(d.getTime() + 60000);
  const p2 = (n: number): string => (n < 10 ? '0' : '') + n;
  return x.getFullYear() + '-' + p2(x.getMonth() + 1) + '-' + p2(x.getDate());
}
function today(): string { return isoDate(new Date()); }
function isFormula(s: string): boolean { return /^[=+\-@]/.test(s) && !/^-?\d+(\.\d+)?$/.test(s); }
function isSpLink(s: string): boolean {
  if (/\s/.test(s)) return false;
  const m = /^https:\/\/([^/?#]+)(\/|$)/i.exec(s);
  return !!m && /(^|\.)sharepoint\.com$/i.test(m[1]);
}
function parseDate(s: string): string | null {
  if (/^\d{5}(\.0+)?$/.test(s)) return new Date(Date.UTC(1899, 11, 30) + Math.floor(+s) * 86400000).toISOString().slice(0, 10);
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  if (!m) return null;
  const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]));
  return d.getUTCFullYear() === +m[1] && d.getUTCMonth() === +m[2] - 1 && d.getUTCDate() === +m[3] ? s : null;
}
function key(h: string): string {
  const k = h.toLowerCase().replace(/\s+/g, ' ').trim();
  return ALIASES[k] || k;
}

interface ITable { cols: { [k: string]: number }; rows: { line: number; get: (k: string) => string }[] }

/** Reads one tab: finds the heading row (row 1, or the AP pivot's row 3), checks the headings. */
function readTab(tab: string, sheet: Sheet | undefined, spec: { name: string; req: boolean }[], issues: IIssue[],
  opts: { required: boolean; maxRows: number; pivot?: boolean; ignore?: string[] }): ITable | null {
  const push = (row: number, column: string, message: string): void => { if (issues.length < 1000) issues.push({ tab, row, column, message }); };
  if (!sheet || !sheet.length) {
    if (opts.required) push(0, '(tab)', 'The ' + tab + ' tab is missing or empty. Use the downloaded template and keep the tab name.');
    return null;
  }
  const want = spec.map(c => key(c.name)), ignore = (opts.ignore || []).map(key);
  let hr = 0;
  for (let r = 0; r < Math.min(10, sheet.length); r++) {
    const ks = (sheet[r] || []).map(c => key(clean(c)));
    if (want.filter(w => ks.indexOf(w) >= 0).length >= 2) { hr = r; break; }
  }
  const head = (sheet[hr] || []).map(c => clean(c));
  const cols: { [k: string]: number } = {};
  head.forEach((h, i) => {
    if (!h) return;
    const k = key(h);
    if (want.indexOf(k) < 0) { if (ignore.indexOf(k) < 0) push(hr + 1, h, 'Unknown column "' + h + '". Remove it or use the latest template.'); return; }
    if (cols[k] !== undefined) push(hr + 1, h, 'Column "' + h + '" appears more than once.');
    else cols[k] = i;
  });
  spec.forEach(c => { if (c.req && cols[key(c.name)] === undefined) push(hr + 1, c.name, 'Missing column "' + c.name + '".'); });
  if (issues.some(i => i.tab === tab)) return null;

  const rows: { line: number; get: (k: string) => string }[] = [];
  const carry: { [k: string]: string } = {};
  for (let r = hr + 1; r < sheet.length; r++) {
    const raw = sheet[r] || [];
    const vals: { [k: string]: string } = {};
    Object.keys(cols).forEach(k => { vals[k] = clean(raw[cols[k]]); });
    const all = raw.map(c => clean(c));
    if (all.every(v => v === '')) continue;
    if (opts.pivot) {
      // AP pivot: drop Total rows, fill grouped columns down.
      if (all.some(v => /(^|\s)total$/i.test(v) || /^grand total$/i.test(v))) continue;
      ['department', 'division', 'unit', 'organization'].forEach(k => {
        if (cols[k] === undefined) return;
        if (vals[k]) carry[k] = vals[k]; else vals[k] = carry[k] || '';
      });
    }
    rows.push({ line: r + 1, get: (k: string) => vals[key(k)] || '' });
  }
  if (rows.length > opts.maxRows) push(0, '(tab)', 'Too many rows (' + rows.length + '). The limit is ' + opts.maxRows + '.');
  if (opts.required && rows.length === 0) push(hr + 2, '(tab)', 'No data rows under the headings.');
  for (const row of rows) {
    Object.keys(cols).forEach(k => {
      const v = row.get(k);
      if (v && isFormula(v)) push(row.line, k, 'Starts with = + - or @. Formulas are not accepted.');
      if (v.length > 2048) push(row.line, k, 'Too long (' + v.length + ' characters).');
    });
  }
  return { cols, rows };
}

export function validate(book: { [tab: string]: Sheet }, fileName: string, importedBy: string): IValidation {
  const issues: IIssue[] = [];
  const notes: string[] = [];
  const push = (tab: string, row: number, column: string, message: string): void => { if (issues.length < 1000) issues.push({ tab, row, column, message }); };
  const find = (name: string): Sheet | undefined => {
    const k = Object.keys(book).find(t => t.trim().toLowerCase() === name.toLowerCase());
    return k ? book[k] : undefined;
  };

  /* ---------- Sites ---------- */
  const sitesT = readTab(TABS.sites, find(TABS.sites), COLUMNS.sites, issues, { required: true, maxRows: 5000 });
  const sites: ISiteRow[] = [];
  const known = new Set<string>();
  if (sitesT) {
    const seen: { [k: string]: number } = {}, siteSig: { [k: string]: { line: number; sig: string } } = {};
    for (const r of sitesT.rows) {
      const P = (c: string, m: string): void => push(TABS.sites, r.line, c, m);
      const site = r.get('Site'), url = r.get('URL'), nm = r.get('Site Name');
      const dept = r.get('Department').toUpperCase(), div = r.get('Division').toUpperCase(), prodRaw = r.get('Production');
      const cat = r.get('Category').toUpperCase(), sub = r.get('Sub-category').toUpperCase(), grp = r.get('Sub-group').toUpperCase();
      COLUMNS.sites.forEach(c => { if (c.req && !r.get(c.name)) P(c.name, 'Required. This cell is empty.'); });
      const m = SITE_URL.exec(url);
      if (url && !m) P('URL', 'Must look like https://<tenant>.sharepoint.com/sites/<name>, with nothing after the site name.');
      if (m && nm && nm.toLowerCase() !== m[1].toLowerCase()) P('Site Name', 'Must equal "' + m[1] + '", the name in the URL.');
      if (site) {
        if (!isSpLink(site)) P('Site', 'Must be a full https:// link on a sharepoint.com address.');
        else if (url && site.toLowerCase().indexOf(url.toLowerCase().replace(/\/$/, '') + '/') !== 0) P('Site', 'Must start with the URL on the same row followed by /.');
        const k = site.toLowerCase().replace(/\/$/, '');
        if (seen[k]) P('Site', 'Repeated (first on row ' + seen[k] + ').'); else seen[k] = r.line;
      }
      ([['Department', dept], ['Division', div], ['Sub-category', sub], ['Sub-group', grp]] as [string, string][]).forEach(([c, v]) => {
        if (v && !CODE.test(v)) P(c, '"' + v + '" is not a valid code (capital letters and digits, 2 to 12 characters).');
      });
      const prod = prodRaw.toLowerCase();
      if (prodRaw && prod !== 'yes' && prod !== 'no') P('Production', '"' + prodRaw + '" must be Yes or No.');
      if (cat && ['HQ', 'RM', 'RO'].indexOf(cat) < 0) P('Category', '"' + cat + '" must be HQ, RM or RO.');
      if (dept && sub && dept !== sub && dept !== grp) P('Department', '"' + dept + '" must equal the Sub-category (' + sub + ')' + (grp ? ' or the Sub-group (' + grp + ')' : '') + '.');
      if (m) {
        const sig = [dept, div, prod, cat, sub, grp].join('|'), prev = siteSig[url.toLowerCase()];
        if (prev && prev.sig !== sig) P('URL', 'Same site as row ' + prev.line + ' but with a different Department, Division, Production or category.');
        else if (!prev) siteSig[url.toLowerCase()] = { line: r.line, sig };
      }
      if (dept) known.add(dept);
      if (sub) known.add(sub);
      if (grp) known.add(grp);
      sites.push({ site: site.replace(/\/$/, ''), url, siteName: nm, department: dept, division: div, production: prod === 'yes', category: cat, subCategory: sub, subGroup: grp || null });
    }
  }

  /* ---------- Code mapping (optional) ---------- */
  const map: { [k: string]: string } = {};
  const mapT = readTab(TABS.mapping, find(TABS.mapping), COLUMNS.mapping, issues, { required: false, maxRows: 500 });
  if (mapT) {
    for (const r of mapT.rows) {
      const from = r.get('Code in People').toUpperCase(), to = r.get('Report unit').toUpperCase();
      if (!from || !to) { push(TABS.mapping, r.line, !from ? 'Code in People' : 'Report unit', 'Required. This cell is empty.'); continue; }
      if (!PCODE.test(from)) push(TABS.mapping, r.line, 'Code in People', '"' + from + '" is not a valid code.');
      if (!CODE.test(to)) push(TABS.mapping, r.line, 'Report unit', '"' + to + '" is not a valid code.');
      if (map[from]) push(TABS.mapping, r.line, 'Code in People', '"' + from + '" is mapped twice.');
      map[from] = to;
    }
  }

  /* ---------- People ---------- */
  const units: { [code: string]: IUnitFigures } = {};
  const unit = (c: string): IUnitFigures => units[c] || (units[c] = { headcount: 0, staff: 0, consultant: 0, contractor: 0, trained: 0, goLive: null, convUrl: null });
  const peopleT = readTab(TABS.people, find(TABS.people), COLUMNS.people, issues,
    { required: true, maxRows: 30000, pivot: true, ignore: ['Organization', 'Count of User Name'] });
  let people = 0, skippedDomain = 0, repeats = 0, trainedAll = 0, noDept = 0;
  if (peopleT) {
    const seen: { [e: string]: boolean } = {};
    for (const r of peopleT.rows) {
      const P = (c: string, m: string): void => push(TABS.people, r.line, c, m);
      const email = r.get('Email').toLowerCase(), dept = r.get('Department').toUpperCase();
      const officeRaw = r.get('Office Location'), typeRaw = r.get('Staff type'), trRaw = r.get('Completed EDRMS training');
      if (!email) { skippedDomain++; continue; }               // accounts with no mailbox (system ids) are not people
      if (!EMAIL.test(email)) { skippedDomain++; continue; }
      const dom = email.split('@')[1];
      if (ADB_DOMAINS.indexOf(dom) < 0) { skippedDomain++; continue; }
      if (seen[email]) { repeats++; continue; }
      seen[email] = true;
      if (!dept || dept === '(BLANK)') { noDept++; }
      let t = typeRaw.toLowerCase();
      if (!t) { const loc = email.split('@')[0]; t = /\.consultant$/.test(loc) ? 'consultant' : /\.contractor$/.test(loc) ? 'contractor' : 'staff'; }
      if (['staff', 'consultant', 'contractor'].indexOf(t) < 0) { P('Staff type', '"' + typeRaw + '" must be Staff, Consultant or Contractor.'); continue; }
      const tr = trRaw.toLowerCase();
      if (tr && tr !== 'yes' && tr !== 'no') { P('Completed EDRMS training', '"' + trRaw + '" must be Yes, No or blank.'); continue; }
      const office = officeRaw.toUpperCase();
      let code = HQ.indexOf(officeRaw.toLowerCase()) >= 0 ? (dept && dept !== '(BLANK)' ? dept : 'UNASSIGNED') : office;
      code = map[code] || code;
      if (!PCODE.test(code)) { P(HQ.indexOf(officeRaw.toLowerCase()) >= 0 ? 'Department' : 'Office Location', '"' + code + '" is not a valid code. Add it to the Code mapping tab.'); continue; }
      const u = unit(code);
      u.headcount++;
      if (t === 'staff') u.staff++; else if (t === 'consultant') u.consultant++; else u.contractor++;
      if (tr === 'yes') { u.trained++; trainedAll++; }
      people++;
    }
    if (skippedDomain) notes.push(skippedDomain + ' account(s) skipped: no email or not an ADB mailbox (service and test accounts).');
    if (repeats) notes.push(repeats + ' repeated email(s) counted once.');
    if (noDept) notes.push(noDept + ' person(s) with no Department or office, counted under UNASSIGNED.');
    if (people > 0 && trainedAll === 0) notes.push('No one is marked Yes in Completed EDRMS training, so Completed training will show 0 for every unit. Fill that column if this is not intended.');
    if (people === 0) push(TABS.people, 0, '(tab)', 'No people could be counted. Check the Email column.');
  }

  /* ---------- Departments ---------- */
  const deptT = readTab(TABS.departments, find(TABS.departments), COLUMNS.departments, issues, { required: false, maxRows: 500 });
  if (deptT) {
    const seen: { [k: string]: number } = {}, now = today();
    for (const r of deptT.rows) {
      const P = (c: string, m: string): void => push(TABS.departments, r.line, c, m);
      const code = r.get('Unit code').toUpperCase(), d = r.get('Go-Live date'), link = r.get('Site convention link');
      if (!code) { P('Unit code', 'Required. This cell is empty.'); continue; }
      if (!CODE.test(code)) { P('Unit code', '"' + code + '" is not a valid code.'); continue; }
      if (seen[code]) { P('Unit code', '"' + code + '" is repeated (first on row ' + seen[code] + ').'); continue; }
      seen[code] = r.line;
      if (!known.has(code) && !units[code]) P('Unit code', '"' + code + '" is not on the Sites or People tab.');
      let date: string | null = null;
      if (d) {
        date = parseDate(d);
        if (!date) P('Go-Live date', '"' + d + '" is not a real date in YYYY-MM-DD form.');
        else if (date < '2015-01-01') P('Go-Live date', date + ' is before 2015-01-01.');
        else if (date > now) P('Go-Live date', date + ' is in the future.');
      }
      if (link && !isSpLink(link)) P('Site convention link', 'Must be a full https:// link on a sharepoint.com address, with no spaces.');
      const u = unit(code);
      u.goLive = date; u.convUrl = link || null;
    }
  }

  const noSites = Object.keys(units).filter(c => units[c].headcount > 0 && !known.has(c));
  if (noSites.length) notes.push(noSites.length + ' unit(s) have people but no EDRMS site: ' + noSites.slice(0, 12).join(', ') + (noSites.length > 12 ? ', ...' : '') + '. Map them on Code mapping if they belong to another unit.');

  const summary = { sites: sites.length, people, units: Object.keys(units).length, trained: trainedAll };
  const ok = issues.length === 0;
  return {
    issues, notes, summary,
    data: ok ? { version: 2, importedAt: new Date().toISOString(), importedBy, fileName, units, sites, notes } : null
  };
}
