import * as React from 'react';
import styles from '../../components/Report.module.scss';
import { FLOOT_EXTRA_CSS } from '../flootExtraCss';
import { applyManual, IReportData } from '../helpers/edrmsData';
import { IManualData } from '../helpers/edrmsImportRules';
import { IManualStore } from '../helpers/edrmsManualStore';
import { ImportPanel } from './EdrmsImportPanel';
import { useLinked, useLinkReset, useOnChange, isOneOf } from '../helpers/edrmsLink';
import { exportPdf, exportPptx } from '../helpers/edrmsExporters';
import { BankWide } from './EdrmsBankWide';
import { DepartmentInsights } from './EdrmsDepartmentInsights';
import { DownloadGlyph } from './EdrmsUi';

export type Dashboard = 'bw' | 'dp' | 'ad';
export type TextSize = 'standard' | 'large' | 'xlarge';

export interface IReportAppProps {
  dashboard: Dashboard;
  showSidebar: boolean;
  textSize: TextSize;
  /** Where imported manual data is read from and saved to. */
  store?: IManualStore;
  /** True only for people who can manage the site (Owners, site collection admins). */
  canImport?: boolean;
  userName?: string;
  roleLabel?: string;
}

/* Text size: Large is the default, as readers are often older. */
const ZOOM: { [k in TextSize]: number } = { standard: 1, large: 1.25, xlarge: 1.5 };
const SIDEBAR_KEY = 'edrms-sidebar-closed';

const ICONS: { [k: string]: React.ReactElement } = {
  bw: <svg viewBox="0 0 16 16"><circle cx="8" cy="8" r="6" /><circle cx="8" cy="8" r="2.5" fill="currentColor" /></svg>,
  ad: <svg viewBox="0 0 16 16"><rect x="3" y="2" width="10" height="12" rx="1" /><path d="M5.5 6h5M5.5 9h5M5.5 12h3" /></svg>,
  dp: <svg viewBox="0 0 16 16"><rect x="2" y="2" width="5" height="5" /><rect x="9" y="2" width="5" height="5" /><rect x="2" y="9" width="5" height="5" /><rect x="9" y="9" width="5" height="5" /></svg>,
  pj: <svg viewBox="0 0 16 16"><path d="M8 2l6 6-6 6-6-6z" /></svg>,
  fp: <svg viewBox="0 0 16 16"><path d="M3 4h10M3 8h10M3 12h10" /></svg>,
  rd: <svg viewBox="0 0 16 16"><circle cx="8" cy="8" r="6" /><path d="M8 5v3l2 1" /></svg>,
  ra: <svg viewBox="0 0 16 16"><rect x="2" y="3" width="12" height="4" /><path d="M3 7v6h10V7M6 10h4" /></svg>
};

const FUTURE: { key: string; text: string }[] = [
  { key: 'pj', text: 'Project Insights' },
  { key: 'fp', text: 'Institutional File Plan' },
  { key: 'rd', text: 'Retention & Disposal' },
  { key: 'ra', text: 'Records & Archive Holdings' }
];

/* 25 Nov 2026: sidebar labels stay on one line and fade while the sidebar slides; clicking
   in the sidebar never highlights text. */
const SIDE_CSS = '.edrms-report .side{user-select:none}' +
  '.edrms-report .side .navTx,.edrms-report .side .brand .t1,.edrms-report .side .brand .t2,.edrms-report .side .grp{transition:opacity .12s ease}' +
  '.edrms-report .side.sliding .navTx,.edrms-report .side.sliding .brand .t1,.edrms-report .side.sliding .brand .t2,.edrms-report .side.sliding .grp{opacity:0;white-space:nowrap;overflow:hidden}' +
  '.edrms-report .menuBtn{user-select:none}';

function readClosed(): boolean {
  try { return localStorage.getItem(SIDEBAR_KEY) === '1'; } catch { return false; }
}

/* Web part 1.0.59: the Floot app's report (24 Nov 2026). Two SharePoint differences:
   the report fits the web part's own width rather than the whole browser window, and
   Import data is offered only to site Owners and site collection admins (canImport). */
const ReportAppInner: React.FC<IReportAppProps & { base: IReportData }> = props => {
  const base = props.base;
  // Imported manual data (Import data) replaces sample figures for every reader.
  const [manual, setManual] = React.useState<IManualData | null>(null);
  const [importing, setImporting] = React.useState(false);
  React.useEffect(() => { if (props.store) props.store.load().then(setManual, () => setManual(null)); }, [props.store]);
  const data = React.useMemo(() => applyManual(base, manual), [base, manual]);
  // 25 Nov 2026: the open dashboard and department are kept in the page address (helpers/edrmsLink).
  const [dash, setDash] = useLinked<Dashboard>('dash', props.dashboard, isOneOf(['bw', 'dp', 'ad']));
  const [focusRaw, setFocusRaw] = useLinked<string>('focus', '', isOneOf([''].concat(base.depts.map(d => d.code))));
  const focus = focusRaw || undefined;
  const setFocus = (v: string | undefined): void => setFocusRaw(v || '');
  const [closed, setClosed] = React.useState<boolean>(readClosed);
  const [busy, setBusy] = React.useState(false);
  const page = React.useRef<HTMLDivElement>(null);
  const root = React.useRef<HTMLDivElement>(null);
  /* 23 Nov 2026: the text size adapts to the space available, so the same layout fits any
     monitor (a smaller or scaled screen shrinks it; a large one keeps the chosen size). The
     layout was designed for about 1500 x 800 CSS pixels at size 1. In SharePoint the space
     is the web part's own width, not the whole window. */
  const [fitZoom, setFitZoom] = React.useState<number>(1);
  const [fitH, setFitH] = React.useState<number>(0);
  React.useEffect(() => {
    const fit = (): void => {
      /* 25 Nov 2026, by request: the report keeps the same proportions on every screen,
         as it looks on a laptop: everything grows together on a bigger monitor, so the
         filters stay readable and the graph keeps its share. The text size setting
         scales that (Large is 1). */
      const scale = (ZOOM[props.textSize] || 1.25) / 1.25;
      const side = props.showSidebar ? (closed ? 60 : 300) : 0;
      const host = root.current && root.current.parentElement;
      const width = host && host.clientWidth ? host.clientWidth : window.innerWidth;
      const byW = width / 1500 + 0 * side;
      /* 25 Nov 2026: the report is exactly as tall as the screen below where it starts,
         so the page never scrolls, and the text size also shrinks to fit that height.
         The start is measured on the page, not where it happens to be now: SharePoint
         scrolls its own page area and lays the page out after the web part first draws,
         so this runs again a few times below. */
      const el = root.current;
      let top = 0;
      if (el) {
        top = el.getBoundingClientRect().top;
        for (let p = el.parentElement; p; p = p.parentElement) {
          if (p.scrollTop > 0) top += p.scrollTop;
        }
        top = Math.max(0, top + window.scrollY);
      }
      const availH = Math.max(320, window.innerHeight - top - 2);
      const byH = availH / 620;
      const z = Math.max(0.45, Math.min(3, Math.min(byW, byH) * scale));
      setFitZoom(z);
      setFitH(availH / z);
    };
    fit();
    const timers = [200, 700, 1500, 3000].map(ms => window.setTimeout(fit, ms));
    window.addEventListener('resize', fit);
    return () => { timers.forEach(t => window.clearTimeout(t)); window.removeEventListener('resize', fit); };
  }, [props.textSize, props.showSidebar, closed]);
  /* After the size changes, let the screen-filling parts (main graph, breakdown tables)
     measure again, on the next frame once the new size has applied. */
  React.useEffect(() => {
    const id = window.requestAnimationFrame(() => window.setTimeout(() => window.dispatchEvent(new Event('resize')), 30));
    return () => window.cancelAnimationFrame(id);
  }, [fitZoom, fitH]);

  useOnChange(props.dashboard, () => setDash(props.dashboard));

  const go = (d: Dashboard): void => {
    setDash(d);
    if (d === 'bw') setFocus(undefined);
    if (root.current) root.current.scrollIntoView({ block: 'start' });
  };
  const openDept = (code: string): void => { setFocus(code); go('dp'); };
  /* 25 Nov 2026: a smooth sidebar. The labels fade instead of wrapping while it slides, and
     the report beside it takes its new width once, at the start, so it does not redraw on
     every frame of the slide; the tables and graph refit once the slide has finished. */
  const [sliding, setSliding] = React.useState(false);
  const sideW = React.useRef<{ open: number; shut: number }>({ open: 236, shut: 56 });
  const slideTimer = React.useRef(0);
  const toggle = (): void => {
    const next = !closed;
    const m = page.current;
    const side = m && m.parentElement ? m.parentElement.querySelector('nav.side') as HTMLElement | null : null;
    if (side) sideW.current[closed ? 'shut' : 'open'] = side.offsetWidth;
    if (m) {
      const delta = sideW.current.open - sideW.current.shut;
      m.style.flex = '0 0 ' + (m.offsetWidth + (next ? delta : -delta)) + 'px';
    }
    setSliding(true);
    setClosed(next);
    window.clearTimeout(slideTimer.current);
    slideTimer.current = window.setTimeout(() => {
      if (page.current) page.current.style.flex = '';
      setSliding(false);
      window.dispatchEvent(new Event('resize'));
    }, 240);
    try { localStorage.setItem(SIDEBAR_KEY, next ? '1' : '0'); } catch { /* private window */ }
  };
  const [menu, setMenu] = React.useState(false);
  const [busyText, setBusyText] = React.useState('');
  React.useEffect(() => {
    if (!menu) return;
    const close = (): void => setMenu(false);
    const key = (e: KeyboardEvent): void => { if (e.key === 'Escape') setMenu(false); };
    document.addEventListener('click', close);
    document.addEventListener('keydown', key);
    return () => { document.removeEventListener('click', close); document.removeEventListener('keydown', key); };
  }, [menu]);
  const name = dash === 'dp' ? 'Department Insights' : 'Bank-wide Oversight';
  /* 23 Nov 2026: "Data as of" moves only when an import is saved successfully.
     A refused or failed import never reaches the store, so the date stays put.
     Before any import, the sample data's own date is shown. */
  const asOfText = React.useMemo(() => {
    const at = manual && manual.importedAt ? new Date(manual.importedAt) : null;
    if (!at || isNaN(at.getTime())) return 'Monday 23 Nov 2026';
    const m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const w = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return w[at.getDay()] + ' ' + ('0' + at.getDate()).slice(-2) + ' ' + m[at.getMonth()] + ' ' + at.getFullYear();
  }, [manual, base.asOf]);
  // The capture libraries do not understand CSS zoom, so the page is drawn at
  // standard size and the text size is put back afterwards.
  const run = (text: string, job: () => Promise<void>): void => {
    if (!page.current || busy) return;
    setMenu(false); setBusy(true); setBusyText(text);
    const r = root.current, zoom = r ? r.style.getPropertyValue('zoom') : '';
    if (r) r.style.setProperty('zoom', '1');
    const done = (): void => { if (r) r.style.setProperty('zoom', zoom); setBusy(false); };
    job().then(done, e => { console.error('[EDRMS export]', e); done(); });
  };
  const pdf = (): void => run('Preparing PDF', () => exportPdf(page.current as HTMLElement, name));
  /* RAC Item 8 (22 Oct 2026): PowerPoint, one slide per breakdown and section. */
  const pptx = (): void => run('Preparing PowerPoint', () => {
    const el = page.current as HTMLElement;
    const pick = (q: string): string => ((el.querySelector(q) || {}).textContent || '').trim();
    return exportPptx(el, {
      name, desc: pick('.band .bd'), asOf: asOfText,
      filter: dash === 'bw' ? 'All Departments / Offices / RMs / ROs'
        : Array.from(el.querySelectorAll('.dash-dp > .panel:first-of-type .cgG')).map(g =>
          ((g.querySelector('.cgL') || {}).textContent || '') + ': ' + ((g.querySelector('.ms-Dropdown-title') || {}).textContent || '').trim()).join('  ·  ')
    });
  });

  const canImport = !!(props.canImport && props.store);
  const bandTools = (
    <>
      <span className="asof"><i />Data as of<b>{asOfText}</b></span>
      {/* Bank-wide Oversight only, and only for site Owners and site collection admins. */}
      {dash === 'bw' && canImport && (
        <button type="button" className="pdfBtn impOpen" data-html2canvas-ignore="true" onClick={() => setImporting(true)}
          title="Owners and admins: import People and training">
          <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 11V2M4.5 5.5 8 2l3.5 3.5M2.5 10.5v3h11v-3" /></svg>Import data
        </button>
      )}
      <span className="xMenuWrap" data-html2canvas-ignore="true">
        <button type="button" className="pdfBtn" disabled={busy} aria-haspopup="menu" aria-expanded={menu}
          onClick={e => { e.stopPropagation(); setMenu(!menu); }}>
          <DownloadGlyph />{busy ? busyText : 'Export'}{!busy && <span className="xCaret" aria-hidden="true">&#9662;</span>}
        </button>
        {menu && (
          <div className="xMenu" role="menu" onClick={e => e.stopPropagation()}>
            <button type="button" role="menuitem" onClick={pdf}><span className="xIc pdf">PDF</span><span><b>PDF</b><small>The dashboard as on screen</small></span></button>
            <button type="button" role="menuitem" onClick={pptx}><span className="xIc ppt">PPT</span><span><b>PowerPoint</b><small>One slide per breakdown and section, editable title and key points</small></span></button>
          </div>
        )}
      </span>
    </>
  );

  return (
    <div ref={root} className={styles.report + ' edrms-report'} style={{ zoom: fitZoom, height: fitH ? fitH.toFixed(1) + 'px' : (100 / fitZoom).toFixed(2) + 'vh', overflow: 'hidden', background: '#C3E4F3' } as React.CSSProperties}>
      {props.showSidebar && (
        <nav className={'side' + (closed ? ' closed' : '') + (sliding ? ' sliding' : '')} aria-label="Dashboards">
          <style>{SIDE_CSS}</style>
          <div className="brand">
            <button type="button" className="menuBtn" onClick={toggle} aria-expanded={!closed}
              title={sliding ? undefined : closed ? 'Open navigation' : 'Close navigation'} aria-label={closed ? 'Open navigation' : 'Close navigation'}>
              <svg viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16" /></svg>
            </button>
            <div className="t1">EDRMS Utilization Report</div>
            <div className="t2">Asian Development Bank</div>
          </div>
          <div className="grp">Key views</div>
          <button type="button" className={'nav' + (dash === 'bw' ? ' on' : '')} aria-current={dash === 'bw' ? 'page' : undefined} title="Bank-wide Oversight" onClick={() => go('bw')}>
            {ICONS.bw}<span className="navTx">Bank-wide Oversight</span>
          </button>
          <button type="button" className={'nav' + (dash === 'dp' ? ' on' : '')} aria-current={dash === 'dp' ? 'page' : undefined} title="Department Insights" onClick={() => go('dp')}>
            {ICONS.dp}<span className="navTx">Department Insights</span>
          </button>
          <div className="grp">For future release</div>
          {FUTURE.map(f => (
            <button type="button" key={f.key} className="nav future" aria-disabled="true" title={f.text + ' (future release)'}>
              {ICONS[f.key]}<span className="navTx">{f.text}</span>
            </button>
          ))}
        </nav>
      )}
      <style>{FLOOT_EXTRA_CSS}</style>
      <div className="main" ref={page} style={{ overflowY: 'auto', height: '100%', paddingBottom: 0 }}>
        {dash === 'dp'
          ? <DepartmentInsights data={data} openDept={openDept} bandTools={bandTools} focus={focus} />
          : <BankWide data={data} openDept={openDept} bandTools={bandTools} />}
      </div>
      {importing && canImport && props.store && (
        <ImportPanel store={props.store} user={props.userName || 'Site owner'} role={props.roleLabel || 'Site owner'}
          current={manual} knownUnits={base.depts.map(d => d.code)}
          onClose={() => setImporting(false)} onLoaded={setManual} />
      )}
    </div>
  );
};

/* 25 Nov 2026: a link whose filters are no longer valid is ignored as a whole; the
   report then starts afresh with the default view. */
export const ReportApp: React.FC<IReportAppProps & { base: IReportData }> = props => {
  const gen = useLinkReset();
  return <ReportAppInner key={gen} {...props} />;
};
