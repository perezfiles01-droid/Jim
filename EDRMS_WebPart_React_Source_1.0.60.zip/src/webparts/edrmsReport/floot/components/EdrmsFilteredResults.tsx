import * as React from 'react';
import { IReportData, IDept, documentSeries, DOC_MONTHS, sum, approxHead, isMissing, NOT_SOURCED } from '../helpers/edrmsData';
import { categoryOf } from '../helpers/edrmsCategories';
import { F, niceMax, axisLabel } from '../helpers/edrmsFormat';
import { Panel, Segmented, InfoIcon } from './EdrmsUi';

/* Tooltips on the five Filtered results figures (23 Nov 2026). */
const TIPS: { [k: string]: string } = {
  sites: 'EDRMS sites for the departments and period chosen in the filters.',
  users: 'Internal ADB users (approximate headcount derived by BPMSD) for the departments and period chosen.',
  docs: 'Files stored in EDRMS sites for the departments and period chosen.',
  rec: 'Documents declared as official records for the departments and period chosen.',
  phys: 'Declared records that also exist on paper, for the departments and period chosen.'
};

/*
 * RAC review of 23 Nov 2026 (EDRMS_Dashboard.pptx, slides 1 to 7 and 19 to 20):
 * the "Filtered results" section of Bank-wide Oversight. The five cards above it
 * never move; these figures and the graph follow the filters.
 *  - Display: Month or Year. Year turns "Show # Months" into "Show # Years" and
 *    Count by into Cumulative / YTD.
 *  - Count by: Cumulative (Day 1 to the period end) or MTD / YTD (that period only).
 *  - Report type: Documents, Records and Physical can be combined (1 to 3) when one
 *    period is shown; with several periods only one report type is allowed.
 *  - View: By department, or Summary (one ADB bar).
 *  - Department: searchable, type-ahead, multi-select list of departments only
 *    (no RM / RO expansion on Bank-wide; that belongs to Department Insights).
 * Monthly periods, not an exact date: the data refreshes weekly, and the "Data as
 * of" stamp in the title band shows the last refresh.
 * SAMPLE FIGURES: monthly values are spread from the sample document series.
 */

type TypeKey = 'sites' | 'users' | 'docs' | 'rec' | 'phys';
const TYPES: { key: TypeKey; text: string; color: string }[] = [
  { key: 'sites', text: 'Sites', color: '#6E5BAA' },
  { key: 'users', text: 'Users', color: '#0F9F87' },
  /* RAC mockup colours: documents dark teal, records orange. */
  { key: 'docs', text: 'Documents', color: '#1B5E80' },
  { key: 'rec', text: 'Records', color: '#ED7D31' },
  { key: 'phys', text: 'Physical', color: '#E08A1E' }
];
const COMBINABLE: TypeKey[] = ['docs', 'rec', 'phys'];
const PERIOD_COLORS = ['#0072BC', '#5CA943', '#E08A1E', '#6E5BAA', '#0F9F87', '#C0392B', '#2677D4', '#8E44AD', '#16A085', '#D35400', '#7F8C8D', '#2C3E50'];
const YEARS = [2024, 2025, 2026];

const baseOf = (d: IDept, t: TypeKey): number => (t === 'users' ? approxHead(d) : d[t]);

/** The department a unit belongs to (an RM or RO rolls up to its department). */
export const deptOf = (code: string): string => categoryOf(code).sub || code;

interface IPeriod { key: string; label: string; end: number; prevEnd: number }

const FrStyles = (): React.ReactElement => (
  <style>{`
.fr .frFilters{background:#185E85;border-radius:12px;padding:12px 16px;margin-bottom:12px}
.fr .frFilters .frL{color:#DCE8F3!important}
.fr .frFilters .seg{background:#fff;border-radius:6px}
.fr .frFilters .dp input[type=search]{background:#fff}
.fr .frStrip{background:#185E85;border-radius:12px;padding:14px 16px;gap:10px;margin:8px 0 16px!important;position:relative}
.fr .frStrip::before{content:'Filtered results';grid-column:1/-1;color:#fff;font-size:16px;font-weight:700}
.fr .frCell{background:#fff!important;border:0!important;border-radius:12px!important;padding:12px 16px!important;box-shadow:0 1px 3px rgba(16,36,62,.12)}
.fr .frCell .l{font-size:15px!important;font-weight:500!important;color:#10243E!important}
.fr .frCell .v{font-size:28px!important;font-weight:700;color:#10243E;line-height:1.15;margin-top:4px}
.edrms-report .chart svg rect:hover,.edrms-report .chart svg circle:hover{opacity:.75;cursor:pointer}
.fr .frFilters{display:flex;flex-wrap:wrap;gap:14px 22px;align-items:flex-end;margin-bottom:14px}
.fr .frG{display:flex;flex-direction:column;gap:6px}
.fr .frL{font-size:12px;font-weight:600;color:#5B6B7D;text-transform:uppercase;letter-spacing:.03em}
.fr .frStrip{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:10px;margin:4px 0 14px}
.fr .frCell{position:relative;border:1px solid #DCE3EB;border-radius:8px;padding:10px 12px;background:#F7FAFD}
.fr .frCell .l{font-size:12px;color:#5B6B7D}
.fr .frCell .v{font-size:22px;font-weight:600;color:#10243E}
.fr .frHint{font-size:12px;color:#6B7A8C;margin:0 0 8px}
.fr .dp{position:relative;min-width:260px}
.fr .dp input[type=search]{width:100%;box-sizing:border-box;height:32px;border:1px solid #B8C4D1;border-radius:4px;padding:0 10px;font:inherit;font-size:13px}
.fr .dpList input[type=checkbox]{width:16px!important;height:16px!important;min-width:0!important;margin:0!important;padding:0!important;flex:0 0 16px;accent-color:#0072BC}
.fr .dpList label{justify-content:flex-start!important;text-align:left!important;color:#10243E}
.fr .dpList{position:absolute;z-index:20;top:36px;left:0;right:0;max-height:260px;overflow:auto;background:#fff;border:1px solid #B8C4D1;border-radius:4px;box-shadow:0 6px 18px rgba(16,36,62,.15)}
.fr .dpList label{display:flex;gap:8px;align-items:center;padding:6px 10px;font-size:13px;cursor:pointer}
.fr .dpList label:hover{background:#EEF4FA}
.fr .dpChips{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px;max-width:420px}
.fr .dpChip{font-size:12px;background:#E6F0FA;color:#0B4F8A;border-radius:12px;padding:2px 8px;border:0;cursor:pointer}
.fr .seg button:disabled{opacity:.4;cursor:not-allowed}
@media (max-width:900px){.fr .frStrip{grid-template-columns:repeat(2,minmax(0,1fr))}}
`}</style>
);

/** Searchable, type-ahead, multi-select list of departments. Empty means all. */
export const DeptPicker: React.FC<{ all: string[]; selected: string[]; onChange: (v: string[]) => void }> = ({ all, selected, onChange }) => {
  const [q, setQ] = React.useState('');
  const [open, setOpen] = React.useState(false);
  const wrap = React.useRef<HTMLDivElement>(null);
  React.useEffect(() => {
    if (!open) return undefined;
    const close = (e: MouseEvent): void => { if (wrap.current && !wrap.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, [open]);
  const shown = all.filter(c => c.toLowerCase().indexOf(q.trim().toLowerCase()) >= 0);
  const flip = (c: string): void => onChange(selected.indexOf(c) >= 0 ? selected.filter(x => x !== c) : selected.concat(c));
  return (
    <div className="dp" ref={wrap}>
      <input type="search" value={q} placeholder={selected.length ? selected.length + ' selected' : 'All departments'}
        aria-label="Department" onFocus={() => setOpen(true)} onChange={e => { setQ(e.target.value); setOpen(true); }} />
      {open && (
        <div className="dpList" role="listbox" aria-multiselectable="true">
          {shown.length ? shown.map(c => (
            <label key={c}><input type="checkbox" checked={selected.indexOf(c) >= 0} onChange={() => flip(c)} />{c}</label>
          )) : <label>No department matches.</label>}
        </div>
      )}
      {selected.length > 0 && (
        <div className="dpChips">
          {selected.map(c => <button type="button" key={c} className="dpChip" onClick={() => flip(c)} aria-label={'Remove ' + c}>{c} &times;</button>)}
          <button type="button" className="dpChip" onClick={() => onChange([])}>Clear all</button>
        </div>
      )}
    </div>
  );
};

/** Clustered columns: one group per department (or ADB), one column per series. */
const GroupedColumns: React.FC<{ groups: string[]; series: { key: string; label: string; color: string; values: number[] }[]; onGroup?: (g: string) => void; title?: string; sub?: string }> =
  ({ groups, series, onGroup, title, sub }) => {
    /* 23 Nov 2026: the graph fills the rest of the screen, so the default view ends
       exactly at the bottom of the graph whatever the window size. */
    const svgRef = React.useRef<SVGSVGElement>(null);
    const [H, setH] = React.useState(290);
    React.useLayoutEffect(() => {
      const fit = (): void => {
        const s = svgRef.current;
        if (!s) return;
        const r = s.getBoundingClientRect();
        // 25 Nov 2026: fit to the bottom of the report itself, which is sized to the screen.
        const host = s.closest('.edrms-report');
        const bottom = host ? host.getBoundingClientRect().bottom : window.innerHeight;
        const avail = bottom - r.top - 40; // room for the axis title and the card's bottom edge
        if (r.width > 0 && avail > 0) setH(Math.max(160, Math.min(560, Math.round(1400 * avail / r.width))));
      };
      fit();
      // measure again once fonts and the page's size settle
      const t1 = window.setTimeout(fit, 150), t2 = window.setTimeout(fit, 600);
      window.addEventListener('resize', fit);
      return () => { window.clearTimeout(t1); window.clearTimeout(t2); window.removeEventListener('resize', fit); };
    }, []);
    const W = 1400, L = 78, R = W - 12, T = 14, B = H - 54;
    const n = Math.max(1, groups.length), step = (R - L) / n;
    const max = niceMax(Math.max(1, ...series.map(s => Math.max(0, ...s.values))));
    const inner = Math.min(step * 0.8, 40 * series.length + 20), bw = inner / Math.max(1, series.length);
    return (
      <div className="chart">
        {title && <div className="chartTitle">{title}</div>}
        <div className="legend">{series.map(s => <span key={s.key}><i style={{ background: s.color }} />{s.label}</span>)}</div>
        {sub && <div className="chartSub" style={{ flexBasis: '100%', width: '100%', fontSize: 12, color: '#5B6B7D', margin: '2px 0 4px', fontWeight: 400 }}>{sub}</div>}
        <svg ref={svgRef} viewBox={`0 0 ${W} ${H}`} role="img" aria-label="Filtered results graph">
          <text x={14} y={(T + B) / 2} transform={`rotate(-90 14 ${(T + B) / 2})`} textAnchor="middle" fontSize="12" fontWeight="600" fill="#33475F">Count</text>
          <text x={(L + R) / 2} y={H - 4} textAnchor="middle" fontSize="12" fontWeight="600" fill="#33475F">{groups.length === 1 && groups[0] === 'ADB' ? 'Bank-wide' : 'Department'}</text>
          <line x1={L} x2={R} y1={B} y2={B} stroke="#9FB7C8" />
          {[0, 1, 2, 3, 4].map(t => {
            const y = B - (B - T) * t / 4;
            return <g key={t}><line x1={L} x2={R} y1={y} y2={y} stroke="#E3E9F0" /><text x={L - 8} y={y + 4} textAnchor="end" fontSize="11" fill="#5B6B7D">{axisLabel(max * t / 4)}</text></g>;
          })}
          {groups.map((g, gi) => {
            const x0 = L + step * gi + (step - inner) / 2;
            return (
              <g key={g} className={onGroup && g !== 'ADB' ? 'click' : undefined} onClick={onGroup && g !== 'ADB' ? () => onGroup(g) : undefined} style={onGroup && g !== 'ADB' ? { cursor: 'pointer' } : undefined}>
                {series.map((s, si) => {
                  const v = s.values[gi] || 0, h = (B - T) * Math.max(0, v) / max;
                  return (
                    <g key={s.key}>
                      <rect x={x0 + si * bw + 1} y={B - h} width={Math.max(2, bw - 2)} height={Math.max(h, v ? 2 : 0)} rx="2" fill={s.color}><title>{g + ', ' + s.label + ': ' + F(v)}</title></rect>
                    </g>
                  );
                })}
                <text x={L + step * gi + step / 2} y={B + 16} textAnchor="middle" fontSize="11" fill="#5B6B7D"
                  transform={groups.length > 12 ? `rotate(-35 ${L + step * gi + step / 2} ${B + 16})` : undefined}>{g}</text>
              </g>
            );
          })}
        </svg>
      </div>
    );
  };

export const FilteredResults: React.FC<{ data: IReportData; openDept: (code: string) => void }> = ({ data, openDept }) => {
  const units = data.depts;
  const [display, setDisplay] = React.useState<'m' | 'y'>('m');
  const [count, setCount] = React.useState<'cum' | 'period'>('cum');
  const [nPeriods, setNPeriods] = React.useState<string>('1');
  const [types, setTypes] = React.useState<TypeKey[]>(['docs', 'rec']);
  const [view, setView] = React.useState<'dept' | 'sum'>('dept');
  const [sel, setSel] = React.useState<string[]>([]);

  const allDepts = React.useMemo(() => Array.from(new Set(units.map(u => deptOf(u.code)))).sort(), [units]);
  const series = React.useMemo(() => {
    const o: { [c: string]: { start: number; held: number[] } } = {};
    units.forEach(d => { o[d.code] = documentSeries(d); });
    return o;
  }, [units]);

  const multi = Number(nPeriods) > 1;
  // With several periods only one report type is allowed (RAC, slide 5).
  const shownTypes: TypeKey[] = multi ? [types[0]] : types;
  const pickType = (t: TypeKey): void => {
    if (multi || COMBINABLE.indexOf(t) < 0) { setTypes([t]); return; }
    const cur = types.filter(x => COMBINABLE.indexOf(x) >= 0);
    if (cur.indexOf(t) >= 0) { if (cur.length > 1) setTypes(cur.filter(x => x !== t)); }
    else setTypes(cur.concat(t));
  };

  /* Value of one unit, one type, at the end of month index i (i = -1 is the start). */
  const at = (d: IDept, t: TypeKey, i: number): number => {
    const s = series[d.code];
    const held = i < 0 ? s.start : s.held[Math.min(i, s.held.length - 1)];
    return Math.round(baseOf(d, t) * (d.docs ? held / d.docs : 1));
  };

  const last = DOC_MONTHS.length - 1;
  const periods: IPeriod[] = [];
  if (display === 'm') {
    for (let k = Number(nPeriods) - 1; k >= 0; k--) {
      const i = last - k;
      periods.push({ key: 'm' + i, label: DOC_MONTHS[i].lab, end: i, prevEnd: i - 1 });
    }
  } else {
    YEARS.slice(-Number(nPeriods)).forEach(y => {
      const idx = DOC_MONTHS.map((m, i) => (m.y === y ? i : -2)).filter(i => i >= 0);
      periods.push({ key: 'y' + y, label: String(y) + (y === DOC_MONTHS[last].y ? ' to date' : ''), end: idx[idx.length - 1], prevEnd: idx[0] - 1 });
    });
  }
  const valueOf = (list: IDept[], t: TypeKey, p: IPeriod): number =>
    sum(list, d => (count === 'cum' ? at(d, t, p.end) : at(d, t, p.end) - at(d, t, p.prevEnd)));

  const chosen = units.filter(u => !sel.length || sel.indexOf(deptOf(u.code)) >= 0);
  const groups = view === 'sum' ? ['ADB'] : (sel.length ? sel.slice().sort() : allDepts);
  const unitsOf = (g: string): IDept[] => (g === 'ADB' ? chosen : units.filter(u => deptOf(u.code) === g));
  const latest = periods[periods.length - 1];
  const periodWord = display === 'm' ? 'MTD' : 'YTD';

  const chartSeries = multi
    ? periods.map((p, pi) => ({ key: p.key, label: p.label + ' (' + TYPES.filter(t => t.key === shownTypes[0])[0].text + ')', color: PERIOD_COLORS[pi % PERIOD_COLORS.length], values: groups.map(g => valueOf(unitsOf(g), shownTypes[0], p)) }))
    : shownTypes.map(t => { const ty = TYPES.filter(x => x.key === t)[0]; return { key: t, label: ty.text, color: ty.color, values: groups.map(g => valueOf(unitsOf(g), t, latest)) }; });

  const nOptions = display === 'm'
    ? [{ key: '1', text: '1' }, { key: '2', text: '2' }, { key: '3', text: '3' }, { key: '6', text: '6' }, { key: '12', text: '12' }]
    : [{ key: '1', text: '1' }, { key: '2', text: '2' }, { key: '3', text: '3' }];

  const openGroup = (g: string): void => {
    const u = units.filter(x => deptOf(x.code) === g);
    const own = u.filter(x => x.code === g)[0] || u[0];
    if (own) openDept(own.code);
  };

  return (
    <Panel className="fr">
      <FrStyles />
      <div className="frFilters">
        <div className="frG"><span className="frL">Department</span><DeptPicker all={allDepts} selected={sel} onChange={setSel} /></div>
        <div className="frG"><span className="frL">Display</span>
          <Segmented label="Display" value={display} onChange={v => { setDisplay(v); setNPeriods('1'); }} options={[{ key: 'm', text: 'Month' }, { key: 'y', text: 'Year' }]} /></div>
        <div className="frG"><span className="frL">Count by</span>
          <Segmented label="Count by" value={count} onChange={setCount} options={[{ key: 'cum', text: 'Cumulative' }, { key: 'period', text: periodWord }]} /></div>
        <div className="frG"><span className="frL">{display === 'm' ? 'Show # Months' : 'Show # Years'}</span>
          <Segmented label={display === 'm' ? 'Show # Months' : 'Show # Years'} value={nPeriods} onChange={setNPeriods} options={nOptions} /></div>
        <div className="frG"><span className="frL">View</span>
          <Segmented label="View" value={view} onChange={setView} options={[{ key: 'dept', text: 'By department' }, { key: 'sum', text: 'Summary' }]} /></div>
        <div className="frG"><span className="frL">Report type</span>
          <div className="seg" role="group" aria-label="Report type">
            {TYPES.map(t => {
              const on = shownTypes.indexOf(t.key) >= 0;
              const off = t.key === 'users' && isMissing('head');
              return <button key={t.key} type="button" className={on ? 'on' : ''} aria-pressed={on} disabled={off}
                title={off ? 'Users: ' + NOT_SOURCED : undefined} onClick={() => pickType(t.key)}>{t.text}</button>;
            })}
          </div>
        </div>
      </div>
      <p className="frHint">
        {(count === 'cum' ? 'Cumulative: from Day 1 up to ' : periodWord + ': only the count for ') + (count === 'cum' && latest.end === last ? 'the last refresh (Data as of, above)' : latest.label + (latest.end === last ? ', up to the last refresh' : '')) + '. '}
        {multi ? 'Several periods are shown, so one report type at a time.' : 'Documents, Records and Physical can be combined while one period is shown.'}
      </p>
      <div className="frStrip">
        {TYPES.map(t => (
          <div className="frCell" key={t.key}><InfoIcon text={TIPS[t.key]} /><div className="l">{t.text}</div>
            {t.key === 'users' && isMissing('head')
              ? <div className="v" style={{ fontSize: 15, fontWeight: 400, color: '#8A97A8', lineHeight: '29px' }}>{NOT_SOURCED}</div>
              : <div className="v">{F(valueOf(chosen, t.key, latest))}</div>}</div>
        ))}
      </div>
      <GroupedColumns groups={groups} series={chartSeries} onGroup={openGroup}
        sub={(multi
          ? 'Compares ' + TYPES.filter(t => t.key === shownTypes[0])[0].text.toLowerCase() + ' across the last ' + periods.length + (display === 'm' ? ' months' : ' years') + ', one column per period'
          : 'Compares ' + shownTypes.map(t => TYPES.filter(x => x.key === t)[0].text.toLowerCase()).join(' and ') + ' side by side')
          + (view === 'sum' ? ' for ADB as a whole' : ' for each department') + '. '
          + (count === 'cum' ? 'Cumulative: everything from Day 1 up to ' + latest.label + '.' : periodWord + ': only what was added in ' + latest.label + '.')
          + ' Hover a column to see its figure.'}
        title={(multi ? TYPES.filter(t => t.key === shownTypes[0])[0].text + ' by ' + (display === 'm' ? 'month' : 'year')
          : shownTypes.map(t => TYPES.filter(x => x.key === t)[0].text).join(' and '))
          + (view === 'sum' ? ', bank-wide' : ' by department') + ', ' + (count === 'cum' ? 'cumulative' : periodWord)} />
    </Panel>
  );
};
