/*
 * Where imported manual data lives in SharePoint (5 Nov 2026).
 *
 * A hidden document library "EDRMS Manual Data" on the report's own site holds
 *   current.json   the counts per unit and the site list the report reads
 *   history.json   the last 100 imports, loaded and refused
 * When an Owner first imports, the library is created with its own
 * permissions: Owners keep Full Control, Members are set to Read. So only
 * Owners and site collection admins can change the data, even outside the
 * report; everyone who can see the site can read it.
 * No names or emails are ever written here.
 */
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { IManualData, IIssue } from './importRules';

export interface IHistoryEntry {
  at: string; by: string; fileName: string; status: 'loaded' | 'refused';
  sites: number; people: number; units: number; problems: number;
}

export interface IManualStore {
  load(): Promise<IManualData | null>;
  history(): Promise<IHistoryEntry[]>;
  save(data: IManualData): Promise<void>;
  logRefused(fileName: string, by: string, issues: IIssue[]): Promise<void>;
}

const LIB_TITLE = 'EDRMS Manual Data';
const LIB_URL = 'EDRMSManualData';
const JSON_HEAD = { Accept: 'application/json;odata=nometadata', 'Content-Type': 'application/json;odata=nometadata', 'odata-version': '' };

export function createManualStore(http: SPHttpClient, webUrl: string, webRelUrl: string): IManualStore {
  const api = webUrl.replace(/\/$/, '') + '/_api/web';
  const folder = (webRelUrl === '/' ? '' : webRelUrl.replace(/\/$/, '')) + '/' + LIB_URL;
  const esc = (s: string): string => s.replace(/'/g, "''");

  const get = (u: string): Promise<SPHttpClientResponse> => http.get(u, SPHttpClient.configurations.v1, { headers: { Accept: 'application/json;odata=nometadata' } });
  const post = (u: string, body?: string, headers?: Record<string, string>): Promise<SPHttpClientResponse> =>
    http.post(u, SPHttpClient.configurations.v1, { headers: headers || JSON_HEAD, body });
  const ok = async (r: SPHttpClientResponse, what: string): Promise<SPHttpClientResponse> => {
    if (!r.ok) throw new Error(what + ' (SharePoint answered ' + r.status + ')');
    return r;
  };

  const readJson = async <T>(name: string): Promise<T | null> => {
    const r = await get(api + "/GetFileByServerRelativeUrl('" + esc(folder + '/' + name) + "')/$value");
    if (r.status === 404 || r.status === 400) return null;
    if (!r.ok) throw new Error('Could not read ' + name + ' (' + r.status + ')');
    try { return JSON.parse(await r.text()) as T; } catch { return null; }
  };

  const writeJson = async (name: string, value: unknown): Promise<void> => {
    await ok(await post(api + "/GetFolderByServerRelativeUrl('" + esc(folder) + "')/Files/add(url='" + name + "',overwrite=true)",
      JSON.stringify(value), { Accept: 'application/json;odata=nometadata', 'Content-Type': 'application/octet-stream', 'odata-version': '' }), 'Could not save ' + name);
  };

  /** Creates the library on first use and limits Members to Read. */
  const ensureLibrary = async (): Promise<void> => {
    const r = await get(api + "/lists/getbytitle('" + esc(LIB_TITLE) + "')?$select=Id");
    if (r.ok) return;
    await ok(await post(api + '/lists', JSON.stringify({ Title: LIB_URL, BaseTemplate: 101, Hidden: true, Description: 'Manual data for the EDRMS Utilization Report. Changed only through the report\'s Import data.' })), 'Could not create the data library');
    // Created under its URL name, then given its display title.
    await ok(await post(api + "/lists/getbytitle('" + LIB_URL + "')", JSON.stringify({ Title: LIB_TITLE }),
      { ...JSON_HEAD, 'IF-MATCH': '*', 'X-HTTP-Method': 'MERGE' }), 'Could not name the data library');
    const list = api + "/lists/getbytitle('" + esc(LIB_TITLE) + "')";
    await ok(await post(list + '/breakroleinheritance(copyRoleAssignments=true,clearSubscopes=true)'), 'Could not set the library permissions');
    const members = await get(api + '/AssociatedMemberGroup?$select=Id');
    if (members.ok) {
      const m = await members.json() as { Id: number };
      const reader = await (await get(api + '/RoleDefinitions/GetByType(2)?$select=Id')).json() as { Id: number };
      for (const t of [3, 6]) { // Contributor, Editor
        const rd = await get(api + '/RoleDefinitions/GetByType(' + t + ')?$select=Id');
        if (rd.ok) { const d = await rd.json() as { Id: number }; await post(list + '/RoleAssignments/RemoveRoleAssignment(principalid=' + m.Id + ',roledefid=' + d.Id + ')'); }
      }
      await post(list + '/RoleAssignments/AddRoleAssignment(principalid=' + m.Id + ',roledefid=' + reader.Id + ')');
    }
  };

  const addHistory = async (e: IHistoryEntry): Promise<void> => {
    const h = (await readJson<IHistoryEntry[]>('history.json')) || [];
    h.unshift(e);
    await writeJson('history.json', h.slice(0, 100));
  };

  return {
    load: () => readJson<IManualData>('current.json').catch(() => null),
    history: async () => (await readJson<IHistoryEntry[]>('history.json').catch(() => null)) || [],
    save: async (data: IManualData) => {
      await ensureLibrary();
      await writeJson('current.json', data);
      await addHistory({ at: data.importedAt, by: data.importedBy, fileName: data.fileName, status: 'loaded',
        sites: data.sites.length, people: Object.keys(data.units).reduce((a, k) => a + data.units[k].headcount, 0),
        units: Object.keys(data.units).length, problems: 0 });
    },
    logRefused: async (fileName: string, by: string, issues: IIssue[]) => {
      try {
        await ensureLibrary();
        await addHistory({ at: new Date().toISOString(), by, fileName, status: 'refused', sites: 0, people: 0, units: 0, problems: issues.length });
      } catch { /* the refusal itself is shown on screen; logging is best effort */ }
    }
  };
}
