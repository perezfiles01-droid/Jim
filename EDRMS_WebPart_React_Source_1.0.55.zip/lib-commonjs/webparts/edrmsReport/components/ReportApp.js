"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReportApp = void 0;
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var Report_module_scss_1 = tslib_1.__importDefault(require("./Report.module.scss"));
var data_1 = require("../lib/data");
var ImportPanel_1 = require("./ImportPanel");
var exporters_1 = require("../lib/exporters");
var format_1 = require("../lib/format");
var BankWide_1 = require("../dashboards/BankWide");
var DepartmentInsights_1 = require("../dashboards/DepartmentInsights");
var ui_1 = require("./ui");
/* Text size: Large is the default, as readers are often older. */
var ZOOM = { standard: 1, large: 1.25, xlarge: 1.5 };
var SIDEBAR_KEY = 'edrms-sidebar-closed';
var ICONS = {
    bw: React.createElement("svg", { viewBox: "0 0 16 16" },
        React.createElement("circle", { cx: "8", cy: "8", r: "6" }),
        React.createElement("circle", { cx: "8", cy: "8", r: "2.5", fill: "currentColor" })),
    dp: React.createElement("svg", { viewBox: "0 0 16 16" },
        React.createElement("rect", { x: "2", y: "2", width: "5", height: "5" }),
        React.createElement("rect", { x: "9", y: "2", width: "5", height: "5" }),
        React.createElement("rect", { x: "2", y: "9", width: "5", height: "5" }),
        React.createElement("rect", { x: "9", y: "9", width: "5", height: "5" })),
    pj: React.createElement("svg", { viewBox: "0 0 16 16" },
        React.createElement("path", { d: "M8 2l6 6-6 6-6-6z" })),
    fp: React.createElement("svg", { viewBox: "0 0 16 16" },
        React.createElement("path", { d: "M3 4h10M3 8h10M3 12h10" })),
    rd: React.createElement("svg", { viewBox: "0 0 16 16" },
        React.createElement("circle", { cx: "8", cy: "8", r: "6" }),
        React.createElement("path", { d: "M8 5v3l2 1" })),
    ra: React.createElement("svg", { viewBox: "0 0 16 16" },
        React.createElement("rect", { x: "2", y: "3", width: "12", height: "4" }),
        React.createElement("path", { d: "M3 7v6h10V7M6 10h4" }))
};
var FUTURE = [
    { key: 'pj', text: 'Project Insights' },
    { key: 'fp', text: 'Institutional File Plan' },
    { key: 'rd', text: 'Retention & Disposal' },
    { key: 'ra', text: 'Records & Archive Holdings' }
];
function readClosed() {
    try {
        return localStorage.getItem(SIDEBAR_KEY) === '1';
    }
    catch (_a) {
        return false;
    }
}
var ReportApp = function (props) {
    var base = React.useMemo(data_1.loadReportData, []);
    // Imported manual data (Import data) replaces sample figures for every reader.
    var _a = React.useState(null), manual = _a[0], setManual = _a[1];
    var _b = React.useState(false), importing = _b[0], setImporting = _b[1];
    React.useEffect(function () { if (props.store)
        props.store.load().then(setManual, function () { return setManual(null); }); }, [props.store]);
    var data = React.useMemo(function () { return (0, data_1.applyManual)(base, manual); }, [base, manual]);
    var _c = React.useState(props.dashboard), dash = _c[0], setDash = _c[1];
    var _d = React.useState(undefined), focus = _d[0], setFocus = _d[1];
    var _e = React.useState(readClosed), closed = _e[0], setClosed = _e[1];
    var _f = React.useState(false), busy = _f[0], setBusy = _f[1];
    var page = React.useRef(null);
    var root = React.useRef(null);
    React.useEffect(function () { return setDash(props.dashboard); }, [props.dashboard]);
    var go = function (d) {
        setDash(d);
        if (d === 'bw')
            setFocus(undefined);
        if (root.current)
            root.current.scrollIntoView({ block: 'start' });
    };
    var openDept = function (code) { setFocus(code); go('dp'); };
    var toggle = function () {
        var next = !closed;
        setClosed(next);
        try {
            localStorage.setItem(SIDEBAR_KEY, next ? '1' : '0');
        }
        catch ( /* private window */_a) { /* private window */ }
    };
    var _g = React.useState(false), menu = _g[0], setMenu = _g[1];
    var _h = React.useState(''), busyText = _h[0], setBusyText = _h[1];
    React.useEffect(function () {
        if (!menu)
            return;
        var close = function () { return setMenu(false); };
        var key = function (e) { if (e.key === 'Escape')
            setMenu(false); };
        document.addEventListener('click', close);
        document.addEventListener('keydown', key);
        return function () { document.removeEventListener('click', close); document.removeEventListener('keydown', key); };
    }, [menu]);
    var name = dash === 'bw' ? 'Bank-wide Oversight' : 'Department Insights';
    // The capture libraries do not understand CSS zoom, so the page is drawn at
    // standard size and the text size is put back afterwards.
    var run = function (text, job) {
        if (!page.current || busy)
            return;
        setMenu(false);
        setBusy(true);
        setBusyText(text);
        var r = root.current, zoom = r ? r.style.getPropertyValue('zoom') : '';
        if (r)
            r.style.setProperty('zoom', '1');
        var done = function () { if (r)
            r.style.setProperty('zoom', zoom); setBusy(false); };
        job().then(done, function (e) { console.error('[EDRMS export]', e); done(); });
    };
    var pdf = function () { return run('Preparing PDF', function () { return (0, exporters_1.exportPdf)(page.current, name); }); };
    /* RAC Item 8 (22 Oct 2026): PowerPoint, one slide per breakdown and section. */
    var pptx = function () { return run('Preparing PowerPoint', function () {
        var el = page.current;
        var pick = function (q) { return ((el.querySelector(q) || {}).textContent || '').trim(); };
        return (0, exporters_1.exportPptx)(el, {
            name: name,
            desc: pick('.band .bd'), asOf: (0, format_1.refreshLabel)(),
            // Each box of the category bar as on screen: "Category: RM, HQ  ·  Sub-category: ...".
            filter: dash === 'bw' ? 'All Departments / Offices / RMs / ROs'
                : Array.from(el.querySelectorAll('.dash-dp > .panel:first-of-type .cgG')).map(function (g) {
                    return ((g.querySelector('.cgL') || {}).textContent || '') + ': ' + ((g.querySelector('.ms-Dropdown-title') || {}).textContent || '').trim();
                }).join('  \u00b7  ')
        });
    }); };
    var bandTools = (React.createElement(React.Fragment, null,
        React.createElement("span", { className: "asof" },
            React.createElement("i", null),
            "Data as of",
            React.createElement("b", null, (0, format_1.refreshLabel)())),
        props.canImport && props.store && (React.createElement("button", { type: "button", className: "pdfBtn impOpen", "data-html2canvas-ignore": "true", onClick: function () { return setImporting(true); }, title: "Owners and admins: load the manual data template" },
            React.createElement("svg", { viewBox: "0 0 16 16", "aria-hidden": "true" },
                React.createElement("path", { d: "M8 11V2M4.5 5.5 8 2l3.5 3.5M2.5 10.5v3h11v-3" })),
            "Import data")),
        React.createElement("span", { className: "xMenuWrap", "data-html2canvas-ignore": "true" },
            React.createElement("button", { type: "button", className: "pdfBtn", disabled: busy, "aria-haspopup": "menu", "aria-expanded": menu, onClick: function (e) { e.stopPropagation(); setMenu(!menu); } },
                React.createElement(ui_1.DownloadGlyph, null),
                busy ? busyText : 'Export',
                !busy && React.createElement("span", { className: "xCaret", "aria-hidden": "true" }, "\u25BE")),
            menu && (React.createElement("div", { className: "xMenu", role: "menu", onClick: function (e) { return e.stopPropagation(); } },
                React.createElement("button", { type: "button", role: "menuitem", onClick: pdf },
                    React.createElement("span", { className: "xIc pdf" }, "PDF"),
                    React.createElement("span", null,
                        React.createElement("b", null, "PDF"),
                        React.createElement("small", null, "The dashboard as on screen"))),
                React.createElement("button", { type: "button", role: "menuitem", onClick: pptx },
                    React.createElement("span", { className: "xIc ppt" }, "PPT"),
                    React.createElement("span", null,
                        React.createElement("b", null, "PowerPoint"),
                        React.createElement("small", null, "One slide per breakdown and section, editable title and key points"))))))));
    return (React.createElement("div", { ref: root, className: Report_module_scss_1.default.report, style: { zoom: ZOOM[props.textSize] || 1.25 } },
        props.showSidebar && (React.createElement("nav", { className: 'side' + (closed ? ' closed' : ''), "aria-label": "Dashboards" },
            React.createElement("div", { className: "brand" },
                React.createElement("button", { type: "button", className: "menuBtn", onClick: toggle, "aria-expanded": !closed, title: closed ? 'Open navigation' : 'Close navigation', "aria-label": closed ? 'Open navigation' : 'Close navigation' },
                    React.createElement("svg", { viewBox: "0 0 24 24" },
                        React.createElement("path", { d: "M4 6h16M4 12h16M4 18h16" }))),
                React.createElement("div", { className: "t1" }, "EDRMS Utilization Report"),
                React.createElement("div", { className: "t2" }, "Asian Development Bank")),
            React.createElement("div", { className: "grp" }, "Key views"),
            React.createElement("button", { type: "button", className: 'nav' + (dash === 'bw' ? ' on' : ''), "aria-current": dash === 'bw' ? 'page' : undefined, title: "Bank-wide Oversight", onClick: function () { return go('bw'); } },
                ICONS.bw,
                React.createElement("span", { className: "navTx" }, "Bank-wide Oversight")),
            React.createElement("button", { type: "button", className: 'nav' + (dash === 'dp' ? ' on' : ''), "aria-current": dash === 'dp' ? 'page' : undefined, title: "Department Insights", onClick: function () { return go('dp'); } },
                ICONS.dp,
                React.createElement("span", { className: "navTx" }, "Department Insights")),
            React.createElement("div", { className: "grp" }, "For future release"),
            FUTURE.map(function (f) { return (React.createElement("button", { type: "button", key: f.key, className: "nav future", "aria-disabled": "true", title: f.text + ' (future release)' },
                ICONS[f.key],
                React.createElement("span", { className: "navTx" }, f.text))); }))),
        React.createElement("div", { className: "main", ref: page }, dash === 'bw'
            ? React.createElement(BankWide_1.BankWide, { data: data, openDept: openDept, bandTools: bandTools })
            : React.createElement(DepartmentInsights_1.DepartmentInsights, { data: data, openDept: openDept, bandTools: bandTools, focus: focus })),
        importing && props.canImport && props.store && (React.createElement(ImportPanel_1.ImportPanel, { store: props.store, user: props.userName || 'Site owner', role: props.roleLabel || 'Site owner', current: manual, knownUnits: base.depts.map(function (d) { return d.code; }), onClose: function () { return setImporting(false); }, onLoaded: setManual }))));
};
exports.ReportApp = ReportApp;
//# sourceMappingURL=ReportApp.js.map