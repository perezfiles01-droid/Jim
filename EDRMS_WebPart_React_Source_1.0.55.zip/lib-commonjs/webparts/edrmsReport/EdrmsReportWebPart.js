"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var ReactDom = tslib_1.__importStar(require("react-dom"));
var sp_core_library_1 = require("@microsoft/sp-core-library");
var sp_property_pane_1 = require("@microsoft/sp-property-pane");
var sp_webpart_base_1 = require("@microsoft/sp-webpart-base");
var sp_page_context_1 = require("@microsoft/sp-page-context");
var manualStore_1 = require("./lib/manualStore");
var strings = tslib_1.__importStar(require("EdrmsReportWebPartStrings"));
var ReportApp_1 = require("./components/ReportApp");
var EdrmsReportWebPart = /** @class */ (function (_super) {
    tslib_1.__extends(EdrmsReportWebPart, _super);
    function EdrmsReportWebPart() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    EdrmsReportWebPart.prototype.render = function () {
        var web = this.context.pageContext.web;
        if (!this._store)
            this._store = (0, manualStore_1.createManualStore)(this.context.spHttpClient, web.absoluteUrl, web.serverRelativeUrl);
        // Import data is offered only to people who can manage this site: Owners
        // (Full Control) and site collection admins. Members and Visitors never see it,
        // and the data library refuses their writes anyway (lib/manualStore.ts).
        var canImport = !!web.permissions && web.permissions.hasPermission(sp_page_context_1.SPPermission.manageWeb);
        var isAdmin = !!this.context.pageContext.legacyPageContext && !!this.context.pageContext.legacyPageContext.isSiteAdmin;
        var element = React.createElement(ReportApp_1.ReportApp, {
            dashboard: this.properties.dashboard || 'bw',
            showSidebar: this.properties.showSidebar !== false,
            textSize: this.properties.textSize || 'large',
            store: this._store,
            canImport: canImport,
            userName: this.context.pageContext.user.displayName,
            roleLabel: isAdmin ? 'Site collection admin' : 'Site owner (Full control)'
        });
        ReactDom.render(element, this.domElement);
    };
    EdrmsReportWebPart.prototype.onDispose = function () {
        ReactDom.unmountComponentAtNode(this.domElement);
    };
    Object.defineProperty(EdrmsReportWebPart.prototype, "dataVersion", {
        get: function () {
            return sp_core_library_1.Version.parse('1.0');
        },
        enumerable: false,
        configurable: true
    });
    EdrmsReportWebPart.prototype.getPropertyPaneConfiguration = function () {
        return {
            pages: [{
                    header: { description: strings.PropertyPaneDescription },
                    groups: [{
                            groupName: strings.SettingsGroupName,
                            groupFields: [
                                (0, sp_property_pane_1.PropertyPaneDropdown)('dashboard', {
                                    label: strings.DashboardLabel,
                                    options: [
                                        { key: 'bw', text: 'Bank-wide Oversight' },
                                        { key: 'dp', text: 'Department Insights' }
                                    ]
                                }),
                                (0, sp_property_pane_1.PropertyPaneToggle)('showSidebar', { label: strings.SidebarLabel, onText: 'Shown', offText: 'Hidden' }),
                                (0, sp_property_pane_1.PropertyPaneDropdown)('textSize', {
                                    label: strings.TextSizeLabel,
                                    options: [
                                        { key: 'standard', text: 'Standard (as designed)' },
                                        { key: 'large', text: 'Large (25% larger)' },
                                        { key: 'xlarge', text: 'Extra large (50% larger)' }
                                    ]
                                })
                            ]
                        }]
                }]
        };
    };
    return EdrmsReportWebPart;
}(sp_webpart_base_1.BaseClientSideWebPart));
exports.default = EdrmsReportWebPart;
//# sourceMappingURL=EdrmsReportWebPart.js.map