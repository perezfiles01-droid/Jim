# EDRMS Utilization Report: SharePoint web part (React + Fluent UI)

The approved EDRMS Utilization Report (Bank-wide Oversight and Department
Insights) rebuilt as an SPFx 1.23 web part in **React 17 with Fluent UI 8**,
so it can be maintained as normal components rather than one HTML file.

It matches the approved version screen for screen. Every colour, font size
and spacing value in `Report.module.scss` was measured from the approved web
part as it renders in SharePoint, and it shows the same sample figures, so
any difference can be checked number for number.

## Install (no build needed)

1. Upload `sharepoint/solution/edrms-utilization-report.sppkg` to the
   App Catalog (choose **Replace** if Util sample is already there).
2. Edit a page, add a **Full-width section**, add **EDRMS Utilization Report**, then Republish.
3. Web part settings: **Dashboard on this page**, **Show the report's own
   sidebar**, **Text size** (Large by default, as readers are often older).

It keeps the solution ID, feature ID and web part ID of the earlier "Util
sample" package (1.0.38 and before), so uploading it with **Replace**
upgrades that app, and pages already using the web part switch to this
version with their settings kept.

## Build

Node 22 (22.14 or later).

```
npm ci
npm run build
```

Output: `sharepoint/solution/edrms-utilization-report.sppkg`.
Bump `version` in `config/package-solution.json` before uploading over an
earlier build.

## Where things are

```
src/webparts/edrmsReport/
  EdrmsReportWebPart.ts        web part entry and property pane
  components/
    ReportApp.tsx              sidebar, dashboard switching, Export to PDF
    Report.module.scss         the whole look (measured from the approved version)
    ui.tsx                     band, panel, KPI cards, (i) tooltips, search,
                               segmented buttons, pager, Export table button
    DataTable.tsx              sortable, paged table used everywhere
    DeptFilter.tsx             the Filter button (department checklist, Apply/Reset)
    charts.tsx                 bar list, column chart, column + running total
                               chart, donut (plain SVG)
  dashboards/
    BankWide.tsx               Bank-wide Oversight: 4 cards and their breakdowns,
                               physical counterparts, comparison, declaration trend
    DepartmentInsights.tsx     Department Insights: department and site pickers,
                               5 cards and their breakdowns, library usage
  lib/
    data.ts                    data types, loadReportData(), derived figures
    exporters.ts               Excel (xlsx-js-style) and PDF (html2canvas + jsPDF)
    format.ts                  number formatting, axis rounding
  data/sampleData.json         the approved prototype's sample figures
```

## Import data (1.0.53, 5 Nov 2026)

An **Import data** button sits beside Export, shown only to people who can
manage the site (`SPPermission.manageWeb`: Owners with Full Control and site
collection admins). Members and Visitors never see it.

- One template, `EDRMS_Utilization_Manual_Data.xlsx`, downloaded from the
  panel: tabs Sites, People, Departments, Code mapping (optional), plus
  Instructions and Valid values. Rules: `lib/importRules.ts`.
- People is the AP All Users export (the raw pivot can be pasted as it is)
  plus a Completed EDRMS training column. Headcount, staff type and training
  are counted from it; only counts per unit are saved, never names or emails.
- Saved to a hidden library **EDRMS Manual Data** on the site
  (`current.json`, `history.json`; `lib/manualStore.ts`). It is created on
  the first import with its own permissions: Members are set to Read, so only
  Owners can change it.
- Any broken rule refuses the whole file and lists every problem.
- Test: `node test/build-test-page.js`, then `node test/import-test.js`
  (`AP_FILE=<path>` runs it with the real AP export).

## Connecting the real data

Everything on screen is read through `IReportData` in `lib/data.ts`.
Today `loadReportData()` returns `data/sampleData.json`. To connect the
reporting database, replace that function with a call to the API that
returns the same shapes (`IDept`, `ISite`, `ILibrary`, `ITrend`, `ITotals`).
No component needs to change.

A few figures are **sample formulas** in `lib/data.ts` until a source exists:
training completion, internal/external visitor split, site created date,
library folders and active users, and the monthly documents history. Each
is one function to replace.

## Why the charts are SVG rather than Fluent UI charts

Fluent UI is used for the controls (drop-downs, tooltips, the filter
pop-up, check boxes). The charts are small SVG components because Fluent
UI's chart package cannot reproduce the approved charts exactly: the
records trend uses bars with a running total on a second axis, the Top 10
lists select rows in the table beside them, and the comparison uses two
independently scaled bar columns. Each chart is one component in
`charts.tsx` (about 40 lines each) and maps to a native Power BI visual.

## Checks run before release

- `npm run build`: lint and TypeScript clean.
- Browser test (Playwright, Chromium): both dashboards and all nine
  breakdowns draw with no script errors; search, Filter, paging, sorting,
  department links into Department Insights, the site picker, chart
  selection and "+N more" ties, Year/Month drill-downs, Export table (.xlsx)
  and Export to PDF all work.
- Figures checked against the approved version: 1,032 sites, 11,800
  headcount, 9,420 active, 2,380 no access, 9,405 trained (80.0%),
  3.47M documents, 1,562,850 new documents, 1,188 GB, 21,646 records,
  0.62% declaration rate, 3,186 declaring users, 3,830 counterparts (17.7%),
  17,240 visitors (15,742 internal), 1,600 libraries, 82,006 folders.

Not yet checked inside a SharePoint tenant.
