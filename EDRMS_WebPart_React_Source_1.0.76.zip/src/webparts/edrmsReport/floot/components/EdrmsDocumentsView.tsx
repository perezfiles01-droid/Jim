import * as React from 'react';
import { IDept, documentSeries, DOC_MONTHS, sum, approxHead, trainingDone } from '../helpers/edrmsData';
import { F } from '../helpers/edrmsFormat';
import { Segmented, ExportButton, InfoIcon } from './EdrmsUi';
import { isMissing, formatsOf, formatsIn, manualFor } from '../helpers/edrmsData';
import { SITE_DIRECTORY } from '../helpers/edrmsSiteDirectory';
import { useLinked, isOneOf } from '../helpers/edrmsLink';

/*
 * RAC review 23 Nov 2026, slides 8 to 13: every "View breakdown" uses one layout.
 *  - A title, then a dark "Filtered results" box with white cards beside a "Filters" box.
 *  - One table: Sites (department) and the measures. With the "Previous month"
 *    filter (slide 11) each measure splits into the previous and current month.
 *  - Clicking a department opens its Department overview.
 * SAMPLE FIGURES: month values are spread from the sample document series. A blank
 * cell means no data source carries that measure yet, never a guessed figure.
 * Web part 1.0.59: as the Floot app on 24 Nov 2026. The bar chart beside each table was
 * switched off there, so its code is left out here.
 */
type Range = 'cur' | 'prev';
const RANGES: { key: Range; text: string }[] = [{ key: 'cur', text: 'Current month' }, { key: 'prev', text: 'Previous month' }];
const NAMES = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const monthName = (i: number): string => NAMES[DOC_MONTHS[i].m] + ' ' + DOC_MONTHS[i].y;
const LAST = DOC_MONTHS.length - 1;
const NO_SOURCE = 'Not yet sourced';

/** Share of a unit's latest figure reached by the end of month i (sample growth curve). */
/* A site row follows its department's growth curve, so a department's sites add up to it in every month. */
const factor = (d: IDept, i: number): number => { const g = (d as { parent?: IDept }).parent || d; return g.docs ? documentSeries(g).held[i] / g.docs : 1; };
const at = (base: number, d: IDept, i: number): number => Math.round(base * factor(d, i));
const pctTxt = (a: number, b: number, digits = 1): string => (b ? (a / b * 100).toFixed(digits) : '0.0') + '%';

/*
 * 24 Nov 2026 (RAC slide 8 drawing): a department lists its sites, grouped Department-Division
 * as in RAC's Recommendation layout. Documents and records are RAC's own per-site figures
 * (helpers/edrmsSiteDirectory), so they add up to the department. Physical counterparts and
 * storage are the department's SAMPLE figures shared out by records and documents; inactive
 * sites are SAMPLE and add up to the department's inactive count.
 */
export type SiteRow = IDept & { parent: IDept; group: string; trained?: number };
export const isSiteRow = (d: IDept): d is SiteRow => !!(d as SiteRow).parent;
let SITE_IDLE = 0; // share of sites counted inactive, set by SitesView
const seedOf = (t: string): number => { let h = 0; for (let i = 0; i < t.length; i++) h = (h * 33 + t.charCodeAt(i)) % 9973; return h; };
/** Splits a whole number across weights so the parts add up exactly. */
function share(total: number, weights: number[]): number[] {
  const sw = weights.reduce((a, w) => a + w, 0);
  if (!sw || !total) return weights.map(() => 0);
  const raw = weights.map(w => total * w / sw), out = raw.map(Math.floor);
  let left = total - out.reduce((a, v) => a + v, 0);
  raw.map((v, i) => ({ i, f: v - Math.floor(v) })).sort((a, b) => b.f - a.f).forEach(x => { if (left > 0) { out[x.i]++; left--; } });
  return out;
}
function sitesOf(dept: IDept): SiteRow[] {
  const list = SITE_DIRECTORY.filter(r => r.dept === dept.code);
  // Only sites with records can hold physical counterparts, and never more than their records.
  const phys = share(Math.min(dept.phys, list.reduce((a, r) => a + r.rec, 0)), list.map(r => r.rec));
  const gb10 = share(Math.round(dept.gb * 10), list.map(r => r.docs || 1));
  const idle = new Set(list.map((r, i) => ({ i, h: seedOf(r.site) })).sort((a, b) => b.h - a.h).slice(0, Math.round(dept.sites * SITE_IDLE)).map(x => x.i));
  return list.map((r, i) => ({
    code: r.site, name: r.division, sites: r.sites, users: 0, head: 0, docs: r.docs, rec: r.rec, phys: phys[i],
    declaring: 0, creating: 0, idle180: idle.has(i) ? 1 : 0, visitors: 0, views: 0, gb: gb10[i] / 10, recgb: 0,
    parent: dept, group: r.division && r.division !== dept.code ? dept.code + '-' + r.division : dept.code
  }));
}

/* ADB Users: one row per office, the department's own HQ sites as "<DEPT> (HQ)". Headcount, active
   users and training are shared out from the department so the offices add up to it: by each
   office's imported headcount (People tab, Office Location) where one exists, else by its number
   of sites (SAMPLE). */
function officesOf(d: IDept): SiteRow[] {
  const groups: { [g: string]: SiteRow[] } = {};
  sitesOf(d).forEach(s => { (groups[s.group] = groups[s.group] || []).push(s); });
  const keys = [d.code].filter(g => groups[g]).concat(Object.keys(groups).filter(g => g !== d.code).sort());
  const office = (g: string): string => (g === d.code ? g : g.slice(d.code.length + 1));
  const imp = keys.map(g => { if (g === d.code) return 0; const u = manualFor(office(g)); return u ? u.headcount : 0; });
  const w = imp.some(x => x > 0) ? imp : keys.map(g => groups[g].length);
  const H = share(approxHead(d), w), U = share(d.users, H), T = share(trainingDone(d), H);
  return keys.map((g, n) => ({ code: g === d.code ? d.code + ' (HQ)' : g, name: '', sites: groups[g].length, users: U[n], head: H[n], docs: 0, rec: 0, phys: 0,
    declaring: 0, creating: 0, idle180: 0, visitors: 0, views: 0, gb: 0, recgb: 0, parent: d, group: g, trained: T[n] }));
}
/** A row made of some of a department's sites or offices (an office group, or a part-ticked department). */
function aggOf(d: IDept, l: SiteRow[], code: string, group: string): SiteRow {
  const add = (f: keyof SiteRow): number => l.reduce((a, s) => a + ((s[f] as number) || 0), 0);
  return { code, name: '', sites: add('sites'), users: add('users'), head: add('head'), docs: add('docs'), rec: add('rec'), phys: add('phys'), declaring: 0, creating: 0,
    idle180: add('idle180'), visitors: 0, views: 0, gb: Math.round(add('gb') * 10) / 10, recgb: 0, parent: d, group, trained: add('trained') };
}

/* 24 Nov 2026: the Department filter follows RAC's Department Dropdown drawing: Department > office
   > site (Users: Department > office). Everything starts ticked; untick a site, or click a
   department or office bar to untick or re-tick everything under it. */
type Pick = { [dept: string]: string[] };
/** The key that stands for "nothing ticked" in a Pick (an empty Pick is everything). */
const NONE_KEY = '_none';
interface ILeaf { key: string; label: string; group: string }
const TreePicker: React.FC<{ depts: IDept[]; leaves: (d: IDept) => ILeaf[]; pick: Pick; onChange: (v: Pick) => void }> = ({ depts, leaves, pick, onChange }) => {
  const [q, setQ] = React.useState('');
  const [open, setOpen] = React.useState(false);
  const wrap = React.useRef<HTMLDivElement>(null);
  React.useEffect(() => {
    if (!open) return undefined;
    const close = (e: MouseEvent): void => { if (wrap.current && !wrap.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, [open]);
  const tree = React.useMemo(() => depts.map(d => ({ d, l: leaves(d) })), [depts]);
  const keysOf = (l: ILeaf[]): string[] => (l.length ? l.map(x => x.key) : ['*']);
  /* As RAC's drawing: everything starts ticked (nothing picked = all). Unticking narrows it;
     ticking everything again goes back to all. */
  const all = React.useMemo(() => { const m: Pick = {}; tree.forEach(t => { m[t.d.code] = keysOf(t.l); }); return m; }, [tree]);
  const none = Object.keys(pick).length === 0;
  /* 25 Nov 2026: "Select all" at the top ticks everything; clicking it again unticks
     everything (stored as { _none: [] }), so a few can then be ticked. */
  const nothing = Object.prototype.hasOwnProperty.call(pick, NONE_KEY);
  const isIn = (code: string, k: string): boolean => !nothing && (none || (pick[code] || []).indexOf(k) >= 0);
  const flip = (code: string, keys: string[]): void => {
    const base: Pick = nothing ? {} : none ? JSON.parse(JSON.stringify(all)) : JSON.parse(JSON.stringify(pick));
    const on = !keys.every(k => isIn(code, k)), cur = new Set(base[code] || []);
    keys.forEach(k => (on ? cur.add(k) : cur.delete(k)));
    if (cur.size) base[code] = Array.from(cur); else delete base[code];
    const full = Object.keys(all).every(c => (base[c] || []).length === all[c].length);
    onChange(full ? {} : Object.keys(base).length ? base : { [NONE_KEY]: [] });
  };
  const toggleAll = (): void => onChange(none ? { [NONE_KEY]: [] } : {});
  const leaf = (code: string, k: string, label: string, pad: number): React.ReactNode => (
    <div className="tpR" key={code + '/' + k} style={{ paddingLeft: pad }}>
      <label className="tpL"><input type="checkbox" checked={isIn(code, k)} onChange={() => flip(code, [k])} />{label}</label>
    </div>);
  const bar = (cls: string, key: string, label: string, code: string, keys: string[]): React.ReactNode => (
    <div className={'tpR ' + cls} key={key} role="button" tabIndex={0} title={'Tick or untick everything under ' + label}
      onClick={() => flip(code, keys)} onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); flip(code, keys); } }}>{label}</div>);
  const ql = q.trim().toLowerCase();
  const hit = (s: string): boolean => !ql || s.toLowerCase().indexOf(ql) >= 0;
  const out: React.ReactNode[] = [];
  tree.forEach(({ d, l }) => {
    const dHit = hit(d.code), lHits = l.filter(x => hit(x.label) || hit(x.group));
    if (!dHit && !lHits.length) return;
    const shown = dHit ? l : lHits;
    if (!l.length) { out.push(leaf(d.code, '*', d.code, 8)); return; }
    out.push(bar('dep', d.code, d.code, d.code, keysOf(l)));
    shown.filter(x => x.group === d.code || x.key === x.group).forEach(x => out.push(leaf(d.code, x.key, x.label, 26)));
    Array.from(new Set(shown.filter(x => x.group !== d.code && x.key !== x.group).map(x => x.group))).sort().forEach(g => {
      out.push(bar('tpG', d.code + '/' + g, g, d.code, l.filter(x => x.group === g).map(x => x.key)));
      shown.filter(x => x.group === g).forEach(x => out.push(leaf(d.code, x.key, x.label, 26)));
    });
  });
  const n = nothing ? 0 : Object.keys(pick).length;
  return (
    <div className="dp" ref={wrap}>
      <input type="search" value={q} placeholder={nothing ? 'No departments selected' : n ? n + ' department' + (n > 1 ? 's' : '') + ' selected' : 'All departments'} aria-label="Department, office or site"
        onFocus={() => setOpen(true)} onChange={e => { setQ(e.target.value); setOpen(true); }} />
      {open && <div className="dpList tp" role="tree">
        <div className="tpR tpAll"><label className="tpL"><input type="checkbox" checked={none} ref={el => { if (el) el.indeterminate = !none && !nothing; }} onChange={toggleAll} />Select all</label></div>
        {out.length ? out : <div className="tpR">No department, office or site matches.</div>}</div>}
      {nothing && (
        <div className="dpChips">
          <span className="dpChip">No departments selected</span>
          <button type="button" className="dpChip" onClick={() => onChange({})}>Select all</button>
        </div>
      )}
      {n > 0 && (
        <div className="dpChips">
          {tree.filter(t => pick[t.d.code] && pick[t.d.code].length < keysOf(t.l).length).map(({ d, l }) =>
            <span key={d.code} className="dpChip">{d.code} ({pick[d.code].length} of {keysOf(l).length})</span>)}
          {tree.length - n > 0 && <span className="dpChip">{tree.length - n} department{tree.length - n > 1 ? 's' : ''} unticked</span>}
          <button type="button" className="dpChip" onClick={() => onChange({})}>Select all</button>
        </div>
      )}
    </div>
  );
};

const CSS = `
.dv .crumb{border:0;background:none;padding:0;font:inherit;color:#0072BC;text-decoration:underline;cursor:pointer}
.dv .crumb:hover{color:#194F8E}
.dv .dpList .tpR.tpAll{background:#185E85;position:sticky;top:0;z-index:1;padding:3px 6px}
.dv .dpList .tpR.tpAll label.tpL{color:#fff;font-weight:700}
.dv .dpList .tpR.tpAll:hover{background:#194F8E}
.dv .crumbSep{margin:0 8px;color:#33475F;font-weight:400}
.dv .dvSub{margin:-4px 0 10px;color:#5B6B7D;font-size:13px}
.dv .dvTop{display:flex;flex-direction:column;gap:12px;margin:6px 0 16px}
.dv .dvBox{display:block;flex:none;border-radius:12px;padding:14px 16px;background:#185E85;color:#fff}
.dv .dvBox.fil{order:-1}
.dv .dvBox.fil h4{display:none}
.dv .dvBox h4{margin:0 0 10px;font-size:16px;font-weight:700;color:#fff}
.dv .dvBox.fil{padding:10px 16px}
.dv .dvCards{display:grid;gap:10px;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));align-items:start}
.dv .dvCard{position:relative;background:#fff;border-radius:12px;padding:12px 16px;text-align:left;box-shadow:0 1px 3px rgba(16,36,62,.12)}
.dv .dvCard .l{font-size:15px;font-weight:500;color:#10243E;padding-right:20px;line-height:1.25}
.dv .dvCard .v{font-size:28px;font-weight:700;color:#10243E;line-height:1.15;margin-top:4px}
.dv .dvCard .v.muted{font-size:15px;font-weight:400;color:#8A97A8;line-height:32px}
.dv .dvF{display:flex;flex-wrap:wrap;align-items:center;gap:10px 14px}
.dv .dvF .ttl{font-size:16px;font-weight:700;color:#fff;margin-right:6px}
.dv .dvF .ctlL{font-size:12px;font-weight:600;color:#DCE8F3;text-transform:uppercase;letter-spacing:.04em}
.dv .dvF .seg{background:#fff;border-radius:6px;white-space:nowrap}
.dv .dvDept{display:flex;gap:8px;align-items:center;flex:1 1 360px;min-width:0}
.dv .dvDept .search{flex:1 1 auto;min-width:0;background:#fff}
.dv .dvDept .fBtn{background:#fff;flex:0 0 auto}
.dv .dp{position:relative;flex:1 1 auto;min-width:0}
.dv .dvF .dvDept{flex:1 1 220px!important}
.dv .dp input[type=search]{width:100%;box-sizing:border-box;height:34px;border:1px solid #B8C4D1;border-radius:6px;padding:0 12px;font:inherit;font-size:13px;background:#fff;color:#10243E}
.dv .dpList{position:absolute;z-index:20;top:38px;left:0;right:0;max-height:260px;overflow:auto;background:#fff;border:1px solid #B8C4D1;border-radius:6px;box-shadow:0 6px 18px rgba(16,36,62,.15)}
.dv .dpList label{display:flex;gap:8px;align-items:center;justify-content:flex-start;padding:6px 10px;font-size:13px;cursor:pointer;color:#10243E}
.dv .dpList label:hover{background:#EEF4FA}
.dv .dpList input[type=checkbox]{width:16px;height:16px;margin:0;flex:0 0 16px;accent-color:#0072BC}
.dv .dpChips{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}
.dv .dpChip{font-size:12px;background:#E6F0FA;color:#0B4F8A;border-radius:12px;padding:2px 8px;border:0;cursor:pointer}
.dv .dvXp{margin-left:auto;flex:0 0 auto}
.dv .dvXp .xpBtn{background:#fff}
.dv .dvTbl{width:100%;border-collapse:separate;border-spacing:0;font-size:14px}
.dv .dvTbl th{background:#185E85;color:#fff;font-weight:700;padding:10px 12px;border-right:2px solid #fff;text-align:center}
.dv .dvTbl th.site{text-align:left;width:26%}
.dv .dvTbl thead tr.sub th{background:#A9CCEB;color:#10243E;font-weight:600;font-size:13px}
.dv .dvTbl td{padding:9px 12px;border-right:2px solid #fff;text-align:right;font-variant-numeric:tabular-nums}
.dv .dvTbl tbody tr:nth-child(odd) td{background:#E9EDF1}
.dv .dvTbl tbody tr:nth-child(even) td{background:#D5DBE2}
.dv .dvTbl tbody tr:hover td{background:#C8DDF0}
.dv .dvTbl td.site{text-align:left}
.dv .dvTbl td.site button{background:none;border:0;padding:0;font:inherit;font-weight:700;color:#10243E;text-decoration:underline;cursor:pointer}
.dv .dvTbl td.site small{display:block;font-weight:400;color:#5B6B7D;text-decoration:none}
.dv .dvTbl tfoot td{background:#10243E;color:#fff;font-weight:700}
.dv .dvTblWrap .dvTbl tbody td{height:var(--rowH,auto);padding-top:0!important;padding-bottom:0!important;line-height:1.1}
.dv .dvTblWrap .dvTbl tbody td.site small{display:none}
.dv .dvSplit{display:grid;grid-template-columns:1fr;gap:16px;align-items:start}
.dv .dvSplit{opacity:0;transition:opacity .18s ease-out}
.dv .dvSplit.ready{opacity:1}
.dv .dvTbl th,.dv .dvTbl tfoot td{white-space:nowrap}
.dv .dvSplit .dvTblWrap{overflow-y:auto!important}
.dv .dvTbl tbody tr{height:var(--rowH,auto)}
.dv .dvNote{text-align:right;font-size:14px;color:#33475F;margin-top:10px}
.dv .dvTbl td.site .tw{display:flex;align-items:center;gap:6px}
.dv .dvTbl td.site button.chev{width:18px;flex:0 0 18px;text-decoration:none;font-size:15px;line-height:1;color:#10243E;text-align:center}
.dv .dvTbl td.site span.chev{display:inline-block;width:18px;flex:0 0 18px}
.dv .dvTbl tr.lv1 td,.dv .dvTbl tr.lv2 td{font-size:13px}
.dv .dvTbl tr.lv1 td.site .nm,.dv .dvTbl tr.lv2 td.site .nm{font-weight:500;color:#33475F}
.dv .dvTbl tr.lv1.kids td.site .nm{font-weight:700;color:#10243E}
.dv .tBtn{background:none;border:0;color:#fff;font:inherit;font-size:13px;font-weight:600;cursor:pointer;padding:4px 6px}
.dv .tBtn:hover{text-decoration:underline}
.dv .dpList.tp{max-height:380px;background:#C3E4F3;border:1px solid #185E85;border-radius:4px;padding:0}
.dv .dpList .tpR{display:flex;align-items:center;gap:4px;padding:3px 10px 3px 6px;font-size:13px;color:#10243E}
.dv .dpList .tpR.dep{background:#185E85;color:#fff;font-weight:700;font-size:14px;padding:3px 6px;cursor:pointer}
.dv .dpList .tpR.dep label.tpL,.dv .dpList .tpR.tpG label.tpL{color:#fff}
.dv .dpList .tpR.tpG{background:#194F8E;color:#fff;font-weight:700;font-size:14px;padding:3px 6px;cursor:pointer}
.dv .dpList label.tpL{display:flex;gap:8px;align-items:center;padding:1px 0;cursor:pointer;justify-content:flex-start;color:#10243E}
.dv .dpList .tpR:not(.dep):not(.tpG):not(.tpAll):hover{background:#A9D6EE}
.dv .dpList{user-select:none}
.dv .dpList input:focus:not(:focus-visible){outline:none;box-shadow:none}
.dv .dpList ::selection{background:transparent}
.dv i.tri{display:inline-block;width:0;height:0;border-left:6px solid currentColor;border-top:4.5px solid transparent;border-bottom:4.5px solid transparent;transition:transform .15s;vertical-align:middle}
.dv i.tri.on{transform:rotate(90deg)}
.dv .dpList .tpR label.tpL input[type=checkbox]{accent-color:#10243E;width:14px;height:14px;flex:0 0 14px}
.dv .dpList .tpR label.tpL{font-size:14px}
`;

/* 23 Nov 2026: the last fitted sizes, reused when the next breakdown opens so it
   draws at its final size straight away instead of growing and then shrinking. */
const FITS: { [view: string]: { [k: string]: string } } = {};

interface ICard { label: string; value: (list: IDept[], i: number) => string | null; info: string }
interface ICol { label: string; cell: (d: IDept, i: number) => string | null; total: (list: IDept[], i: number) => string | null }

interface IBreakdownProps {
  title: string;
  sub?: string;
  cards: ICard[];
  cols: ICol[];
  depts: IDept[];
  openDept: (c: string) => void;
  sortBy: (d: IDept, i: number) => number;
  after?: React.ReactNode;
  /** Sites, documents, records and physical: department > office > site. */
  bySite?: boolean;
  /** ADB Users: the tree goes one level, department to office; people are not counted per site. */
  byOffice?: boolean;
}

/* 25 Nov 2026: the way back to the Bank-wide overview is the breadcrumb on the
   breakdown's title ("Bank-wide Overview > EDRMS Sites"), the only way back. */
export const BackCtx = React.createContext<(() => void) | null>(null);

export const Breakdown: React.FC<IBreakdownProps> = p => {
  const home = React.useContext(BackCtx);
  // 25 Nov 2026: the date range and the ticked departments and sites are kept in the page address.
  const [range, setRange] = useLinked<Range>('bd.range', 'cur', isOneOf(['cur', 'prev']));
  const [pick, setPick] = useLinked<Pick>('bd.pick', {}, v => {
    if (!v || typeof v !== 'object' || Array.isArray(v)) return false;
    const o = v as { [k: string]: unknown };
    return Object.keys(o).every(code => {
      if (code === NONE_KEY) return Array.isArray(o[code]) && (o[code] as unknown[]).length === 0;
      const d = p.depts.filter(x => x.code === code)[0];
      const arr = o[code];
      if (!d || !Array.isArray(arr)) return false;
      const keys = (p.byOffice ? officesOf(d).map(s => s.group) : p.bySite ? sitesOf(d).map(s => s.code) : []);
      return arr.every(k => typeof k === 'string' && keys.indexOf(k) >= 0);
    });
  });
  const sel = Object.keys(pick);
  const LAST_FIT = FITS[p.title + '|' + range] || (FITS[p.title + '|' + range] = {});
  /* The tree's leaves: sites, or offices for ADB Users. A part-ticked department becomes a row
     of only its ticked leaves, so cards, table and totals follow exactly what is ticked. */
  const leafRows = (d: IDept): SiteRow[] => (p.byOffice ? officesOf(d) : p.bySite ? sitesOf(d) : []);
  const leafKey = (s: SiteRow): string => (p.byOffice ? s.group : s.code);
  const chosen = (d: IDept): SiteRow[] => { const k = pick[d.code], l = leafRows(d); return k ? l.filter(s => k.indexOf(leafKey(s)) >= 0) : l; };
  const depts = React.useMemo(() => (sel.length
    ? p.depts.filter(d => pick[d.code]).map(d => { const l = leafRows(d), c = chosen(d); return !l.length || c.length === l.length ? d : aggOf(d, c, d.code, d.code); })
    : p.depts), [p.depts, pick]);
  /* Tree state: which departments and office groups are open. Picking one department opens it. */
  const [open, setOpen] = React.useState<{ [k: string]: boolean }>({});
  const tree = !!(p.bySite || p.byOffice);
  React.useEffect(() => { if (tree && sel.length === 1) setOpen(o => ({ ...o, [sel[0]]: true })); }, [tree, sel.join(',')]);
  const toggle = (k: string): void => setOpen(o => ({ ...o, [k]: !o[k] }));
  const months = range === 'prev' ? [LAST - 1, LAST] : [LAST];
  const latest = LAST;
  const totalLabel = depts.length !== p.depts.length ? 'Total, ' + depts.length + ' shown' : 'All departments';
  const bySort = <T extends IDept>(l: T[]): T[] => l.slice().sort((a, b) => p.sortBy(b, latest) - p.sortBy(a, latest));
  const rows = bySort(depts);
  /* Department rows, then (when open) the department's own sites and its office groups,
     each office group opening to its sites. Totals count department rows only. */
  const items: { d: IDept; depth: number; key: string; kids: boolean }[] = [];
  rows.forEach(d0 => {
    const d = isSiteRow(d0) ? d0.parent : d0;
    items.push({ d: d0, depth: 0, key: d.code, kids: tree });
    if (!tree || !open[d.code]) return;
    const picked = chosen(d);
    if (p.byOffice) { picked.forEach(o => items.push({ d: o, depth: 1, key: d.code + '/' + o.group, kids: false })); return; }
    const groups: { [g: string]: SiteRow[] } = {};
    picked.forEach(s => { (groups[s.group] = groups[s.group] || []).push(s); });
    bySort(groups[d.code] || []).forEach(s => items.push({ d: s, depth: 1, key: d.code + '/' + s.code, kids: false }));
    Object.keys(groups).filter(g => g !== d.code).sort().forEach(g => {
      const k = d.code + '/' + g, l = groups[g];
      items.push({ d: aggOf(d, l, g, g), depth: 1, key: k, kids: true });
      if (open[k]) bySort(l).forEach(s => items.push({ d: s, depth: 2, key: k + '/' + s.code, kids: false }));
    });
  });
  /* 23 Nov 2026: the whole breakdown fits one screen; the table scrolls inside its box. */
  const tblRef = React.useRef<HTMLDivElement>(null);
  const [tblH, setTblH] = React.useState<number>(0);
  React.useLayoutEffect(() => {
    const fit = (): void => {
      const el = tblRef.current;
      if (!el || !el.offsetWidth) return;
      const r = el.getBoundingClientRect();
      const zoom = r.width / el.offsetWidth || 1; // the report's text-size zoom
      // 25 Nov 2026: fit to the bottom of the report itself, which is sized to the screen.
      const host = el.closest('.edrms-report');
      const bottom = host ? host.getBoundingClientRect().bottom : window.innerHeight;
      const avail = (bottom - r.top - 8) / zoom;
      setTblH(Math.max(120, Math.round(avail)));
      /* 23 Nov 2026: rows shrink or grow so the whole table, total included, fits
         the window on any screen, instead of scrolling inside its box. */
      const tb = el.querySelector('tbody');
      const n = tb ? tb.rows.length : 0;
      if (n) {
        const thEl = el.querySelector('thead') as HTMLElement | null, tfEl = el.querySelector('tfoot') as HTMLElement | null;
        const th = thEl ? thEl.offsetHeight : 0, tf = tfEl ? tfEl.offsetHeight : 0;
        const rh = Math.floor((avail - th - tf - 2) / n);
        const v = Math.max(18, Math.min(40, rh)) + 'px';
        LAST_FIT['--rowH'] = v;
        if (el.style.getPropertyValue('--rowH') !== v) el.style.setProperty('--rowH', v);
        const sp = el.parentElement;
        if (sp) {
          if (sp.style.getPropertyValue('--rowH') !== v) sp.style.setProperty('--rowH', v);
          window.requestAnimationFrame(() => sp.classList.add('ready'));
        }
      }
    };
    /* 23 Nov 2026: no flicker. While the rows settle to their fitted height the page
       scroll bar is held off, so it does not flash in and out when a card is clicked. */
    const root = document.documentElement;
    const prevOv = root.style.overflowY;
    root.style.overflowY = 'hidden';
    fit();
    const t1 = window.setTimeout(fit, 150);
    const t2 = window.setTimeout(() => {
      fit();
      const sp = tblRef.current && tblRef.current.parentElement;
      if (sp) sp.classList.add('ready');
      window.requestAnimationFrame(() => { root.style.overflowY = prevOv; });
    }, 600);
    window.addEventListener('resize', fit);
    return () => { window.removeEventListener('resize', fit); window.clearTimeout(t1); window.clearTimeout(t2); root.style.overflowY = prevOv; };
  }, [range, sel.length, items.length]);

  return (
    <section className="panel dv">
      <style>{CSS}</style>
      <h3 className="ptitle">{home && <><button type="button" className="crumb" onClick={home}>Bank-wide Overview</button><span className="crumbSep" aria-hidden="true">&#8250;</span></>}{p.title}</h3>
      {p.sub && <p className="dvSub">{p.sub}</p>}
      <div className="dvTop">
        <div className="dvBox">
          <h4>Filtered results</h4>
          <div className="dvCards">
            {p.cards.map(c => {
              const v = c.value(depts, latest);
              return (
                <div className="dvCard" key={c.label}><InfoIcon text={c.info} />
                  <div className="l">{c.label}</div><div className={'v' + (v === null ? ' muted' : '')}>{v === null ? NO_SOURCE : v}</div></div>
              );
            })}
          </div>
        </div>
        <div className="dvBox fil">
          <h4>Filters</h4>
          <div className="dvF">
            <span className="ttl">Filters</span>
            <span className="ctlL">Date Range</span>
            <Segmented label="Date range" value={range} onChange={setRange} options={RANGES} />
            <span className="ctlL">Department</span>
            <div className="dvDept"><TreePicker depts={p.depts} leaves={d => leafRows(d).map(s => ({ key: leafKey(s), label: s.code, group: s.group }))} pick={pick} onChange={setPick} /></div>
            {tree && (
              <span className="dvTree">
                <button type="button" className="tBtn" onClick={() => { const o: { [k: string]: boolean } = {}; rows.forEach(d => { o[d.code] = true; sitesOf(d).forEach(s => { if (s.group !== d.code) o[d.code + '/' + s.group] = true; }); }); setOpen(o); }}>Expand all</button>
                <button type="button" className="tBtn" onClick={() => setOpen({})}>Collapse all</button>
              </span>
            )}
            <span className="dvXp">
              <ExportButton table={() => ({
                name: p.title,
                head: ['Sites'].concat(...p.cols.map(c => months.map(m => c.label + (months.length > 1 ? ' ' + monthName(m) : '')))),
                rows: rows.map(d => ([d.code + ' - ' + d.name] as (string | number)[]).concat(...p.cols.map(c => months.map(m => c.cell(d, m) || '')))),
                total: ([totalLabel] as (string | number)[]).concat(...p.cols.map(c => months.map(m => c.total(depts, m) || '')))
              })} />
            </span>
          </div>
        </div>
      </div>
      <div className="dvSplit solo" style={{ ...(LAST_FIT as React.CSSProperties) }}>
      <div className="dvTblWrap" ref={tblRef} style={{ maxHeight: tblH ? tblH + 'px' : undefined, ...(LAST_FIT['--rowH'] ? { ['--rowH' as string]: LAST_FIT['--rowH'] } : {}) } as React.CSSProperties}>
        <table className="dvTbl">
          <thead>
            <tr>
              <th className="site" rowSpan={months.length > 1 ? 2 : 1}>Sites</th>
              {p.cols.map(c => <th key={c.label} colSpan={months.length}>{c.label}</th>)}
            </tr>
            {months.length > 1 && <tr className="sub">{p.cols.map((c, g) => months.map(m => <th key={g + '-' + m}>{monthName(m)}</th>))}</tr>}
          </thead>
          <tbody>
            {rows.length ? items.map(it => (
              <tr key={it.key} className={'lv' + it.depth + (it.kids ? ' kids' : '')}>
                <td className="site"><span className="tw" style={{ paddingLeft: it.depth * 20 }}>
                  {it.kids ? <button type="button" className="chev" aria-expanded={!!open[it.key]} aria-label={(open[it.key] ? 'Collapse ' : 'Expand ') + it.d.code} onClick={() => toggle(it.key)}><i className={'tri' + (open[it.key] ? ' on' : '')} /></button> : (tree ? <span className="chev" /> : null)}
                  {it.depth === 0 ? <button type="button" className="nm" onClick={() => p.openDept(it.d.code)} title="Open the Department overview">{it.d.code}</button> : <span className="nm">{it.d.code}</span>}
                </span><small>{it.d.name}</small></td>
                {p.cols.map((c, g) => months.map(m => { const v = c.cell(it.d, m); return <td key={g + '-' + m} title={v === null ? NO_SOURCE : undefined}>{v}</td>; }))}
              </tr>
            )) : <tr><td className="site" colSpan={1 + months.length * p.cols.length}>No department matches the search or filter.</td></tr>}
          </tbody>
          {rows.length > 0 && (
            <tfoot><tr>
              <td className="site" style={{ textAlign: 'left' }}>{totalLabel}</td>
              {p.cols.map((c, g) => months.map(m => <td key={g + '-' + m}>{c.total(depts, m)}</td>))}
            </tr></tfoot>
          )}
        </table>
      </div>
      </div>
      {range === 'prev' && <p className="dvNote">Filter: <b>Previous Month</b></p>}
      {p.after}
    </section>
  );
};

type ViewProps = { depts: IDept[]; openDept: (c: string) => void };

/* Slide 10 and 11: Total Documents in EDRMS. */
export const DocumentsView: React.FC<ViewProps> = ({ depts, openDept }) => {
  const gb = (d: IDept, i: number): number => d.gb * factor(d, i);
  return (
    <Breakdown bySite title="Documents in EDRMS" sub="Files stored in EDRMS sites, the space they use and the file formats found, by department. Choose one department to see its sites." depts={depts} openDept={openDept} sortBy={(d, i) => at(d.docs, d, i)}
      cards={[
        { label: 'Documents', value: (l, i) => F(sum(l, d => at(d.docs, d, i))), info: 'Files stored in EDRMS sites for the departments shown.' },
        { label: 'Storage (GB)', value: (l, i) => (isMissing('gb') ? null : F(Math.round(sum(l, d => gb(d, i))))), info: 'The space EDRMS sites use in SharePoint, in gigabytes. Not in RAC\'s file yet.' },
        { label: 'File Formats Identified', value: l => (isMissing('formats') ? null : F(formatsIn(l.map(d => (isSiteRow(d) ? d.parent.code : d.code))))), info: 'The number of distinct file formats (docx, pdf, xlsx ...) found in the departments shown. Sample figure.' }
      ]}
      cols={[
        { label: 'Documents', cell: (d, i) => F(at(d.docs, d, i)), total: (l, i) => F(sum(l, d => at(d.docs, d, i))) },
        { label: 'Storage (GB)', cell: (d, i) => (isMissing('gb') ? null : gb(d, i).toFixed(1)), total: (l, i) => (isMissing('gb') ? null : F(Math.round(sum(l, d => gb(d, i))))) },
        { label: 'File Formats Identified', cell: d => (isMissing('formats') || isSiteRow(d) ? null : F(formatsOf(d.code).length)), total: l => (isMissing('formats') ? null : F(formatsIn(l.map(d => (isSiteRow(d) ? d.parent.code : d.code))))) }
      ]} />
  );
};

/* Slide 12: Declared records in EDRMS (unique users removed). */
export const RecordsView: React.FC<ViewProps> = ({ depts, openDept }) => {
  const R = (l: IDept[], i: number): number => sum(l, d => at(d.rec, d, i));
  const D = (l: IDept[], i: number): number => sum(l, d => at(d.docs, d, i));
  return (
    <Breakdown bySite title="Records Declared in EDRMS" sub="Documents declared as official records, and their share of all documents stored, by department. Choose one department to see its sites." depts={depts} openDept={openDept} sortBy={(d, i) => at(d.rec, d, i)}
      cards={[
        { label: 'Declaration Rate', value: (l, i) => pctTxt(R(l, i), D(l, i), 2), info: 'Records declared as a share of all documents stored in EDRMS.' },
        { label: 'Records Declared', value: (l, i) => F(R(l, i)), info: 'Documents declared as official records in EDRMS.' },
        { label: 'Documents', value: (l, i) => F(D(l, i)), info: 'Files stored in EDRMS sites for the departments shown.' }
      ]}
      cols={[
        { label: 'Documents', cell: (d, i) => F(at(d.docs, d, i)), total: (l, i) => F(D(l, i)) },
        { label: 'Records Declared', cell: (d, i) => F(at(d.rec, d, i)), total: (l, i) => F(R(l, i)) },
        { label: 'Declaration Rate', cell: (d, i) => pctTxt(at(d.rec, d, i), at(d.docs, d, i), 2), total: (l, i) => pctTxt(R(l, i), D(l, i), 2) }
      ]} />
  );
};

/* Slide 13: Physical records identified in EDRMS. */
export const PhysicalView: React.FC<ViewProps> = ({ depts, openDept }) => {
  const P = (l: IDept[], i: number): number => sum(l, d => at(d.phys, d, i));
  const R = (l: IDept[], i: number): number => sum(l, d => at(d.rec, d, i));
  return (
    <Breakdown bySite title="Physical Records Identified in EDRMS" sub="Declared records that also exist on paper, and their share of all declared records, by department. Choose one department to see its sites." depts={depts} openDept={openDept} sortBy={(d, i) => at(d.phys, d, i)}
      cards={[
        { label: 'Share of Physical Records', value: (l, i) => pctTxt(P(l, i), R(l, i)), info: 'Physical records as a share of all records declared in EDRMS.' },
        { label: 'Physical Records', value: (l, i) => F(P(l, i)), info: 'Declared records that also exist on paper.' },
        { label: 'Records Declared', value: (l, i) => F(R(l, i)), info: 'Documents declared as official records in EDRMS.' }
      ]}
      cols={[
        { label: 'Records Declared', cell: (d, i) => F(at(d.rec, d, i)), total: (l, i) => F(R(l, i)) },
        { label: 'Physical Records', cell: (d, i) => F(at(d.phys, d, i)), total: (l, i) => F(P(l, i)) },
        { label: 'Share of Physical Records', cell: (d, i) => pctTxt(at(d.phys, d, i), at(d.rec, d, i)), total: (l, i) => pctTxt(P(l, i), R(l, i)) }
      ]} />
  );
};

/* Slide 9: ADB users in EDRMS. Headcount and training are not monthly in the sample data. */
export const UsersView: React.FC<ViewProps> = ({ depts, openDept }) => {
  /* Office rows (the tree) carry their shared-out headcount and training directly. */
  const hd = (d: IDept): number => (isSiteRow(d) ? d.head : approxHead(d));
  const tr = (d: IDept): number => (isSiteRow(d) ? d.trained || 0 : trainingDone(d));
  const H = (l: IDept[]): number => sum(l, approxHead);
  const A = (l: IDept[], i: number): number => sum(l, d => at(d.users, d, i));
  const T = (l: IDept[]): number => sum(l, trainingDone);
  return (
    <Breakdown byOffice title="ADB Users" depts={depts} openDept={openDept} sortBy={d => hd(d)}
      sub="Number of ADB staff, consultants and contractors (approximate, based on the headcount derived by BPMSD)."
      cards={[
        { label: 'Approximate ADB Headcount', value: l => (isMissing('head') ? null : F(H(l))), info: 'Approximate headcount derived by BPMSD. Comes from Import data (People tab).' },
        { label: 'Active Users', value: (l, i) => (isMissing('users') ? null : F(A(l, i))), info: 'People who opened or edited a file in an EDRMS site in the last 180 days. No source connected yet.' },
        { label: 'Inactive Users', value: (l, i) => (isMissing('users') || isMissing('head') ? null : F(Math.max(0, H(l) - A(l, i)))), info: 'Approximate headcount minus active users.' },
        { label: 'Completed EDRMS training', value: l => (isMissing('training') ? null : F(T(l))), info: 'People who completed the EDRMS training course. Comes from Import data (People tab).' },
        { label: 'Training Completion Rate', value: l => (isMissing('training') ? null : pctTxt(T(l), H(l))), info: 'Completed training as a share of the approximate headcount.' }
      ]}
      cols={[
        { label: 'Approximate Headcount', cell: d => (isMissing('head') ? null : F(hd(d))), total: l => (isMissing('head') ? null : F(H(l))) },
        { label: 'Active Users', cell: (d, i) => (isMissing('users') ? null : F(at(d.users, d, i))), total: (l, i) => (isMissing('users') ? null : F(A(l, i))) },
        { label: 'Inactive Users', cell: (d, i) => (isMissing('users') || isMissing('head') ? null : F(Math.max(0, hd(d) - at(d.users, d, i)))), total: (l, i) => (isMissing('users') || isMissing('head') ? null : F(Math.max(0, H(l) - A(l, i)))) },
        { label: 'Completed Training', cell: d => (isMissing('training') ? null : F(tr(d))), total: l => (isMissing('training') ? null : F(T(l))) },
        { label: 'Training Completion Rate', cell: d => (isMissing('training') ? null : pctTxt(tr(d), hd(d))), total: l => (isMissing('training') ? null : pctTxt(T(l), H(l))) }
      ]} />
  );
};

/* Slide 8: EDRMS Sites. Deleted and Archived are left out until needed. */
export const SitesView: React.FC<ViewProps & { idleShare: number; after?: React.ReactNode }> = ({ depts, openDept, idleShare, after }) => {
  SITE_IDLE = idleShare;
  const S = (l: IDept[], i: number): number => sum(l, d => at(d.sites, d, i));
  const inact1 = (n: number): number => Math.round(n * idleShare);
  /* A department row estimates its inactive sites; a site row is inactive (1) or not (0). */
  const inD = (d: IDept, i: number): number => (isSiteRow(d) ? (at(d.sites, d, i) ? d.idle180 : 0) : inact1(at(d.sites, d, i)));
  // Totals are the sum of the rows, so the table always adds up.
  const IN = (l: IDept[], i: number): number => sum(l, d => inD(d, i));
  return (
    <Breakdown bySite title="EDRMS Sites" sub="EDRMS sites registered for each department, and whether they are active or inactive. Choose one department to see its sites." depts={depts} openDept={openDept} sortBy={(d, i) => at(d.sites, d, i)} after={after}
      cards={[
        { label: 'Total Sites', value: (l, i) => F(S(l, i)), info: 'EDRMS sites registered in Cloud Governance.' },
        /* Site activity is not in RAC's file; Active / Inactive wait for it and for RAC's definition. */
        { label: 'Active Sites', value: (l, i) => (isMissing('activity') ? null : F(S(l, i) - IN(l, i))), info: 'Sites with recent activity. Not in RAC\'s file yet, and the definition of "active" is to be confirmed with RAC.' },
        { label: 'Inactive Sites', value: (l, i) => (isMissing('activity') ? null : F(IN(l, i))), info: 'Sites with no recent activity. Not in RAC\'s file yet, and the definition is to be confirmed with RAC.' }
      ]}
      cols={[
        { label: 'EDRMS Sites', cell: (d, i) => F(at(d.sites, d, i)), total: (l, i) => F(S(l, i)) },
        { label: 'Active Sites', cell: (d, i) => (isMissing('activity') ? null : F(at(d.sites, d, i) - inD(d, i))), total: (l, i) => (isMissing('activity') ? null : F(S(l, i) - IN(l, i))) },
        { label: 'Inactive Sites', cell: (d, i) => (isMissing('activity') ? null : F(inD(d, i))), total: (l, i) => (isMissing('activity') ? null : F(IN(l, i))) }
      ]} />
  );
};
