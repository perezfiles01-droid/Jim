import * as React from 'react';
import styles from './Report.module.scss';
import { loadReportData } from '../lib/data';
import { exportPdf, exportPptx } from '../lib/exporters';
import { refreshLabel } from '../lib/format';
import { BankWide } from '../dashboards/BankWide';
import { DepartmentInsights } from '../dashboards/DepartmentInsights';
import { DownloadGlyph } from './ui';

export type Dashboard = 'bw' | 'dp';
export type TextSize = 'standard' | 'large' | 'xlarge';

export interface IReportAppProps {
  dashboard: Dashboard;
  showSidebar: boolean;
  textSize: TextSize;
}

/* Text size: Large is the default, as readers are often older. */
const ZOOM: { [k in TextSize]: number } = { standard: 1, large: 1.25, xlarge: 1.5 };
const SIDEBAR_KEY = 'edrms-sidebar-closed';

const ICONS: { [k: string]: JSX.Element } = {
  bw: <svg viewBox="0 0 16 16"><circle cx="8" cy="8" r="6" /><circle cx="8" cy="8" r="2.5" fill="currentColor" /></svg>,
  dp: <svg viewBox="0 0 16 16"><rect x="2" y="2" width="5" height="5" /><rect x="9" y="2" width="5" height="5" /><rect x="2" y="9" width="5" height="5" /><rect x="9" y="9" width="5" height="5" /></svg>,
  pj: <svg viewBox="0 0 16 16"><path d="M8 2l6 6-6 6-6-6z" /></svg>,
  fp: <svg viewBox="0 0 16 16"><path d="M3 4h10M3 8h10M3 12h10" /></svg>,
  rd: <svg viewBox="0 0 16 16"><circle cx="8" cy="8" r="6" /><path d="M8 5v3l2 1" /></svg>,
  ra: <svg viewBox="0 0 16 16"><rect x="2" y="3" width="12" height="4" /><path d="M3 7v6h10V7M6 10h4" /></svg>
};

const FUTURE: { key: string; text: string }[] = [
  { key: 'pj', text: 'Project Insights' },
  { key: 'fp', text: 'Institutional File Plan' },
  { key: 'rd', text: 'Retention & Disposal' },
  { key: 'ra', text: 'Records & Archive Holdings' }
];

function readClosed(): boolean {
  try { return localStorage.getItem(SIDEBAR_KEY) === '1'; } catch { return false; }
}

export const ReportApp: React.FC<IReportAppProps> = props => {
  const data = React.useMemo(loadReportData, []);
  const [dash, setDash] = React.useState<Dashboard>(props.dashboard);
  const [focus, setFocus] = React.useState<string | undefined>(undefined);
  const [closed, setClosed] = React.useState<boolean>(readClosed);
  const [busy, setBusy] = React.useState(false);
  const page = React.useRef<HTMLDivElement>(null);
  const root = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => setDash(props.dashboard), [props.dashboard]);

  const go = (d: Dashboard): void => {
    setDash(d);
    if (d === 'bw') setFocus(undefined);
    if (root.current) root.current.scrollIntoView({ block: 'start' });
  };
  const openDept = (code: string): void => { setFocus(code); go('dp'); };
  const toggle = (): void => {
    const next = !closed;
    setClosed(next);
    try { localStorage.setItem(SIDEBAR_KEY, next ? '1' : '0'); } catch { /* private window */ }
  };
  const [menu, setMenu] = React.useState(false);
  const [busyText, setBusyText] = React.useState('');
  React.useEffect(() => {
    if (!menu) return;
    const close = (): void => setMenu(false);
    const key = (e: KeyboardEvent): void => { if (e.key === 'Escape') setMenu(false); };
    document.addEventListener('click', close);
    document.addEventListener('keydown', key);
    return () => { document.removeEventListener('click', close); document.removeEventListener('keydown', key); };
  }, [menu]);
  const name = dash === 'bw' ? 'Bank-wide Oversight' : 'Department Insights';
  // The capture libraries do not understand CSS zoom, so the page is drawn at
  // standard size and the text size is put back afterwards.
  const run = (text: string, job: () => Promise<void>): void => {
    if (!page.current || busy) return;
    setMenu(false); setBusy(true); setBusyText(text);
    const r = root.current, zoom = r ? r.style.getPropertyValue('zoom') : '';
    if (r) r.style.setProperty('zoom', '1');
    const done = (): void => { if (r) r.style.setProperty('zoom', zoom); setBusy(false); };
    job().then(done, e => { console.error('[EDRMS export]', e); done(); });
  };
  const pdf = (): void => run('Preparing PDF', () => exportPdf(page.current as HTMLElement, name));
  /* RAC Item 8 (22 Oct 2026): PowerPoint, one slide per breakdown and section. */
  const pptx = (): void => run('Preparing PowerPoint', () => {
    const el = page.current as HTMLElement;
    const pick = (q: string): string => ((el.querySelector(q) || {}).textContent || '').trim();
    return exportPptx(el, {
      name, desc: pick('.band .bd'), asOf: refreshLabel(),
      // Each box of the category bar as on screen: "Category: RM, HQ  ·  Sub-category: ...".
      filter: dash === 'bw' ? 'All Departments / Offices / RMs / ROs'
        : Array.from(el.querySelectorAll('.dash-dp > .panel:first-of-type .cgG')).map(g =>
          ((g.querySelector('.cgL') || {}).textContent || '') + ': ' + ((g.querySelector('.ms-Dropdown-title') || {}).textContent || '').trim()).join('  \u00b7  ')
    });
  });

  const bandTools = (
    <>
      <span className="asof"><i />Data as of<b>{refreshLabel()}</b></span>
      <span className="xMenuWrap" data-html2canvas-ignore="true">
        <button type="button" className="pdfBtn" disabled={busy} aria-haspopup="menu" aria-expanded={menu}
          onClick={e => { e.stopPropagation(); setMenu(!menu); }}>
          <DownloadGlyph />{busy ? busyText : 'Export'}{!busy && <span className="xCaret" aria-hidden="true">&#9662;</span>}
        </button>
        {menu && (
          <div className="xMenu" role="menu" onClick={e => e.stopPropagation()}>
            <button type="button" role="menuitem" onClick={pdf}><span className="xIc pdf">PDF</span><span><b>PDF</b><small>The dashboard as on screen</small></span></button>
            <button type="button" role="menuitem" onClick={pptx}><span className="xIc ppt">PPT</span><span><b>PowerPoint</b><small>One slide per breakdown and section, editable title and key points</small></span></button>
          </div>
        )}
      </span>
    </>
  );

  return (
    <div ref={root} className={styles.report} style={{ zoom: ZOOM[props.textSize] || 1.25 } as React.CSSProperties}>
      {props.showSidebar && (
        <nav className={'side' + (closed ? ' closed' : '')} aria-label="Dashboards">
          <div className="brand">
            <button type="button" className="menuBtn" onClick={toggle} aria-expanded={!closed}
              title={closed ? 'Open navigation' : 'Close navigation'} aria-label={closed ? 'Open navigation' : 'Close navigation'}>
              <svg viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16" /></svg>
            </button>
            <div className="t1">EDRMS Utilization Report</div>
            <div className="t2">Asian Development Bank</div>
          </div>
          <div className="grp">Key views</div>
          <button type="button" className={'nav' + (dash === 'bw' ? ' on' : '')} aria-current={dash === 'bw' ? 'page' : undefined} title="Bank-wide Oversight" onClick={() => go('bw')}>
            {ICONS.bw}<span className="navTx">Bank-wide Oversight</span>
          </button>
          <button type="button" className={'nav' + (dash === 'dp' ? ' on' : '')} aria-current={dash === 'dp' ? 'page' : undefined} title="Department Insights" onClick={() => go('dp')}>
            {ICONS.dp}<span className="navTx">Department Insights</span>
          </button>
          <div className="grp">For future release</div>
          {FUTURE.map(f => (
            <button type="button" key={f.key} className="nav future" aria-disabled="true" title={f.text + ' (future release)'}>
              {ICONS[f.key]}<span className="navTx">{f.text}</span>
            </button>
          ))}
        </nav>
      )}
      <div className="main" ref={page}>
        {dash === 'bw'
          ? <BankWide data={data} openDept={openDept} bandTools={bandTools} />
          : <DepartmentInsights data={data} openDept={openDept} bandTools={bandTools} focus={focus} />}
      </div>
    </div>
  );
};

