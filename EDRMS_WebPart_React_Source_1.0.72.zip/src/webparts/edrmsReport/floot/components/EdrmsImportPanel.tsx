/*
 * Import data (5 Nov 2026), shown only to SharePoint Owners and site collection admins.
 *
 * 24 Nov 2026: the import is SEGMENTED. Each kind of manual data is its own
 * section with its own template, check and last-import line, so one section
 * never blocks or overwrites another. For now there is one section on
 * Bank-wide Oversight: People and training, which gives the approximate
 * headcount and the training completion per department. Sites, records,
 * physical counterparts, storage, activity and file formats come from the
 * scan job and system sources, not from a manual upload.
 * Web part 1.0.59: as the Floot app, without its sign-in step; SharePoint already
 * knows who is signed in, and the button is shown to Owners and admins only.
 */
import * as React from 'react';
import { validatePeople, IValidation, TABS, COLUMNS, IManualData, Sheet } from '../helpers/edrmsImportRules';
import { IManualStore, IHistoryEntry } from '../helpers/edrmsManualStore';

export interface IImportPanelProps {
  store: IManualStore;
  user: string;
  role: string;
  current: IManualData | null;
  knownUnits: string[];
  onClose: () => void;
  onLoaded: (d: IManualData) => void;
}

const MAX_BYTES = 10 * 1024 * 1024;
const TEMPLATE_NAME = 'EDRMS_People_and_Training.xlsx';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function xlsx(): Promise<any> { return import('xlsx-js-style'); }

async function downloadTemplate(knownUnits: string[]): Promise<void> {
  const X = await xlsx();
  const wb = X.utils.book_new();
  const headStyle = { font: { bold: true, color: { rgb: 'FFFFFF' } }, fill: { fgColor: { rgb: '194F8E' } }, alignment: { vertical: 'center', wrapText: true } };
  const sheet = (rows: (string | number)[][], widths: number[]): unknown => {
    const ws = X.utils.aoa_to_sheet(rows);
    ws['!cols'] = widths.map(w => ({ wch: w }));
    if (rows.length) rows[0].forEach((_, c) => { const a = X.utils.encode_cell({ r: 0, c }); if (ws[a]) ws[a].s = headStyle; });
    return ws;
  };
  X.utils.book_append_sheet(wb, sheet([COLUMNS.people.map(c => c.name)], [34, 26, 13, 11, 10, 16, 13, 24]), TABS.people);
  X.utils.book_append_sheet(wb, sheet([COLUMNS.mapping.map(c => c.name)], [18, 16]), TABS.mapping);
  X.utils.book_append_sheet(wb, sheet([['Departments on the report'], ...knownUnits.slice().sort().map(u => [u]), [], ['Staff type'], ['Staff'], ['Consultant'], ['Contractor'], [], ['Completed EDRMS training'], ['Yes'], ['No']], [28]), 'Valid values');
  X.writeFile(wb, TEMPLATE_NAME);
}

async function readBook(file: File): Promise<{ book: { [t: string]: Sheet } | null; problem: string | null }> {
  if (!/\.xlsx$/i.test(file.name)) return { book: null, problem: 'Only .xlsx files are accepted. Use the downloaded template.' };
  if (file.size > MAX_BYTES) return { book: null, problem: 'The file is larger than 10 MB.' };
  try {
    const X = await xlsx();
    const wb = X.read(await file.arrayBuffer(), { type: 'array', cellDates: true });
    const book: { [t: string]: Sheet } = {};
    (wb.SheetNames as string[]).forEach(n => { book[n] = X.utils.sheet_to_json(wb.Sheets[n], { header: 1, raw: true, defval: null, blankrows: true }); });
    return { book, problem: null };
  } catch {
    return { book: null, problem: 'The file could not be read. Open it in Excel and save it again as .xlsx.' };
  }
}

const F = (n: number): string => n.toLocaleString('en-US');

export const ImportPanel: React.FC<IImportPanelProps> = props => {
  const [file, setFile] = React.useState<File | null>(null);
  const [result, setResult] = React.useState<IValidation | null>(null);
  const [problem, setProblem] = React.useState<string | null>(null);
  const [busy, setBusy] = React.useState('');
  const [done, setDone] = React.useState<string | null>(null);
  const [hist, setHist] = React.useState<IHistoryEntry[] | null>(null);
  const [drag, setDrag] = React.useState(false);
  const input = React.useRef<HTMLInputElement>(null);
  const shade = React.useRef<HTMLDivElement>(null);

  // Start below SharePoint's own top bar, which sits above the page and would
  // otherwise cover the panel's title and close button. The report is drawn
  // with CSS zoom (text size), so the offset is given in zoomed pixels.
  React.useLayoutEffect(() => {
    const place = (): void => {
      const el = shade.current;
      if (!el) return;
      const bars = Array.prototype.slice.call(document.querySelectorAll('#SuiteNavWrapper, #SuiteNavPlaceHolder, #O365_NavHeader, [data-automationid="SuiteNav"], #spSiteHeader ~ div[role="banner"]')) as HTMLElement[];
      const bottom = bars.reduce((a, b) => { const r = b.getBoundingClientRect(); return r.height > 0 && r.top < 5 ? Math.max(a, r.bottom) : a; }, 0);
      const zoom = parseFloat(getComputedStyle(el.parentElement || el).getPropertyValue('zoom')) || 1;
      el.style.top = Math.max(0, bottom) / zoom + 'px';
    };
    place();
    window.addEventListener('resize', place);
    return () => window.removeEventListener('resize', place);
  }, []);

  React.useEffect(() => { props.store.history().then(setHist, () => setHist([])); }, []);
  React.useEffect(() => {
    const k = (e: KeyboardEvent): void => { if (e.key === 'Escape' && !busy) props.onClose(); };
    document.addEventListener('keydown', k);
    return () => document.removeEventListener('keydown', k);
  }, [busy]);

  const reset = (): void => { setFile(null); setResult(null); setProblem(null); setDone(null); if (input.current) input.current.value = ''; };

  const check = async (f: File | null): Promise<void> => {
    reset();
    if (!f) return;
    setFile(f); setBusy('Checking ' + f.name);
    const { book, problem: p } = await readBook(f);
    if (!book) { setProblem(p); setBusy(''); return; }
    // Let the "Checking" line paint before a large file is processed.
    await new Promise(resolve => setTimeout(resolve, 30));
    const v = validatePeople(book, f.name, props.user, props.current, props.knownUnits);
    setResult(v); setBusy('');
    if (v.issues.length) {
      await props.store.logRefused(f.name, props.user, v.issues);
      props.store.history().then(setHist, () => undefined);
    }
  };

  const load = async (): Promise<void> => {
    if (!result || !result.data) return;
    setBusy('Saving');
    try {
      await props.store.save(result.data);
      props.onLoaded(result.data);
      setDone('Loaded. Headcount and training completion now show the imported figures.');
      setResult(null);
      setHist(await props.store.history());
    } catch (e) {
      setProblem('Nothing was saved: ' + (e instanceof Error ? e.message : 'the server did not accept the file.') + ' Check that you are still an Owner of this site and try again.');
    }
    setBusy('');
  };

  const last = hist && hist.filter(h => h.status === 'loaded')[0];
  const issues = result ? result.issues : [];

  return (
    <div ref={shade} className="impShade" onClick={() => { if (!busy) props.onClose(); }} data-html2canvas-ignore="true">
      <aside className="impPanel" role="dialog" aria-modal="true" aria-label="Import manual data" onClick={e => e.stopPropagation()}>
        <div className="impHead">
          <div><h2>Import manual data</h2><div className="impWho">Signed in as {props.user} &middot; {props.role}</div></div>
          <button type="button" className="impX" aria-label="Close" title="Close" disabled={!!busy} onClick={props.onClose}>&#10005;</button>
        </div>

        <section className="impStep impSection" data-section="people" style={{ border: '1px solid #D3DEEA', borderRadius: 6, padding: '12px 14px' }}>
          <h3 style={{ marginTop: 0 }}>People and training</h3>
          <p className="impSmall" style={{ marginTop: 0 }}>Gives the approximate headcount and the training completion for each department. One row per person; only the counts per department are kept, never names or emails.</p>

          <h4 style={{ margin: '12px 0 6px' }}>1. Download the template</h4>
          <button type="button" className="impBtn pri" onClick={() => { downloadTemplate(props.knownUnits).catch(e => setProblem('The template could not be created: ' + e)); }}>Download People and training template</button>

          <h4 style={{ margin: '14px 0 6px' }}>2. Upload and check</h4>
          <label className={'impDrop' + (drag ? ' on' : '')}
            onDragOver={e => { e.preventDefault(); setDrag(true); }} onDragLeave={() => setDrag(false)}
            onDrop={e => { e.preventDefault(); setDrag(false); check(e.dataTransfer.files[0] || null).catch(() => undefined); }}>
            <input ref={input} type="file" accept=".xlsx" onChange={e => { check(e.target.files ? e.target.files[0] : null).catch(() => undefined); }} />
            {file ? <b>{file.name}</b> : <span>Drop the filled template here, or <u>browse</u> (.xlsx, up to 10 MB)</span>}
          </label>
          {busy && <p className="impBusy">{busy}&hellip;</p>}
          {problem && <div className="impBad"><b>{problem}</b></div>}
          {result && issues.length > 0 && (
            <div className="impBad">
              <b>Not loaded. {F(issues.length)}{issues.length >= 1000 ? '+' : ''} problem{issues.length === 1 ? '' : 's'} found. Nothing was changed.</b>
              <div className="impTblWrap"><table className="impTbl"><thead><tr><th>Tab</th><th>Row</th><th>Column</th><th>Problem</th></tr></thead>
                <tbody>{issues.slice(0, 300).map((i, n) => <tr key={n}><td>{i.tab}</td><td>{i.row || '-'}</td><td>{i.column}</td><td>{i.message}</td></tr>)}</tbody></table></div>
              {issues.length > 300 && <p className="impSmall">Showing the first 300. Fix these and check again.</p>}
            </div>
          )}
          {result && result.data && (
            <div className="impGood">
              <b>All checks passed.</b>
              <div>{F(result.summary.people)} people in {F(result.summary.units)} departments &middot; {F(result.summary.trained)} completed training</div>
              {result.notes.map((n, i) => <div key={i} className="impNote">{n}</div>)}
              <div className="impRow"><button type="button" className="impBtn pri" disabled={!!busy} onClick={() => { load().catch(() => undefined); }}>Import</button>
                <button type="button" className="impBtn" disabled={!!busy} onClick={reset}>Cancel</button></div>
            </div>
          )}
          {done && <div className="impGood"><b>{done}</b></div>}

          <p className="impSmall" style={{ marginBottom: 0 }}>
            {last ? <>Last import: {new Date(last.at).toLocaleString()} by {last.by} &middot; {F(last.people)} people</> : 'Nothing imported yet. Headcount and training show sample figures.'}
          </p>
        </section>

        {hist && hist.length > 0 && (
          <details className="impHist"><summary>Import history</summary>
            <table className="impTbl"><thead><tr><th>When</th><th>By</th><th>File</th><th>Result</th></tr></thead>
              <tbody>{hist.slice(0, 30).map((h, i) => <tr key={i}><td>{new Date(h.at).toLocaleString()}</td><td>{h.by}</td><td>{h.fileName}</td>
                <td className={h.status === 'loaded' ? 'ok' : 'no'}>{h.status === 'loaded' ? 'Loaded' : 'Refused, ' + F(h.problems) + ' problems'}</td></tr>)}</tbody></table>
          </details>
        )}
      </aside>
    </div>
  );
};
