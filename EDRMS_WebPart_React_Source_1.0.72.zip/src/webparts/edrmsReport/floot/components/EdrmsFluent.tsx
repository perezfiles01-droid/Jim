import * as React from 'react';
import { createPortal } from 'react-dom';

/*
 * The four Fluent UI 8 controls the SharePoint web part uses (Callout,
 * Checkbox, Dropdown, TooltipHost), rebuilt small so the Floot copy runs the
 * web part's own components unchanged. They render the same ms-* class names,
 * so the web part's stylesheet styles them the same way.
 * Web part 1.0.59 keeps these stand-ins too, so it looks exactly like the Floot app.
 */

export enum DirectionalHint { bottomLeftEdge = 1, bottomRightEdge = 2 }

let SEQ = 0;
/** Layers open now; Escape closes only the newest, as Fluent does. */
const OPEN: number[] = [];

interface ICalloutProps {
  target: React.RefObject<HTMLElement | null>;
  onDismiss?: () => void;
  directionalHint?: DirectionalHint;
  gapSpace?: number;
  setInitialFocus?: boolean;
  role?: string;
  ariaLabel?: string;
  isBeakVisible?: boolean;
  calloutWidth?: number;
  calloutMaxWidth?: number;
  preventDismissOnEvent?: (ev: Event) => boolean;
  className?: string;
  children?: React.ReactNode;
}

/** A popup layer placed under its target, closed by Escape or a click outside. */
export const Callout: React.FC<ICalloutProps> = p => {
  const ref = React.useRef<HTMLDivElement>(null);
  const seq = React.useMemo(() => ++SEQ, []);
  const [pos, setPos] = React.useState<{ top: number; left: number; minW: number } | null>(null);
  const place = React.useCallback(() => {
    const t = p.target.current, me = ref.current;
    if (!t) return;
    const r = t.getBoundingClientRect(), w = me ? me.offsetWidth : 0;
    const gap = p.gapSpace || 0;
    let left = p.directionalHint === DirectionalHint.bottomRightEdge ? r.right - w : r.left;
    left = Math.max(8, Math.min(left, window.innerWidth - w - 8));
    let top = r.bottom + gap;
    const h = me ? me.offsetHeight : 0;
    if (h && top + h > window.innerHeight - 8 && r.top - gap - h > 8) top = r.top - gap - h;
    setPos({ top, left, minW: p.calloutWidth || 0 });
  }, [p.target, p.directionalHint, p.gapSpace, p.calloutWidth]);
  React.useLayoutEffect(() => { place(); const id = requestAnimationFrame(place); return () => cancelAnimationFrame(id); }, [place]);
  React.useEffect(() => {
    const onScroll = (): void => place();
    const down = (e: Event): void => {
      const el = e.target as Element | null;
      if (!el || !ref.current) return;
      if (ref.current.contains(el)) return;
      if (p.target.current && p.target.current.contains(el)) return;
      const layer = el.closest ? el.closest('.ms-Layer') as HTMLElement | null : null;
      if (layer && Number(layer.getAttribute('data-seq')) > seq) return;
      if (p.preventDismissOnEvent && p.preventDismissOnEvent(e)) return;
      if (p.onDismiss) p.onDismiss();
    };
    const key = (e: KeyboardEvent): void => {
      if (e.key !== 'Escape' || !p.onDismiss || Math.max(...OPEN) !== seq) return;
      e.stopImmediatePropagation();
      p.onDismiss();
    };
    window.addEventListener('resize', onScroll);
    window.addEventListener('scroll', onScroll, true);
    document.addEventListener('mousedown', down, true);
    document.addEventListener('keydown', key);
    return () => {
      window.removeEventListener('resize', onScroll);
      window.removeEventListener('scroll', onScroll, true);
      document.removeEventListener('mousedown', down, true);
      document.removeEventListener('keydown', key);
    };
  }, [place, p.onDismiss, p.preventDismissOnEvent, seq, p.target]);
  React.useEffect(() => {
    OPEN.push(seq);
    return () => { const i = OPEN.indexOf(seq); if (i >= 0) OPEN.splice(i, 1); };
  }, [seq]);
  React.useEffect(() => {
    if (!p.setInitialFocus || !ref.current) return;
    const f = ref.current.querySelector('input,button,[tabindex]') as HTMLElement | null;
    if (f) f.focus();
  }, [p.setInitialFocus]);
  if (typeof document === 'undefined') return null;
  return createPortal(
    <div className={'ms-Layer edrms-layer' + (p.className ? ' ' + p.className : '')} data-seq={seq}>
      <div ref={ref} className="ms-Callout" role={p.role} aria-label={p.ariaLabel}
        style={{ position: 'fixed', zIndex: 1000000, top: pos ? pos.top : -9999, left: pos ? pos.left : -9999,
          minWidth: pos && pos.minW ? pos.minW : undefined, width: p.calloutWidth || undefined, maxWidth: p.calloutMaxWidth || undefined }}>
        <div className="ms-Callout-main">{p.children}</div>
      </div>
    </div>,
    document.body
  );
};

interface ICheckboxProps {
  className?: string;
  label?: string;
  checked?: boolean;
  indeterminate?: boolean;
  onChange?: (ev?: React.FormEvent<HTMLElement>, checked?: boolean) => void;
  onRenderLabel?: () => React.ReactNode;
}

export const Checkbox: React.FC<ICheckboxProps> = p => {
  const box = React.useRef<HTMLInputElement>(null);
  React.useEffect(() => { if (box.current) box.current.indeterminate = !!p.indeterminate; }, [p.indeterminate]);
  return (
    <div className={'ms-Checkbox' + (p.checked ? ' is-checked' : '') + (p.indeterminate ? ' is-indeterminate' : '') + (p.className ? ' ' + p.className : '')}>
      <label className="ms-Checkbox-label">
        <input ref={box} type="checkbox" className="ms-Checkbox-input" checked={!!p.checked}
          onChange={e => p.onChange && p.onChange(e, e.target.checked)} />
        <span className="ms-Checkbox-checkbox" aria-hidden="true" />
        {p.onRenderLabel ? p.onRenderLabel() : <span className="ms-Checkbox-text">{p.label}</span>}
      </label>
    </div>
  );
};

export interface IDropdownOption { key: string | number; text: string }

interface IDropdownProps {
  className?: string;
  style?: React.CSSProperties;
  selectedKey?: string | number;
  options: IDropdownOption[];
  onChange?: (ev: React.FormEvent<HTMLDivElement>, option?: IDropdownOption) => void;
  ariaLabel?: string;
  onRenderCaretDown?: () => React.ReactNode;
}

export const Dropdown: React.FC<IDropdownProps> = p => {
  const [open, setOpen] = React.useState(false);
  const box = React.useRef<HTMLDivElement>(null);
  const sel = p.options.filter(o => o.key === p.selectedKey)[0];
  const choose = (o: IDropdownOption, e: React.SyntheticEvent): void => {
    setOpen(false);
    if (p.onChange) p.onChange(e as unknown as React.FormEvent<HTMLDivElement>, o);
  };
  return (
    <div className={'ms-Dropdown-container' + (p.className ? ' ' + p.className : '')} style={p.style}>
      <div ref={box} className="ms-Dropdown" tabIndex={0} role="combobox" aria-label={p.ariaLabel} aria-expanded={open}
        onClick={() => setOpen(!open)}
        onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowDown') { e.preventDefault(); setOpen(true); } }}>
        <span className="ms-Dropdown-title">{sel ? sel.text : ''}</span>
        <span className="ms-Dropdown-caretDownWrapper">{p.onRenderCaretDown ? p.onRenderCaretDown() : '▾'}</span>
      </div>
      {open && (
        <Callout target={box} onDismiss={() => setOpen(false)} directionalHint={DirectionalHint.bottomLeftEdge}
          calloutWidth={box.current ? box.current.offsetWidth : undefined} role="listbox" ariaLabel={p.ariaLabel} setInitialFocus>
          <div className="ms-Dropdown-items">
            {p.options.map(o => (
              <button type="button" key={String(o.key)} role="option" aria-selected={o.key === p.selectedKey}
                className={'ms-Dropdown-item' + (o.key === p.selectedKey ? ' is-selected' : '')} onClick={e => choose(o, e)}>{o.text}</button>
            ))}
          </div>
        </Callout>
      )}
    </div>
  );
};

interface ITooltipHostProps {
  content: string;
  hostClassName?: string;
  directionalHint?: DirectionalHint;
  calloutProps?: { gapSpace?: number; calloutMaxWidth?: number };
  children?: React.ReactNode;
}

export const TooltipHost: React.FC<ITooltipHostProps> = p => {
  const [show, setShow] = React.useState(false);
  const host = React.useRef<HTMLSpanElement>(null);
  const cp = p.calloutProps || {};
  return (
    <span ref={host} className={p.hostClassName} onMouseEnter={() => setShow(true)} onMouseLeave={() => setShow(false)}
      onFocus={() => setShow(true)} onBlur={() => setShow(false)}>
      {p.children}
      {show && (
        <Callout target={host} directionalHint={p.directionalHint} gapSpace={cp.gapSpace} calloutMaxWidth={cp.calloutMaxWidth} className="ms-Tooltip">
          <div className="ms-Tooltip-content">{p.content}</div>
        </Callout>
      )}
    </span>
  );
};
