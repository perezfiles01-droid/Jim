/*
 * Web part 1.0.59: the only styles the Floot app added to the web part's own stylesheet
 * (Report.module.scss). They style the small stand-ins for the Fluent UI pop-ups, checkboxes
 * and drop-downs that the Floot screens use (components/EdrmsFluent), and the grouped sites
 * table. Copied word for word from the Floot app's stylesheet of 24 Nov 2026.
 */
export const FLOOT_EXTRA_CSS = `
.edrms-layer .ms-Callout { background: #fff; border-radius: 8px; box-shadow: 0 6px 24px rgba(14, 31, 53, .18), 0 1px 3px rgba(14, 31, 53, .12); font-family: "Segoe UI", system-ui, -apple-system, Arial, sans-serif; color: #10243E; font-size: 13px; }
.edrms-layer.ms-Tooltip .ms-Callout { background: #fff; padding: 8px 10px; font-size: 12px; line-height: 1.4; color: #33475F; }
.edrms-layer .ms-Callout-main { max-height: 80vh; overflow: auto; }
.ms-Checkbox .ms-Checkbox-label { display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 13px; color: #10243E; }
.ms-Checkbox .ms-Checkbox-input { width: 16px; height: 16px; margin: 0; accent-color: #0072BC; flex: 0 0 16px; cursor: pointer; }
.ms-Checkbox .ms-Checkbox-checkbox { display: none; }
.ms-Dropdown-container { position: relative; display: inline-block; }
.ms-Dropdown { position: relative; cursor: pointer; outline: none; }
.ms-Dropdown-title { display: block; height: 32px; line-height: 30px; padding: 0 32px 0 10px; border: 1px solid #CFD8E3; border-radius: 4px; background: #fff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; font-size: 13px; color: #10243E; }
.ms-Dropdown-caretDownWrapper { position: absolute; top: 0; right: 8px; height: 32px; display: flex; align-items: center; pointer-events: none; }
.edrms-layer .ms-Dropdown-items { padding: 4px 0; display: flex; flex-direction: column; }
.edrms-layer .ms-Dropdown-item { border: 0; background: #fff; text-align: left; padding: 8px 12px; font: inherit; font-size: 13px; color: #10243E; cursor: pointer; }
.edrms-layer .ms-Dropdown-item:hover { background: #F2F7FB; }
.edrms-layer .ms-Dropdown-item.is-selected { background: #E8F3FB; font-weight: 600; }
.edrms-report .infoWrap { display: inline-flex; }
.edrms-report .sgGroupBar { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin-top: 10px; }
.edrms-report .sgGroupBar .ctlL { font-size: 11px; letter-spacing: .06em; text-transform: uppercase; color: #6B7A8C; font-weight: 600; }
.edrms-report .sgSp { flex: 1 1 auto; }
.edrms-report .sgLink { border: 0; background: none; color: #0072BC; font: inherit; font-size: 13px; font-weight: 600; cursor: pointer; padding: 4px 6px; }
.edrms-report .sgLink:hover { text-decoration: underline; }
.edrms-report .sgTbl td, .edrms-report .sgTbl th { white-space: nowrap; }
.edrms-report .sgTbl .sgName { display: inline-flex; align-items: center; gap: 6px; }
.edrms-report .sgTbl .sgName a { color: #10243E; text-decoration: none; }
.edrms-report .sgTbl .sgName a:hover { color: #0072BC; text-decoration: underline; }
.edrms-report .sgTog { width: 22px; height: 22px; border: 0; border-radius: 4px; background: transparent; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; padding: 0; color: #33475F; }
.edrms-report .sgTog:hover { background: #E8F0F8; }
.edrms-report .sgTog svg { width: 12px; height: 12px; fill: none; stroke: currentColor; stroke-width: 1.8; stroke-linecap: round; stroke-linejoin: round; transition: transform .15s; }
.edrms-report .sgTog.on svg { transform: rotate(90deg); }
.edrms-report .sgDot { width: 22px; display: inline-flex; justify-content: center; }
.edrms-report .sgDot::before { content: ""; width: 5px; height: 5px; border-radius: 50%; background: #B9C6D4; }
.edrms-report .sgR.sgD0 td { background: #F3F7FB; font-weight: 600; }
.edrms-report .sgR.sgD1.sgG td { font-weight: 600; color: #33475F; }
.edrms-report .sgLoc { font-size: 10.5px; font-weight: 600; letter-spacing: .04em; color: #0F6E5E; background: #E3F5F1; border-radius: 4px; padding: 1px 6px; }
.edrms-report .sgLoc.fo { color: #8A4B00; background: #FDF0DD; }
.edrms-report .sgNote, .edrms-layer .sgNote { font-size: 11.5px; color: #6B7A8C; margin: 8px 0 0; }
.edrms-layer .sgPop { width: 340px; }
.edrms-layer .sgSec { padding: 6px 14px 4px; font-size: 11px; letter-spacing: .06em; text-transform: uppercase; color: #6B7A8C; font-weight: 600; }
.edrms-layer .sgLocs { display: flex; flex-wrap: wrap; gap: 6px 14px; padding: 2px 14px 10px; border-bottom: 1px solid #E3E9F0; }
.edrms-layer .sgTree .ugS { margin-left: 0; }
.edrms-layer .sgTree .ugI.d2 { margin-left: 24px; }
`;
