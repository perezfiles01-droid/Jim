/*
 * Web part 1.0.59: the Floot screens use the web part's own SharePoint store
 * (lib/manualStore.ts: the hidden "EDRMS Manual Data" library, Owners write,
 * everyone reads). Only its types are needed here; the web part creates the store.
 */
export type { IHistoryEntry, IManualStore } from '../../lib/manualStore';
