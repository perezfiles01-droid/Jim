// The report's data, and the few figures it derives from it.
//
// Everything on screen is read through IReportData. Today it is filled from
// data/sampleData.json, the same sample figures as the approved prototype, so
// the two can be compared number for number. To connect the real reporting
// database, replace loadReportData() with a call to the API and return the
// same shapes; no component needs to change.

import { IManualData, IUnitFigures } from './edrmsImportRules';
import { setCategoryRows } from './edrmsCategories';
import { SITE_DIRECTORY } from './edrmsSiteDirectory';
const SITE_DIR = () => SITE_DIRECTORY;

export interface IDept {
  code: string;
  name: string;
  sites: number;
  /** People active in EDRMS in the last 180 days. */
  users: number;
  /** Approximate headcount, provided by RAC. */
  head: number;
  docs: number;
  rec: number;
  phys: number;
  /** Distinct people who declared at least one record. */
  declaring: number;
  creating: number;
  idle180: number;
  visitors: number;
  views: number;
  gb: number;
  recgb: number;
}

export interface ISite {
  name: string;
  owner: string;
  docs: number;
  rec: number;
  phys: number;
  users: number;
  visitors: number;
  declaring: number;
  creating: number;
  /** Days since last activity. */
  idle: number;
  gb: number;
  ermsType: string;
}

export interface ILibrary {
  lib: string;
  site: string;
  docs: number;
  rec: number;
  phys: number;
}

export interface ITrend {
  /** First day of each month, yyyy-mm-dd. */
  keys: string[];
  values: number[];
  labels: string[];
  from: string;
  to: string;
}

export interface ITotals {
  documents: number;
  declared: number;
  withPhysical: number;
  sites: number;
  activeUsers: number;
  headcount: number;
  usersDeclaring: number;
  usersCreating: number;
  visitors: number;
  storageGb: number;
}

export interface IReportData {
  asOf: string;
  totals: ITotals;
  trend: ITrend;
  depts: IDept[];
  sites: { [code: string]: ISite[] };
  libsByDept: { [code: string]: ILibrary[] };
  libsAll: ILibrary[];
  allName: string;
}

/* Web part 1.0.59: the sample figures are the web part's own data/sampleData.json,
   bundled with it (the Floot copy fetches the same file from its file store). */
// eslint-disable-next-line @typescript-eslint/no-require-imports
const SAMPLE_JSON: IReportData = require('../../data/sampleData.json');
let SAMPLE: IReportData | null = null;

/** Loads the sample figures once; the report waits for it before drawing. */
export async function fetchReportData(): Promise<IReportData> {
  return loadReportData();
}

export function loadReportData(): IReportData {
  if (!SAMPLE) SAMPLE = fromClientFile(SAMPLE_JSON);
  return SAMPLE;
}

/* ---------- RAC's file as the basis (23 Nov 2026) ---------- */

/*
 * At the requester's instruction, 23 Nov 2026: the report uses ONLY the departments
 * and figures in RAC's Utilization_Report_Dropdown.xlsx (Metadata tab, helpers/
 * edrmsSiteDirectory): 15 departments, with # Sites, # Documents, # Records and
 * # Physical counterparts per site. The old sample units (ITD, HRD, OSFG ...) are gone.
 * Anything the file does not hold (headcount, active users, storage, training,
 * site activity) is NOT guessed: it is flagged missing and shown as "Not yet sourced"
 * until it is imported (Import data, People tab) or a source is connected.
 */
/* 23 Nov 2026, later: the requester asked for SAMPLE figures wherever RAC's file has none,
   so every view shows numbers. Sites, documents, records and physical stay RAC's own;
   headcount, active users, storage, training, site activity and file formats are SAMPLE,
   generated per department below. Flip a flag to true to show "Not yet sourced" again. */
export const MISSING: { [field: string]: boolean } = { head: false, users: false, gb: false, training: false, activity: false, formats: false };

/* Sample file formats: each department holds a subset of this list. */
const FORMATS = ['docx', 'xlsx', 'pdf', 'pptx', 'msg', 'eml', 'jpg', 'png', 'csv', 'txt', 'zip', 'doc', 'xls', 'ppt', 'mp4', 'vsdx', 'tif', 'html', 'xml', 'rtf', 'one', 'mpp', 'gif', 'json'];
const FMT_BY_DEPT: { [code: string]: string[] } = {};
export function formatsOf(code: string): string[] { return FMT_BY_DEPT[code] || []; }
export function formatsIn(codes: string[]): number {
  const s: { [f: string]: true } = {};
  codes.forEach(c => formatsOf(c).forEach(f => { s[f] = true; }));
  return Object.keys(s).length;
}
export const NOT_SOURCED = 'Not yet sourced';
export const isMissing = (field: string): boolean => !!MISSING[field];

export function fromClientFile(base: IReportData): IReportData {
  const dir = SITE_DIR();
  const byDept: { [code: string]: IDept } = {};
  const sites: { [code: string]: ISite[] } = {};
  dir.forEach(r => {
    const d = byDept[r.dept] || (byDept[r.dept] = {
      code: r.dept, name: '', sites: 0, users: 0, head: 0, docs: 0, rec: 0, phys: 0,
      declaring: 0, creating: 0, idle180: 0, visitors: 0, views: 0, gb: 0, recgb: 0
    });
    d.sites += r.sites; d.docs += r.docs; d.rec += r.rec; d.phys += r.phys;
    (sites[r.dept] = sites[r.dept] || []).push({
      name: r.site, owner: '', docs: r.docs, rec: r.rec, phys: r.phys, users: 0, visitors: 0,
      declaring: 0, creating: 0, idle: 0, gb: 0, ermsType: r.loc
    });
  });
  const depts = Object.keys(byDept).sort().map(k => byDept[k]);
  /* SAMPLE figures for what the file does not hold, stable per department. */
  depts.forEach(d => {
    const h = seed(d.code, 31, 9973) / 9973, g = seed(d.code + 'x', 37, 9973) / 9973;
    d.head = Math.round((d.sites * 35 + 120 + h * 400) / 10) * 10;
    d.users = Math.round(d.head * (0.62 + 0.3 * g));
    d.gb = Math.round((d.docs * 0.0018 + 1.5 + h * 6) * 10) / 10;
    d.declaring = Math.max(1, Math.round(d.users * 0.18));
    FMT_BY_DEPT[d.code] = FORMATS.slice(0, 8 + Math.round(g * 12));
  });
  /* RAC's file has 0 physical counterparts everywhere; SAMPLE 8 to 25 percent of records. */
  if (depts.every(d => !d.phys)) {
    depts.forEach(d => { d.phys = Math.round(d.rec * (0.08 + 0.17 * (seed(d.code + 'p', 29, 997) / 997))); });
    Object.keys(sites).forEach(k => sites[k].forEach(s => { s.phys = Math.round(s.rec * 0.15); }));
  }
  Object.keys(sites).forEach(k => sites[k].forEach(s => { s.idle = seed(s.name, 41, 997) % 365; }));
  const recTotal = depts.reduce((a, d) => a + d.rec, 0);
  // The records trend keeps its monthly shape but is scaled to the file's record total.
  const tSum = base.trend.values.reduce((a, v) => a + v, 0) || 1;
  let acc = 0;
  const values = base.trend.values.map((v, i, all) => {
    if (i === all.length - 1) return recTotal - acc;
    const x = Math.round(v * recTotal / tSum); acc += x; return x;
  });
  return {
    ...base,
    depts,
    sites,
    libsByDept: {},
    libsAll: [],
    trend: { ...base.trend, values },
    totals: {
      ...base.totals,
      documents: depts.reduce((a, d) => a + d.docs, 0), declared: recTotal,
      withPhysical: depts.reduce((a, d) => a + d.phys, 0), sites: depts.reduce((a, d) => a + d.sites, 0),
      activeUsers: depts.reduce((a, d) => a + d.users, 0), headcount: depts.reduce((a, d) => a + d.head, 0),
      usersDeclaring: depts.reduce((a, d) => a + d.declaring, 0), usersCreating: 0, visitors: 0,
      storageGb: Math.round(depts.reduce((a, d) => a + d.gb, 0))
    }
  };
}

/* ---------- imported manual data (Import data, Owners only, 5 Nov 2026) ---------- */


let MANUAL: { [code: string]: IUnitFigures } = {};

/** The imported figures for a unit, if any. */
export function manualFor(code: string): IUnitFigures | undefined { return MANUAL[code]; }

/**
 * Returns the report data with imported values in place of the sample ones:
 * headcount (counted from People) and, through manualFor(), completed training,
 * Go-Live date and site convention link. The site list sets the categories.
 * Units with nothing imported keep their sample figures.
 */
export function applyManual(base: IReportData, m: IManualData | null): IReportData {
  MANUAL = {};
  if (!m || !m.units) return base;
  MANUAL = m.units;
  if (m.sites && m.sites.length) {
    const rows: { [code: string]: [string, string, string?] } = {};
    m.sites.forEach(s => { if (!rows[s.department]) rows[s.department] = [s.category, s.subCategory, s.subGroup || undefined]; });
    setCategoryRows(rows);
  }
  const depts = base.depts.map(d => {
    const u = m.units[d.code];
    return u && u.headcount > 0 ? { ...d, head: u.headcount } : d;
  });
  return { ...base, depts, totals: { ...base.totals, headcount: depts.reduce((a, d) => a + d.head, 0) } };
}

/* ---------- derived figures (the same formulas as the prototype) ---------- */

/** Headcount is shown rounded to the nearest hundred. */
export const approxHead = (d: IDept): number => Math.round(d.head / 100) * 100;

function seed(text: string, mul: number, mod: number): number {
  let h = 0;
  for (let i = 0; i < text.length; i++) h = (h * mul + text.charCodeAt(i)) % mod;
  return h;
}

/** People who completed EDRMS training: imported (People tab), else a sample figure. */
export function trainingDone(d: IDept): number {
  const u = manualFor(d.code);
  if (u && u.headcount > 0) return Math.min(u.trained, d.head);
  // SAMPLE until the People tab is imported: 60 to 95 percent of the headcount.
  const rate = 0.6 + 0.35 * (seed(d.code, 37, 997) / 997);
  return Math.round(d.head * rate);
}

/** Internal and external visitors of a site. */
export function visitorSplit(s: ISite): { internal: number; external: number } {
  const h = seed(s.name, 33, 9973);
  const external = Math.round(s.visitors * (0.03 + 0.12 * (h / 9973)));
  return { internal: s.visitors - external, external };
}

/** The date a site was created. */
export function siteCreated(s: ISite): Date {
  const h = seed(s.name, 31, 100003);
  const m = h % 33;
  return new Date(2024 + Math.floor(m / 12), m % 12, 1 + (h % 27));
}

/** "k.aquino@adb.org" to "K Aquino". */
export function ownerName(email: string): string {
  const parts = String(email || '').split('@')[0].split(/[._-]/).filter(Boolean);
  return parts.map(p => p.charAt(0).toUpperCase() + p.slice(1)).join(' ') || email;
}

export function ownerInitials(email: string): string {
  return ownerName(email).split(' ').map(p => p.charAt(0)).join('').slice(0, 2);
}

/** Folders and active users of a library (sample figures). */
export function libraryExtras(l: ILibrary): { folders: number; users: number } {
  const h = seed(l.lib + '||' + l.site, 31, 9973);
  return {
    users: Math.max(1, Math.round(Math.sqrt(l.docs) / 4 + (h % 9))),
    folders: Math.max(1, Math.round(l.docs / 45 + (h % 7)))
  };
}

/* Documents over time: 35 monthly snapshots, Jan 2024 to Nov 2026 (extended
   23 Nov 2026 so the last month matches the "Data as of" refresh date). */
export const DOC_MONTHS: { y: number; m: number; lab: string }[] = (() => {
  const names = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const out: { y: number; m: number; lab: string }[] = [];
  for (let i = 0; i < 35; i++) {
    const y = 2024 + Math.floor(i / 12);
    out.push({ y, m: i % 12, lab: names[i % 12] + " '" + String(y).slice(2) });
  }
  return out;
})();

/** Documents held by a department at the start, and at the end of each month. */
export function documentSeries(d: IDept): { start: number; held: number[] } {
  let s = seed(d.code, 31, 9973);
  const w: number[] = [];
  let tw = 0;
  for (let i = 0; i < DOC_MONTHS.length; i++) {
    s = (s * 7919 + 17) % 9973;
    const x = 0.6 + 0.8 * s / 9973;
    w.push(x);
    tw += x;
  }
  const start = Math.round(d.docs * 0.55), grow = d.docs - start, held: number[] = [];
  let acc = 0;
  for (let i = 0; i < DOC_MONTHS.length; i++) {
    acc += w[i];
    held.push(start + Math.round(grow * acc / tw));
  }
  held[DOC_MONTHS.length - 1] = d.docs;
  return { start, held };
}

/** Sum a numeric field over a list. */
export function sum<T>(list: T[], pick: (x: T) => number): number {
  return list.reduce((a, x) => a + (pick(x) || 0), 0);
}
