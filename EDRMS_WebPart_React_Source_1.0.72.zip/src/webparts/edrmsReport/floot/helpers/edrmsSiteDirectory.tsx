/*
 * The client's site list (Utilization_Report_Dropdown.xlsx, Metadata tab,
 * 19 Nov 2026): Department > Division > Site, with Location 1 (HQ, RM, SO,
 * CO, RO) and Location 2 (HQ or Field Office). The figures are the client's
 * own SAMPLE values from the Bankwide Over sight tab; sites that tab does not
 * list carry a generated sample figure. Corrected on load: "Microneisa" to
 * "Micronesia", "Maldivs" to "Maldives".
 */
export interface ISiteDirectoryRow {
  dept: string; division: string; site: string; url: string;
  /** Location 1: HQ, RM, SO, CO or RO. */
  loc: string;
  /** Location 2: HQ or Field Office. */
  area: string;
  sites: number; docs: number; rec: number; phys: number;
}

const BASE = 'https://asiandevbank.sharepoint.com/sites/';
/* dept, division, site, site path, Location 1, Location 2, # sites, # documents, # records, # physical counterparts */
type Row = [string, string, string, string, string, string, number, number, number, number];
const ROWS: Row[] = [
  ["BPMSD", "BPMSD", "BPMSD", "org_bpmsd", "HQ", "HQ", 1, 570, 40, 0],
  ["CSD", "CSOD", "CSD Administration", "org_csd_csodadmin", "HQ", "HQ", 1, 1000, 704, 0],
  ["CSD", "CSOD", "CSD People Management", "org_csd_csodpeople", "HQ", "HQ", 1, 1000, 8, 0],
  ["CSD", "CSIS", "CSIS Administration", "org_csd_csisadmin", "HQ", "HQ", 1, 1000, 174, 0],
  ["CSD", "CSIS", "CSIS Field Office Support", "org_csd_csis_fos", "HQ", "HQ", 1, 1000, 4462, 0],
  ["CSD", "CSIS", "CSIS Government Relations", "org_csd_csis_gr", "HQ", "HQ", 1, 1000, 3534, 0],
  ["CSD", "CSIS", "CSIS Information Resources and Services", "org_csd_csis_ir", "HQ", "HQ", 1, 1000, 461, 0],
  ["CSD", "CSIS", "CSIS Logistics Management", "org_csd_csis_lm", "HQ", "HQ", 1, 1000, 201, 0],
  ["CSD", "CSIS", "CSIS People Management", "org_csd_csispeople", "HQ", "HQ", 1, 1000, 1, 0],
  ["CSD", "CSPC", "CSPC Administration", "org_csd_cspcadmin", "HQ", "HQ", 1, 1000, 13, 0],
  ["CSD", "CSPC", "CSPC People Management", "org_csd_cspcpeople", "HQ", "HQ", 1, 1000, 0, 0],
  ["CSD", "CSRS", "CSRS Administration", "org_csd_csrsadmin", "HQ", "HQ", 1, 1000, 2112, 0],
  ["CSD", "CSRS", "CSRS People Management", "org_csd_csrspeople", "HQ", "HQ", 1, 1000, 0, 0],
  ["CSD", "CSWH", "CSWH Administration", "org_csd_cswhadmin", "HQ", "HQ", 1, 1000, 42, 0],
  ["CSD", "CSWH", "CSWH Hospitality Management", "org_csd_cswh_hm", "HQ", "HQ", 1, 1000, 0, 0],
  ["CSD", "CSWH", "CSWH People Management", "org_csd_cswhpeople", "HQ", "HQ", 1, 1000, 88, 0],
  ["CSD", "CSWH", "CSWH Workplace Management", "org_csd_cswh_wm", "HQ", "HQ", 1, 1000, 1, 0],
  ["CWRD", "CWRD", "CAREC", "org_cwrd_carec", "HQ", "HQ", 1, 1092, 22, 0],
  ["CWRD", "CWRD", "CWRD", "org_cwrd", "HQ", "HQ", 1, 830, 50, 0],
  ["CWRD", "KARM", "KARM", "org_karm", "RM", "Field Office", 1, 419, 21, 0],
  ["CWRD", "KYRM", "KYRM", "org_kyrm", "RM", "Field Office", 1, 1737, 52, 0],
  ["CWRD", "TJRM", "TJRM", "org_tjrm", "RM", "Field Office", 1, 1543, 185, 0],
  ["CWRD", "TKRM", "TKRM", "org_tkrm", "RM", "Field Office", 1, 704, 77, 0],
  ["CWRD", "URM", "URM", "org_urm", "RM", "Field Office", 1, 1120, 123, 0],
  ["OCRP", "OCRP", "OCRP", "org_ocrp", "HQ", "HQ", 1, 1832, 256, 0],
  ["OOMP", "OOMP", "OOMP", "org_oomp", "HQ", "HQ", 1, 1436, 201, 0],
  ["OPEC", "OPEC", "OPEC", "org_opec", "HQ", "HQ", 1, 336, 40, 0],
  ["ORM", "ORM", "ORM", "org_orm", "HQ", "HQ", 1, 1727, 104, 0],
  ["OSPF", "OSPF", "OSPF", "org_ospf", "HQ", "HQ", 1, 790, 103, 0],
  ["PARD", "PARD", "PARD", "", "HQ", "HQ", 1, 100, 0, 0],
  ["PARD", "PLCO", "Vanuatu", "", "CO", "Field Office", 1, 100, 0, 0],
  ["PARD", "SPSO", "Cook Islands", "", "SO", "Field Office", 1, 100, 0, 0],
  ["PARD", "NPSO", "Federated States of Micronesia", "", "SO", "Field Office", 1, 1415, 184, 0],
  ["PARD", "SPSO", "Fiji", "", "SO", "Field Office", 1, 100, 0, 0],
  ["PARD", "SPSO", "Kiribati", "", "SO", "Field Office", 1, 100, 0, 0],
  ["PARD", "NPSO", "Marshall Islands", "", "SO", "Field Office", 1, 100, 0, 0],
  ["PARD", "PLCO", "Nauru", "", "CO", "Field Office", 1, 100, 0, 0],
  ["PARD", "SPSO", "Niue", "", "SO", "Field Office", 1, 100, 0, 0],
  ["PARD", "NPSO", "NPSO", "", "SO", "Field Office", 1, 100, 0, 0],
  ["PARD", "NPSO", "Palau", "", "SO", "Field Office", 1, 100, 0, 0],
  ["PARD", "PLCO", "PLCO", "", "CO", "Field Office", 1, 100, 0, 0],
  ["PARD", "PNRM", "PNRM", "", "RM", "Field Office", 1, 100, 0, 0],
  ["PARD", "SPSO", "Samoa", "", "SO", "Field Office", 1, 100, 0, 0],
  ["PARD", "SORM", "SORM", "", "RM", "Field Office", 1, 100, 0, 0],
  ["PARD", "SPSO", "SPSO", "", "SO", "Field Office", 1, 100, 0, 0],
  ["PARD", "SPSO", "Tonga", "", "SO", "Field Office", 1, 100, 0, 0],
  ["PARD", "SPSO", "Tuvalu", "", "SO", "Field Office", 1, 100, 0, 0],
  ["SARD", "SARD", "Maldives", "https://asiandevbank.sharepoint.com/teams/cty_mld", "HQ", "HQ", 1, 1000, 6, 0],
  ["SARD", "SARD", "SARD", "org_sard", "HQ", "HQ", 1, 1000, 146, 0],
  ["SARD", "SARD", "SASEC", "org_sard_sasec", "HQ", "HQ", 1, 1000, 56, 0],
  ["SARD", "BHRM", "BHRM", "org_bhrm", "RM", "Field Office", 1, 1000, 17, 0],
  ["SARD", "BRM", "BRM", "org_brm", "RM", "Field Office", 1, 1000, 3, 0],
  ["SARD", "INRM", "INRM", "org_inrm", "RM", "Field Office", 1, 1000, 126, 0],
  ["SARD", "NRM", "NRM", "org_nrm", "RM", "Field Office", 1, 1000, 160, 0],
  ["SARD", "SLRM", "SLRM", "org_slrm", "RM", "Field Office", 1, 1000, 112, 0],
  ["SD1", "SD1", "SD1", "org_sd1", "HQ", "HQ", 1, 1000, 10, 0],
  ["SD1", "SD1-ENE", "SD1 - Energy", "org_ene", "HQ", "HQ", 1, 1000, 8, 0],
  ["SD1", "SD1-TRA", "SD1 - Transport", "org_tra", "HQ", "HQ", 1, 1000, 0, 0],
  ["SD2", "SD2-AFNR", "AFNR", "", "HQ", "HQ", 1, 1812, 36, 0],
  ["SD2", "SD2-DIG", "DIG", "", "HQ", "HQ", 1, 844, 59, 0],
  ["SD2", "SD2", "SD2 Front Office", "", "HQ", "HQ", 1, 676, 20, 0],
  ["SD2", "SD2-WUD", "WUD", "", "HQ", "HQ", 1, 1326, 27, 0],
  ["SD3", "SD3-FIN", "FIN", "", "HQ", "HQ", 1, 973, 117, 0],
  ["SD3", "SD3-HSD", "HSD", "", "HQ", "HQ", 1, 422, 38, 0],
  ["SD3", "SD3-PSMG", "PSMG", "", "HQ", "HQ", 1, 570, 80, 0],
  ["SD3", "SD3", "SD3 Front Office", "", "HQ", "HQ", 1, 493, 44, 0],
  ["SPD", "SPD", "2027 FiCS Summit", "https://asiandevbank.sharepoint.com/teams/grp_spd_fics", "HQ", "HQ", 1, 100, 0, 0],
  ["SPD", "SPD", "Policy Architecture", "policyarchitecture", "HQ", "HQ", 1, 100, 0, 0],
  ["SPD", "SPD", "SPD", "org_spd", "HQ", "HQ", 1, 100, 57, 0],
  ["SPD", "ERO", "ERO", "org_ero", "RO", "Field Office", 1, 100, 2, 0],
  ["SPD", "JRO", "JRO", "org_ero", "RO", "Field Office", 1, 524, 68, 0],
  ["SPD", "NARO", "NARO", "org_naro", "RO", "Field Office", 1, 100, 2, 0],
  ["VPAC", "VPAC", "VPAC", "org_vpac", "HQ", "HQ", 1, 1116, 67, 0]
];

export const SITE_DIRECTORY: ISiteDirectoryRow[] = ROWS.map(r => ({
  dept: r[0], division: r[1], site: r[2], url: !r[3] ? '' : /^https:/.test(r[3]) ? r[3] : BASE + r[3], loc: r[4], area: r[5],
  sites: r[6], docs: r[7], rec: r[8], phys: r[9]
}));
