/*
 * Shareable links (25 Nov 2026). Everything on screen (dashboard, open card and every
 * filter) is kept in the page address after "#edrms=", updated as it changes, so copying
 * the address from the browser and opening it elsewhere shows the same view.
 * A value that is at its default is left out, so a plain view has a plain address.
 * If any part of an opened link is no longer valid (a department or site that no longer
 * exists, an unknown option), the whole link is ignored and the default view opens.
 */
import * as React from 'react';

type Link = { [k: string]: unknown };
const PREFIX = '#edrms=';

let link: Link = {};
let badOnOpen = false;
let invalidPending = false;
let reset: (() => void) | null = null;
let timer = 0;

function readHash(): Link {
  if (typeof window === 'undefined') return {};
  try {
    const h = window.location.hash;
    if (h.indexOf(PREFIX) !== 0) return {};
    const o = JSON.parse(decodeURIComponent(h.slice(PREFIX.length)));
    if (o && typeof o === 'object' && !Array.isArray(o)) return o as Link;
  } catch { /* fall through */ }
  badOnOpen = true;
  return {};
}
link = readHash();

function write(): void {
  window.clearTimeout(timer);
  timer = window.setTimeout(() => {
    const keys = Object.keys(link);
    const ours = window.location.hash.indexOf(PREFIX) === 0;
    // Never touch an address that is not ours and has nothing of ours to add.
    if (!keys.length && !ours) return;
    const url = window.location.pathname + window.location.search + (keys.length ? PREFIX + encodeURIComponent(JSON.stringify(link)) : '');
    try { window.history.replaceState(window.history.state, '', url); } catch { /* not allowed here */ }
  }, 60);
}

function invalidate(): void {
  link = {};
  write();
  if (reset) reset();
}

/** Called once by the report: drops a link that could not be read, and returns a counter
    that changes whenever a link turns out to be invalid, so the report can start afresh. */
export function useLinkReset(): number {
  const [gen, setGen] = React.useState(0);
  // Set during render, so it is ready before any view below checks its link value.
  reset = () => setGen(g => g + 1);
  React.useEffect(() => {
    if (badOnOpen) { badOnOpen = false; invalidate(); }
    return () => { reset = null; };
  }, []);
  return gen;
}

const same = (a: unknown, b: unknown): boolean => JSON.stringify(a) === JSON.stringify(b);

/** React.useState whose value is also kept in the page address under `key`. `valid`
    checks a value read from a link; one invalid value makes the whole link ignored. */
export function useLinked<T>(key: string, initial: T, valid: (v: unknown) => boolean): [T, (v: T | ((p: T) => T)) => void] {
  const init = React.useRef(initial);
  const [v, setV] = React.useState<T>(() => {
    if (Object.prototype.hasOwnProperty.call(link, key)) {
      const x = link[key];
      let ok = false;
      try { ok = valid(x); } catch { ok = false; }
      if (ok) return x as T;
      invalidPending = true;
    }
    return initial;
  });
  React.useEffect(() => {
    if (invalidPending) { invalidPending = false; invalidate(); }
    // A view that closes takes its filters out of the address with it.
    return () => { delete link[key]; };
  }, []);
  const set = React.useCallback((n: T | ((p: T) => T)) => {
    setV(prev => {
      const nv = typeof n === 'function' ? (n as (p: T) => T)(prev) : n;
      if (same(nv, init.current)) delete link[key]; else link[key] = nv;
      write();
      return nv;
    });
  }, [key]);
  return [v, set];
}

/** Runs `fn` when `value` changes, but not when the view first opens (so a value
    restored from a link is not overwritten by a default). */
export function useOnChange(value: unknown, fn: () => void): void {
  const first = React.useRef(true);
  React.useEffect(() => {
    if (first.current) { first.current = false; return; }
    fn();
  }, [value]);
}

/* ---------- checks for values read from a link ---------- */
export const isOneOf = (opts: readonly string[]) => (v: unknown): boolean => typeof v === 'string' && opts.indexOf(v) >= 0;
export const isSubset = (all: readonly string[]) => (v: unknown): boolean =>
  Array.isArray(v) && v.every(x => typeof x === 'string' && all.indexOf(x) >= 0);
export const isStr = (v: unknown): boolean => typeof v === 'string';
export const isStrOrNull = (v: unknown): boolean => v === null || typeof v === 'string';
