import * as React from 'react';
import styles from '../../components/Report.module.scss';
import { FLOOT_EXTRA_CSS } from '../flootExtraCss';
import { applyManual, IReportData } from '../helpers/edrmsData';
import { IManualData } from '../helpers/edrmsImportRules';
import { IManualStore } from '../helpers/edrmsManualStore';
import { ImportPanel } from './EdrmsImportPanel';
import { exportPdf, exportPptx } from '../helpers/edrmsExporters';
import { BankWide } from './EdrmsBankWide';
import { DepartmentInsights } from './EdrmsDepartmentInsights';
import { DownloadGlyph } from './EdrmsUi';

export type Dashboard = 'bw' | 'dp' | 'ad';
export type TextSize = 'standard' | 'large' | 'xlarge';

export interface IReportAppProps {
  dashboard: Dashboard;
  showSidebar: boolean;
  textSize: TextSize;
  /** Where imported manual data is read from and saved to. */
  store?: IManualStore;
  /** True only for people who can manage the site (Owners, site collection admins). */
  canImport?: boolean;
  userName?: string;
  roleLabel?: string;
}

/* Text size: Large is the default, as readers are often older. */
const ZOOM: { [k in TextSize]: number } = { standard: 1, large: 1.25, xlarge: 1.5 };
const SIDEBAR_KEY = 'edrms-sidebar-closed';

const ICONS: { [k: string]: React.ReactElement } = {
  bw: <svg viewBox="0 0 16 16"><circle cx="8" cy="8" r="6" /><circle cx="8" cy="8" r="2.5" fill="currentColor" /></svg>,
  ad: <svg viewBox="0 0 16 16"><rect x="3" y="2" width="10" height="12" rx="1" /><path d="M5.5 6h5M5.5 9h5M5.5 12h3" /></svg>,
  dp: <svg viewBox="0 0 16 16"><rect x="2" y="2" width="5" height="5" /><rect x="9" y="2" width="5" height="5" /><rect x="2" y="9" width="5" height="5" /><rect x="9" y="9" width="5" height="5" /></svg>,
  pj: <svg viewBox="0 0 16 16"><path d="M8 2l6 6-6 6-6-6z" /></svg>,
  fp: <svg viewBox="0 0 16 16"><path d="M3 4h10M3 8h10M3 12h10" /></svg>,
  rd: <svg viewBox="0 0 16 16"><circle cx="8" cy="8" r="6" /><path d="M8 5v3l2 1" /></svg>,
  ra: <svg viewBox="0 0 16 16"><rect x="2" y="3" width="12" height="4" /><path d="M3 7v6h10V7M6 10h4" /></svg>
};

const FUTURE: { key: string; text: string }[] = [
  { key: 'pj', text: 'Project Insights' },
  { key: 'fp', text: 'Institutional File Plan' },
  { key: 'rd', text: 'Retention & Disposal' },
  { key: 'ra', text: 'Records & Archive Holdings' }
];

function readClosed(): boolean {
  try { return localStorage.getItem(SIDEBAR_KEY) === '1'; } catch { return false; }
}

/* Web part 1.0.59: the Floot app's report (24 Nov 2026). Two SharePoint differences:
   the report fits the web part's own width rather than the whole browser window, and
   Import data is offered only to site Owners and site collection admins (canImport). */
export const ReportApp: React.FC<IReportAppProps & { base: IReportData }> = props => {
  const base = props.base;
  // Imported manual data (Import data) replaces sample figures for every reader.
  const [manual, setManual] = React.useState<IManualData | null>(null);
  const [importing, setImporting] = React.useState(false);
  React.useEffect(() => { if (props.store) props.store.load().then(setManual, () => setManual(null)); }, [props.store]);
  const data = React.useMemo(() => applyManual(base, manual), [base, manual]);
  const [dash, setDash] = React.useState<Dashboard>(props.dashboard);
  const [focus, setFocus] = React.useState<string | undefined>(undefined);
  const [closed, setClosed] = React.useState<boolean>(readClosed);
  const [busy, setBusy] = React.useState(false);
  const page = React.useRef<HTMLDivElement>(null);
  const root = React.useRef<HTMLDivElement>(null);
  /* 23 Nov 2026: the text size adapts to the space available, so the same layout fits any
     monitor (a smaller or scaled screen shrinks it; a large one keeps the chosen size). The
     layout was designed for about 1500 x 800 CSS pixels at size 1. In SharePoint the space
     is the web part's own width, not the whole window. */
  const [fitZoom, setFitZoom] = React.useState<number>(1);
  React.useEffect(() => {
    const fit = (): void => {
      const max = ZOOM[props.textSize] || 1.25;
      const side = props.showSidebar ? (closed ? 60 : 300) : 0;
      const host = root.current && root.current.parentElement;
      const width = host && host.clientWidth ? host.clientWidth : window.innerWidth;
      const byW = (width - side) / 1300;
      const byH = window.innerHeight / 760;
      setFitZoom(Math.max(0.6, Math.min(max, byW, byH)));
    };
    fit();
    window.addEventListener('resize', fit);
    return () => window.removeEventListener('resize', fit);
  }, [props.textSize, props.showSidebar, closed]);
  /* After the size changes, let the screen-filling parts (main graph, breakdown tables)
     measure again, on the next frame once the new size has applied. */
  React.useEffect(() => {
    const id = window.requestAnimationFrame(() => window.setTimeout(() => window.dispatchEvent(new Event('resize')), 30));
    return () => window.cancelAnimationFrame(id);
  }, [fitZoom]);

  React.useEffect(() => setDash(props.dashboard), [props.dashboard]);

  const go = (d: Dashboard): void => {
    setDash(d);
    if (d === 'bw') setFocus(undefined);
    if (root.current) root.current.scrollIntoView({ block: 'start' });
  };
  const openDept = (code: string): void => { setFocus(code); go('dp'); };
  const toggle = (): void => {
    const next = !closed;
    setClosed(next);
    try { localStorage.setItem(SIDEBAR_KEY, next ? '1' : '0'); } catch { /* private window */ }
  };
  const [menu, setMenu] = React.useState(false);
  const [busyText, setBusyText] = React.useState('');
  React.useEffect(() => {
    if (!menu) return;
    const close = (): void => setMenu(false);
    const key = (e: KeyboardEvent): void => { if (e.key === 'Escape') setMenu(false); };
    document.addEventListener('click', close);
    document.addEventListener('keydown', key);
    return () => { document.removeEventListener('click', close); document.removeEventListener('keydown', key); };
  }, [menu]);
  const name = dash === 'dp' ? 'Department Insights' : 'Bank-wide Oversight';
  /* 23 Nov 2026: "Data as of" moves only when an import is saved successfully.
     A refused or failed import never reaches the store, so the date stays put.
     Before any import, the sample data's own date is shown. */
  const asOfText = React.useMemo(() => {
    const at = manual && manual.importedAt ? new Date(manual.importedAt) : null;
    if (!at || isNaN(at.getTime())) return 'Monday 23 Nov 2026';
    const m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const w = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return w[at.getDay()] + ' ' + ('0' + at.getDate()).slice(-2) + ' ' + m[at.getMonth()] + ' ' + at.getFullYear();
  }, [manual, base.asOf]);
  // The capture libraries do not understand CSS zoom, so the page is drawn at
  // standard size and the text size is put back afterwards.
  const run = (text: string, job: () => Promise<void>): void => {
    if (!page.current || busy) return;
    setMenu(false); setBusy(true); setBusyText(text);
    const r = root.current, zoom = r ? r.style.getPropertyValue('zoom') : '';
    if (r) r.style.setProperty('zoom', '1');
    const done = (): void => { if (r) r.style.setProperty('zoom', zoom); setBusy(false); };
    job().then(done, e => { console.error('[EDRMS export]', e); done(); });
  };
  const pdf = (): void => run('Preparing PDF', () => exportPdf(page.current as HTMLElement, name));
  /* RAC Item 8 (22 Oct 2026): PowerPoint, one slide per breakdown and section. */
  const pptx = (): void => run('Preparing PowerPoint', () => {
    const el = page.current as HTMLElement;
    const pick = (q: string): string => ((el.querySelector(q) || {}).textContent || '').trim();
    return exportPptx(el, {
      name, desc: pick('.band .bd'), asOf: asOfText,
      filter: dash === 'bw' ? 'All Departments / Offices / RMs / ROs'
        : Array.from(el.querySelectorAll('.dash-dp > .panel:first-of-type .cgG')).map(g =>
          ((g.querySelector('.cgL') || {}).textContent || '') + ': ' + ((g.querySelector('.ms-Dropdown-title') || {}).textContent || '').trim()).join('  ·  ')
    });
  });

  const canImport = !!(props.canImport && props.store);
  const bandTools = (
    <>
      <span className="asof"><i />Data as of<b>{asOfText}</b></span>
      {/* Bank-wide Oversight only, and only for site Owners and site collection admins. */}
      {dash === 'bw' && canImport && (
        <button type="button" className="pdfBtn impOpen" data-html2canvas-ignore="true" onClick={() => setImporting(true)}
          title="Owners and admins: import People and training">
          <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 11V2M4.5 5.5 8 2l3.5 3.5M2.5 10.5v3h11v-3" /></svg>Import data
        </button>
      )}
      <span className="xMenuWrap" data-html2canvas-ignore="true">
        <button type="button" className="pdfBtn" disabled={busy} aria-haspopup="menu" aria-expanded={menu}
          onClick={e => { e.stopPropagation(); setMenu(!menu); }}>
          <DownloadGlyph />{busy ? busyText : 'Export'}{!busy && <span className="xCaret" aria-hidden="true">&#9662;</span>}
        </button>
        {menu && (
          <div className="xMenu" role="menu" onClick={e => e.stopPropagation()}>
            <button type="button" role="menuitem" onClick={pdf}><span className="xIc pdf">PDF</span><span><b>PDF</b><small>The dashboard as on screen</small></span></button>
            <button type="button" role="menuitem" onClick={pptx}><span className="xIc ppt">PPT</span><span><b>PowerPoint</b><small>One slide per breakdown and section, editable title and key points</small></span></button>
          </div>
        )}
      </span>
    </>
  );

  return (
    <div ref={root} className={styles.report + ' edrms-report'} style={{ zoom: fitZoom, minHeight: (100 / fitZoom).toFixed(2) + 'vh', background: '#C3E4F3' } as React.CSSProperties}>
      {props.showSidebar && (
        <nav className={'side' + (closed ? ' closed' : '')} aria-label="Dashboards">
          <div className="brand">
            <button type="button" className="menuBtn" onClick={toggle} aria-expanded={!closed}
              title={closed ? 'Open navigation' : 'Close navigation'} aria-label={closed ? 'Open navigation' : 'Close navigation'}>
              <svg viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16" /></svg>
            </button>
            <div className="t1">EDRMS Utilization Report</div>
            <div className="t2">Asian Development Bank</div>
          </div>
          <div className="grp">Key views</div>
          <button type="button" className={'nav' + (dash === 'bw' ? ' on' : '')} aria-current={dash === 'bw' ? 'page' : undefined} title="Bank-wide Oversight" onClick={() => go('bw')}>
            {ICONS.bw}<span className="navTx">Bank-wide Oversight</span>
          </button>
          <button type="button" className={'nav' + (dash === 'dp' ? ' on' : '')} aria-current={dash === 'dp' ? 'page' : undefined} title="Department Insights" onClick={() => go('dp')}>
            {ICONS.dp}<span className="navTx">Department Insights</span>
          </button>
          <div className="grp">For future release</div>
          {FUTURE.map(f => (
            <button type="button" key={f.key} className="nav future" aria-disabled="true" title={f.text + ' (future release)'}>
              {ICONS[f.key]}<span className="navTx">{f.text}</span>
            </button>
          ))}
        </nav>
      )}
      <style>{FLOOT_EXTRA_CSS}</style>
      <div className="main" ref={page}>
        {dash === 'dp'
          ? <DepartmentInsights data={data} openDept={openDept} bandTools={bandTools} focus={focus} />
          : <BankWide data={data} openDept={openDept} bandTools={bandTools} />}
      </div>
      {importing && canImport && props.store && (
        <ImportPanel store={props.store} user={props.userName || 'Site owner'} role={props.roleLabel || 'Site owner'}
          current={manual} knownUnits={base.depts.map(d => d.code)}
          onClose={() => setImporting(false)} onLoaded={setManual} />
      )}
    </div>
  );
};
